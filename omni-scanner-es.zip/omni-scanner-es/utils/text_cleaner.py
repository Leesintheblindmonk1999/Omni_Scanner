"""
text_cleaner.py — Omni-Scanner Semántico v1.0
----------------------------------------------
Normalizador de ruido léxico. Prepara el texto para análisis semántico
preservando el español completo (tildes, ñ, ü, ç).

CHANGELOG vs versión original:
  + clean(raw_text) preservada con firma original
  + segment_by_logic(text) preservada con firma original
  + FIX CRÍTICO: .encode('ascii','ignore') eliminaba todas las tildes y ñ,
    rompiendo la detección de cláusulas en español (ej: 'Cláusula' → 'Clusula').
    Reemplazado por normalización Unicode NFKC que preserva el español.
  + NUEVO: clean() acepta parámetro keep_case (default False = minúsculas)
  + NUEVO: clean_for_analysis() — limpieza conservadora que preserva mayúsculas
    y puntuación para el TopologyMapper y EntropyAnalyzer
  + NUEVO: extract_metadata() — extrae fechas, montos y referencias numéricas
  + NUEVO: segment_by_paragraph() — segmentación por párrafos (más útil que por '.;:')
  + NUEVO: normalize_legal_abbreviations() — expande abreviaturas comunes
"""
from __future__ import annotations
import re
import unicodedata
from typing import List


# Abreviaturas legales/técnicas comunes en español
_LEGAL_ABBREVS = {
    r"\bart\.": "artículo",
    r"\barts\.": "artículos",
    r"\bcfr\.": "conforme",
    r"\bej\.": "ejemplo",
    r"\betc\.": "etcétera",
    r"\binc\.": "inciso",
    r"\blit\.": "literal",
    r"\bnum\.": "número",
    r"\bpár\.": "párrafo",
    r"\bpárs\.": "párrafos",
    r"\bsec\.": "sección",
    r"\bvid\.": "véase",
}

# Artefactos de encoding frecuentes en documentos escaneados / PDFs
_ENCODING_ARTIFACTS = {
    "\x92": "'",  "\x93": '"',  "\x94": '"',
    "\x96": "–",  "\x97": "—",  "\xa0": " ",
    "\x85": "...", "\x91": "'",  "\x95": "•",
}


class TextCleaner:
    """
    Normalizador de texto para el pipeline del Omni-Scanner.

    Parameters
    ----------
    remove_html : bool          Eliminar etiquetas HTML/XML (default True).
    normalize_whitespace : bool Colapsar espacios múltiples (default True).
    fix_encoding : bool         Corregir artefactos de encoding (default True).
    expand_abbrevs : bool       Expandir abreviaturas legales (default False).
    """

    def __init__(
        self,
        remove_html: bool = True,
        normalize_whitespace: bool = True,
        fix_encoding: bool = True,
        expand_abbrevs: bool = False,
    ):
        self.remove_html = remove_html
        self.normalize_whitespace = normalize_whitespace
        self.fix_encoding = fix_encoding
        self.expand_abbrevs = expand_abbrevs

    # ------------------------------------------------------------------
    # API ORIGINAL (preservada para compatibilidad)
    # ------------------------------------------------------------------

    def clean(self, raw_text: str, keep_case: bool = False) -> str:
        """
        Limpieza estándar del texto. API original preservada y corregida.

        FIX: eliminado .encode('ascii','ignore') que destruía español.
        Ahora usa normalización Unicode NFKC + eliminación solo de caracteres
        de control, preservando todo el alfabeto español.

        Parameters
        ----------
        raw_text : str
        keep_case : bool    Si True, preserva mayúsculas. Default False (minúsculas).
        """
        text = raw_text

        # 1. Artefactos de encoding (PDF, Word, etc.)
        if self.fix_encoding:
            text = self._fix_encoding_artifacts(text)

        # 2. Normalización Unicode NFKC (preserva tildes y ñ)
        text = unicodedata.normalize("NFKC", text)

        # 3. Eliminar etiquetas HTML/XML
        if self.remove_html:
            text = re.sub(r"<[^>]*>", "", text)

        # 4. Eliminar caracteres de control (pero NO letras acentuadas)
        text = self._remove_control_chars(text)

        # 5. Normalizar espacios y saltos de línea
        if self.normalize_whitespace:
            text = re.sub(r"\s+", " ", text).strip()

        # 6. Expansión de abreviaturas (opcional)
        if self.expand_abbrevs:
            text = self.normalize_legal_abbreviations(text)

        return text if keep_case else text.lower()

    def segment_by_logic(self, text: str) -> List[str]:
        """
        Divide el texto en unidades de pensamiento lógico.
        API original preservada. Filtra segmentos vacíos.
        """
        segments = re.split(r"[.;:]", text)
        return [s.strip() for s in segments if s.strip()]

    # ------------------------------------------------------------------
    # API EXTENDIDA
    # ------------------------------------------------------------------

    def clean_for_analysis(self, raw_text: str) -> str:
        """
        Limpieza conservadora: preserva mayúsculas y puntuación oracional.
        Ideal para TopologyMapper (necesita oraciones completas) y
        EntropyAnalyzer (sensible a la distribución real de tokens).
        """
        text = self._fix_encoding_artifacts(raw_text)
        text = unicodedata.normalize("NFKC", text)
        if self.remove_html:
            text = re.sub(r"<[^>]*>", "", text)
        text = self._remove_control_chars(text)
        # Preservar puntuación oracional, solo colapsar espacios múltiples
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text.strip()

    def segment_by_paragraph(self, text: str) -> List[str]:
        """
        Segmentación por párrafos (doble salto de línea).
        Más útil que segment_by_logic para documentos legales y técnicos.
        """
        paragraphs = re.split(r"\n{2,}", text.strip())
        return [p.strip() for p in paragraphs if len(p.strip()) > 20]

    def segment_by_sentence(self, text: str) -> List[str]:
        """
        Segmentación por oraciones con manejo de abreviaturas.
        Preserva el punto final para el TopologyMapper.
        """
        # Marcadores temporales para abreviaturas que contienen punto
        protected = re.sub(
            r"\b(art|arts|dr|sr|sra|ing|lic|etc|num|pár|sec)\.",
            lambda m: m.group(0).replace(".", "<<<DOT>>>"),
            text,
            flags=re.IGNORECASE,
        )
        sentences = re.split(r"(?<=[.!?])\s+(?=[A-ZÁÉÍÓÚÑ])", protected)
        return [
            s.replace("<<<DOT>>>", ".").strip()
            for s in sentences
            if len(s.strip()) > 10
        ]

    def extract_metadata(self, text: str) -> dict:
        """
        Extrae entidades numéricas y referencias clave del texto.
        Útil para auditoría de contratos (plazos, montos, porcentajes).
        """
        dates = re.findall(
            r"\b(\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4}-\d{2}-\d{2})\b", text
        )
        amounts = re.findall(
            r"\b(?:USD|ARS|EUR|BTC)?\s*[\$€£]?\s*\d[\d.,]*(?:\s*(?:millones?|mil))?\b",
            text, re.IGNORECASE,
        )
        percentages = re.findall(r"\b\d+(?:[.,]\d+)?\s*%", text)
        deadlines = re.findall(
            r"\b\d+\s*(?:días?|meses?|años?|horas?|semanas?)\b", text, re.IGNORECASE
        )
        references = re.findall(
            r"\b(?:art[ií]culo|cláusula|inciso|sección|anexo)\s+\d+\w*\b",
            text, re.IGNORECASE,
        )

        return {
            "dates": dates,
            "amounts": amounts,
            "percentages": percentages,
            "deadlines": deadlines,
            "legal_references": references,
            "has_numeric_content": bool(dates or amounts or percentages),
        }

    def normalize_legal_abbreviations(self, text: str) -> str:
        """Expande abreviaturas legales comunes en español."""
        for pattern, replacement in _LEGAL_ABBREVS.items():
            text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)
        return text

    def strip_boilerplate(self, text: str, min_sentence_len: int = 30) -> str:
        """
        Elimina frases de boilerplate muy cortas o repetitivas
        (pies de página, disclaimers genéricos de una línea).
        """
        sentences = self.segment_by_sentence(text)
        return " ".join(s for s in sentences if len(s) >= min_sentence_len)

    # ------------------------------------------------------------------
    # Helpers privados
    # ------------------------------------------------------------------

    def _fix_encoding_artifacts(self, text: str) -> str:
        for bad, good in _ENCODING_ARTIFACTS.items():
            text = text.replace(bad, good)
        return text

    def _remove_control_chars(self, text: str) -> str:
        """
        Elimina solo caracteres de control Unicode (categoría Cc),
        preservando letras, tildes, ñ y cualquier carácter visible.
        """
        return "".join(
            ch for ch in text
            if unicodedata.category(ch) != "Cc" or ch in ("\n", "\t")
        )
