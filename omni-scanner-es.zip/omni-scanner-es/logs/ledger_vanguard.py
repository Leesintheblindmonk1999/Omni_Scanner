"""
logs/ledger_vanguard.py — Omni-Scanner Semántico v2.0
═══════════════════════════════════════════════════════
Forensic Ledger Vanguard — Inmutabilidad del Veredicto

Genera registros de auditoría con hash SHA-256 encadenados
(hash del registro anterior incluido en el siguiente — cadena
de hashes equivalente a la estructura de un bloque blockchain).

Estructura de cada registro:
  {
    "block_index":      int,
    "timestamp":        str (ISO 8601 UTC),
    "document_hash":    sha256(texto_original),
    "manifold_score":   float,
    "overall_verdict":  str,
    "kappa_d":          float,
    "previous_hash":    sha256(registro anterior),  ← encadenamiento
    "block_hash":       sha256(todo lo anterior)    ← sellado final
  }

Verificación de integridad:
  Si cualquier registro es editado, block_hash ya no coincide
  con la recomputación → TAMPERING DETECTED.

Esquema blockchain preparado:
  El método to_chain_payload() exporta el registro en el formato
  compatible con Ethereum (EVM) para grabación on-chain via
  la función: keccak256(abi.encode(block_hash, block_index, timestamp))
  Solo requiere una billetera Web3 + contrato de registry externo.
"""
from __future__ import annotations

import os
import sys
import json
import hashlib
import datetime
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, List

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


# ══════════════════════════════════════════════════════════════
# Constantes
# ══════════════════════════════════════════════════════════════

GENESIS_HASH = "0" * 64   # hash del bloque génesis (anterior al primero)
LEDGER_VERSION = "2.0"


# ══════════════════════════════════════════════════════════════
# Estructuras de datos
# ══════════════════════════════════════════════════════════════

@dataclass
class LedgerBlock:
    """
    Un registro inmutable en el Forensic Ledger.
    Una vez sellado (block_hash calculado), cualquier modificación
    invalida el hash y es detectable.
    """
    block_index:      int
    timestamp:        str
    document_hash:    str       # SHA-256 del texto original
    document_preview: str       # primeros 120 chars (no identificatorio)
    manifold_score:   float
    overall_verdict:  str       # CLEAR | REVIEW | HIGH_RISK
    topology_flag:    str
    coherence_score:  float
    kappa_d:          float
    input_type:       str
    auditor_id:       str       # identificador del nodo auditor
    previous_hash:    str       # hash del bloque anterior (encadenamiento)
    block_hash:       str = ""  # se calcula al sellar

    # Metadata extendida
    extra: dict = field(default_factory=dict)

    def seal(self) -> "LedgerBlock":
        """Calcula y asigna el block_hash sellando el registro."""
        self.block_hash = self._compute_block_hash()
        return self

    def verify(self) -> bool:
        """Verifica que el block_hash es correcto (sin tampering)."""
        expected = self._compute_block_hash()
        return self.block_hash == expected

    def _compute_block_hash(self) -> str:
        """
        SHA-256 sobre la concatenación determinista de todos los campos.
        Incluye previous_hash para asegurar el encadenamiento.
        """
        payload = (
            f"{self.block_index}"
            f"|{self.timestamp}"
            f"|{self.document_hash}"
            f"|{self.manifold_score:.8f}"
            f"|{self.overall_verdict}"
            f"|{self.topology_flag}"
            f"|{self.coherence_score:.8f}"
            f"|{self.kappa_d:.8f}"
            f"|{self.input_type}"
            f"|{self.auditor_id}"
            f"|{self.previous_hash}"
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def to_dict(self) -> dict:
        d = {k: v for k, v in self.__dict__.items()}
        return d

    def to_chain_payload(self) -> dict:
        """
        Payload para grabación on-chain (compatible con EVM/Ethereum).

        Para registrar en blockchain:
          1. Llamar to_chain_payload()
          2. Encodar con abi.encode() o eth_abi
          3. Enviar a contrato de registry: registerAudit(bytes32 blockHash, ...)
          4. El txHash de Ethereum es la prueba de existencia inmutable.

        Contrato mínimo (Solidity):
          function registerAudit(
              bytes32 blockHash,
              uint256 blockIndex,
              uint256 timestamp,
              bytes32 documentHash,
              string memory verdict
          ) external { ... }
        """
        return {
            "contract_function": "registerAudit",
            "args": {
                "blockHash":    "0x" + self.block_hash,
                "blockIndex":   self.block_index,
                "timestamp":    int(datetime.datetime.fromisoformat(
                    self.timestamp.replace("Z", "+00:00")
                ).timestamp()),
                "documentHash": "0x" + self.document_hash,
                "verdict":      self.overall_verdict,
            },
            "ledger_version": LEDGER_VERSION,
            "note": "Requiere billetera Web3 + contrato de registry desplegado",
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=indent)


@dataclass
class LedgerIntegrityReport:
    """Resultado de la verificación de integridad de toda la cadena."""
    total_blocks:       int
    valid_blocks:       int
    tampered_blocks:    list    # índices de bloques con tampering
    chain_intact:       bool
    first_block_index:  int
    last_block_index:   int
    verification_hash:  str     # hash de la cadena completa

    @property
    def tampering_detected(self) -> bool:
        return len(self.tampered_blocks) > 0


# ══════════════════════════════════════════════════════════════
# Motor principal
# ══════════════════════════════════════════════════════════════

class LedgerVanguard:
    """
    Forensic Ledger Vanguard — Registro Histórico de la Verdad.

    Mantiene una cadena de bloques local en JSONL donde cada registro
    incluye el hash del anterior. Cualquier modificación retrospectiva
    rompe la cadena y es detectada por verify_chain().

    Parámetros
    ----------
    ledger_path : Path
        Archivo JSONL donde se persiste la cadena.
    auditor_id : str
        Identificador del nodo auditor (puede ser hostname, API key hash, etc.)
    kappa_d : float
        Constante de referencia (default 0.56).
    """

    def __init__(
        self,
        ledger_path: Optional[Path] = None,
        auditor_id: str = "omni-scanner-local",
        kappa_d: float = 0.56,
    ):
        self.ledger_path = ledger_path or (
            Path(__file__).parent / "vanguard_ledger.jsonl"
        )
        self.auditor_id = auditor_id
        self.kappa_d    = kappa_d
        self._cache: Optional[List[LedgerBlock]] = None

    # ── API principal ─────────────────────────────────────────

    def register(
        self,
        raw_text: str,
        manifold_score: float,
        overall_verdict: str,
        topology_flag: str = "N/A",
        coherence_score: float = 0.0,
        input_type: str = "generic",
        extra: Optional[dict] = None,
    ) -> LedgerBlock:
        """
        Registra un veredicto de auditoría en el ledger.

        Genera el hash del documento + encadena con el bloque anterior.
        Retorna el LedgerBlock sellado y persistido.

        Parámetros
        ----------
        raw_text : str
            Texto original auditado (se hashea, no se guarda completo).
        manifold_score : float
        overall_verdict : str     CLEAR | REVIEW | HIGH_RISK
        topology_flag : str
        coherence_score : float
        input_type : str
        extra : dict             Campos adicionales opcionales.
        """
        # Hash del documento (el texto nunca se guarda, solo su huella)
        doc_hash = hashlib.sha256(
            raw_text.encode("utf-8", errors="replace")
        ).hexdigest()

        # Encadenamiento: hash del bloque anterior
        prev_hash = self._get_last_hash()

        # Nuevo índice
        block_idx = self._get_block_count()

        # Timestamp ISO 8601 UTC
        ts = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"

        # Preview del documento (primeros 120 chars, sin datos sensibles)
        preview = raw_text.strip()[:120].replace("\n", " ")

        block = LedgerBlock(
            block_index      = block_idx,
            timestamp        = ts,
            document_hash    = doc_hash,
            document_preview = preview,
            manifold_score   = round(manifold_score, 8),
            overall_verdict  = overall_verdict,
            topology_flag    = topology_flag,
            coherence_score  = round(coherence_score, 8),
            kappa_d          = self.kappa_d,
            input_type       = input_type,
            auditor_id       = self.auditor_id,
            previous_hash    = prev_hash,
            extra            = extra or {},
        ).seal()

        # Persistir
        self._append_block(block)
        self._cache = None   # invalidar cache

        return block

    def verify_chain(self) -> LedgerIntegrityReport:
        """
        Verifica la integridad completa de la cadena.

        Para cada bloque:
          1. Recomputa block_hash desde sus campos
          2. Verifica que previous_hash == hash del bloque anterior
          3. Detecta cualquier modificación retrospectiva

        Si un solo byte fue alterado en cualquier bloque,
        la cadena se rompe a partir de ese punto.
        """
        blocks = self._load_all_blocks()

        if not blocks:
            return LedgerIntegrityReport(
                total_blocks=0, valid_blocks=0, tampered_blocks=[],
                chain_intact=True, first_block_index=0, last_block_index=0,
                verification_hash=GENESIS_HASH,
            )

        tampered = []
        prev_hash = GENESIS_HASH

        for block in blocks:
            # Verificar integridad interna del bloque
            if not block.verify():
                tampered.append(block.block_index)

            # Verificar encadenamiento
            if block.previous_hash != prev_hash:
                if block.block_index not in tampered:
                    tampered.append(block.block_index)

            prev_hash = block.block_hash

        # Hash de verificación de toda la cadena
        chain_str = "".join(b.block_hash for b in blocks)
        chain_hash = hashlib.sha256(chain_str.encode()).hexdigest()

        return LedgerIntegrityReport(
            total_blocks      = len(blocks),
            valid_blocks      = len(blocks) - len(tampered),
            tampered_blocks   = tampered,
            chain_intact      = len(tampered) == 0,
            first_block_index = blocks[0].block_index,
            last_block_index  = blocks[-1].block_index,
            verification_hash = chain_hash,
        )

    def get_block(self, index: int) -> Optional[LedgerBlock]:
        """Recupera un bloque por índice."""
        blocks = self._load_all_blocks()
        for b in blocks:
            if b.block_index == index:
                return b
        return None

    def get_recent(self, n: int = 20) -> List[LedgerBlock]:
        """Retorna los N bloques más recientes."""
        return self._load_all_blocks()[-n:]

    def export_json(self) -> str:
        """Exporta toda la cadena como JSON."""
        blocks = self._load_all_blocks()
        return json.dumps(
            {
                "ledger_version": LEDGER_VERSION,
                "kappa_d":        self.kappa_d,
                "total_blocks":   len(blocks),
                "chain":          [b.to_dict() for b in blocks],
            },
            ensure_ascii=False, indent=2,
        )

    # ── Persistencia ──────────────────────────────────────────

    def _append_block(self, block: LedgerBlock):
        """Agrega un bloque al archivo JSONL."""
        self.ledger_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.ledger_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(block.to_dict(), ensure_ascii=False) + "\n")

    def _load_all_blocks(self) -> List[LedgerBlock]:
        """Carga todos los bloques del archivo JSONL."""
        if self._cache is not None:
            return self._cache

        if not self.ledger_path.exists():
            return []

        blocks = []
        with open(self.ledger_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    d = json.loads(line)
                    block = LedgerBlock(**d)
                    blocks.append(block)
                except Exception:
                    continue

        self._cache = blocks
        return blocks

    def _get_last_hash(self) -> str:
        """Hash del último bloque (o GENESIS si es el primero)."""
        blocks = self._load_all_blocks()
        if not blocks:
            return GENESIS_HASH
        return blocks[-1].block_hash

    def _get_block_count(self) -> int:
        """Número total de bloques en la cadena."""
        return len(self._load_all_blocks())


# ══════════════════════════════════════════════════════════════
# Ledger global del proyecto
# ══════════════════════════════════════════════════════════════

_DEFAULT_LEDGER_PATH = Path(__file__).parent / "vanguard_ledger.jsonl"

def get_global_ledger(kappa_d: float = 0.56) -> LedgerVanguard:
    """Retorna la instancia global del ledger del proyecto."""
    return LedgerVanguard(ledger_path=_DEFAULT_LEDGER_PATH, kappa_d=kappa_d)
