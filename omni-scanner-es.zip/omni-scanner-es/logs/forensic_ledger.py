"""
logs/forensic_ledger.py
────────────────────────
Forensic Ledger — Registro inmutable de operaciones de sellado.

Cada entrada es una línea JSON (formato JSONL) con:
  - timestamp      : ISO 8601 UTC
  - file_hash      : SHA-256 del input original
  - kd_result      : ManifoldScore y veredicto del análisis κD
  - authorship_status : estado de la firma y ancla de identidad
  - cert_id        : ID del certificado generado
  - verdict        : veredicto general del escaneo
  - input_type     : tipo de documento analizado

APPEND-ONLY: el archivo solo se escribe al final, nunca se modifica.
La función de lectura retorna las entradas como lista de dicts.
"""
from __future__ import annotations

import json
import hashlib
import datetime
from pathlib import Path
from typing import Iterator

LEDGER_PATH = Path(__file__).parent / "audit_ledger.jsonl"


def _utc_now() -> str:
    return datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"


def append_entry(
    raw_text:          str,
    report_dict:       dict,
    authorship:        dict,
    cert_path:         str | None = None,
    anchor_data:       dict | None = None,
) -> dict:
    """
    Registra una operación de 'Firmar y Sellar' en el ledger.
    Retorna la entrada escrita.

    Parámetros
    ----------
    raw_text      : Texto original analizado (se hashea, nunca se almacena).
    report_dict   : FullDiagnosticReport.__dict__
    authorship    : Bloque de firma de MetadataOrigin
    cert_path     : Ruta al PDF generado (opcional)
    anchor_data   : Payload del Ancla de Identidad (opcional)
    """
    file_hash = hashlib.sha256(
        raw_text.encode("utf-8", errors="replace")
    ).hexdigest()

    ms = report_dict.get("manifold_score", None)
    kd_result = {
        "manifold_score":   round(float(ms), 6) if ms is not None and ms == ms and ms != -1.0 else None,
        "manifold_verdict": report_dict.get("manifold_verdict", "N/A"),
        "coherence_score":  round(float(report_dict.get("coherence_score", 0)), 6),
        "domain_risk":      round(float(report_dict.get("domain_risk", 0)), 6),
        "kappa_d":          0.56,
    }

    authorship_status = {
        "signed":       bool(authorship),
        "signed_by":    authorship.get("signed_by", "—"),
        "protocol":     authorship.get("protocol", "—"),
        "content_hash": authorship.get("content_hash", "—"),
        "timestamp":    authorship.get("timestamp", "—"),
        "anchored":     anchor_data is not None,
        "anchor_origin_hash": (anchor_data or {}).get("origin_hash", None),
    }

    entry = {
        "timestamp":          _utc_now(),
        "file_hash":          file_hash,
        "kd_result":          kd_result,
        "authorship_status":  authorship_status,
        "verdict":            report_dict.get("overall_verdict", "N/A"),
        "input_type":         report_dict.get("input_type",      "generic"),
        "cert_id":            Path(cert_path).stem if cert_path else None,
        "cert_path":          str(cert_path) if cert_path else None,
        "sovereignty_verdict": report_dict.get("sovereignty_verdict", "N/A"),
        "confidence":         round(float(report_dict.get("confidence", 0)), 4),
    }

    # Append-only: abrir en modo 'a' siempre
    LEDGER_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(LEDGER_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")

    return entry


def read_entries(last_n: int | None = None) -> list[dict]:
    """
    Lee el ledger y retorna las entradas como lista de dicts.
    Si last_n es especificado, retorna solo las últimas N entradas.
    """
    if not LEDGER_PATH.exists():
        return []
    entries = []
    with open(LEDGER_PATH, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    entries.append(json.loads(line))
                except json.JSONDecodeError:
                    pass
    return entries[-last_n:] if last_n else entries


def entry_count() -> int:
    """Retorna el número de entradas en el ledger."""
    if not LEDGER_PATH.exists():
        return 0
    count = 0
    with open(LEDGER_PATH, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                count += 1
    return count


def verify_integrity() -> dict:
    """
    Verifica la integridad del ledger calculando un hash encadenado
    de todas las entradas. Detecta si alguna línea fue modificada.
    """
    import hashlib
    entries = read_entries()
    if not entries:
        return {"valid": True, "entries": 0, "chain_hash": None}

    chain = ""
    for entry in entries:
        line_hash = hashlib.sha256(
            json.dumps(entry, sort_keys=True, ensure_ascii=False).encode()
        ).hexdigest()
        chain += line_hash

    chain_hash = hashlib.sha256(chain.encode()).hexdigest()
    return {
        "valid":       True,
        "entries":     len(entries),
        "chain_hash":  chain_hash,
        "first_ts":    entries[0].get("timestamp", "—") if entries else None,
        "last_ts":     entries[-1].get("timestamp", "—") if entries else None,
    }
