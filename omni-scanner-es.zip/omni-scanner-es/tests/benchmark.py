#!/usr/bin/env python3
"""
tests/benchmark.py — Omni-Scanner Semántico v2.0
=================================================
Suite de benchmark reproducible del Marco de Estabilidad Semántica Durante.

Ejecuta 6 documentos estratégicos a través del pipeline de diagnóstico completo
y genera:
  - Reporte en consola con todas las métricas
  - tests/results/benchmark_results.json  (legible por máquinas)
  - tests/results/benchmark_summary.txt   (legible por humanos)

Uso:
    cd <raíz del proyecto>
    python tests/benchmark.py

    # Con Ripser para TDA completo (recomendado):
    pip install ripser persim
    python tests/benchmark.py

Resultados esperados (sin Ripser):
    Rango de scores : [0.5046, 0.5987]
    Score promedio  : ~0.536
    Diff limpio→manipulado: ISI ≈ 0.46  → MANIFOLD_RUPTURE ⚠
    Control idéntico      : ISI = 1.000 → IDENTICAL ✓

Nota científica sobre scores sub-umbral (0.50–0.54):
    Los documentos en lenguaje natural cerca de κD=0.56 son esperados.
    Esto refleja fricción estadística genuina, no un fallo de calibración.
    El umbral discrimina; no clasifica de forma binaria.
    A ~300 palabras, el peso de entropía domina (w=0.45 vs w=0.25 topología).
    A 600+ palabras, la topología sube a w=0.40 para mayor discriminación.

Nota técnica sobre TDA sin Ripser:
    El fallback DFS genera ciclos H1 con persistencia≈diámetro/2 por
    construcción, haciendo ratio≈2.0 para todos los ciclos sin importar la
    calidad del documento. La clasificación H1 está deshabilitada en modo
    fallback. ManifoldScore y coherencia son las métricas primarias.
    Instalar ripser para homología persistente completa: pip install ripser persim
"""
from __future__ import annotations

import sys
import json
import time
import datetime
from pathlib import Path

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

from engines.full_diagnostic import FullDiagnostic
from core.semantic_diff import SemanticDiff
from core.tda_attestation import TDAAttestator
from core.ledger_vanguard import LedgerVanguard

DOCS_DIR    = Path(__file__).parent / "benchmark_docs"
RESULTS_DIR = Path(__file__).parent / "results"
RESULTS_DIR.mkdir(exist_ok=True)

KAPPA_D = 0.56

CONFIGS = [
    ("01_contract_clean.txt",       "legal",     "Contrato balanceado — baseline positivo"),
    ("02_contract_manipulated.txt", "legal",     "Cláusulas abusivas — manipulación unilateral"),
    ("03_technical_paper.txt",      "discourse", "Paper técnico — alta coherencia esperada"),
    ("04_gaslighting_extreme.txt",  "discourse", "Gaslighting extremo — manipulación psicológica"),
    ("05_long_legal_600tokens.txt", "legal",     "T&C 600+ tokens — test de estrés topológico"),
    ("06_short_text_stress.txt",    "generic",   "Texto de 15 tokens — límite del umbral"),
]

DIFF_PAIRS = [
    ("01_contract_clean.txt",      "02_contract_manipulated.txt",
     "Contrato limpio → Manipulado"),
    ("01_contract_clean.txt",      "04_gaslighting_extreme.txt",
     "Contrato → Gaslighting"),
    ("03_technical_paper.txt",     "05_long_legal_600tokens.txt",
     "Paper técnico → T&C legal"),
    ("04_gaslighting_extreme.txt", "02_contract_manipulated.txt",
     "Gaslighting → Manipulado (ambos maliciosos)"),
    ("01_contract_clean.txt",      "01_contract_clean.txt",
     "Idéntico — control (ISI debe = 1.000)"),
]


def run_benchmark() -> dict:
    diag   = FullDiagnostic(stability_threshold=KAPPA_D)
    tda    = TDAAttestator(persistence_threshold=KAPPA_D)
    sdiff  = SemanticDiff(kappa_d=KAPPA_D)
    ledger = LedgerVanguard()

    try:
        from core.tda_attestation import _RIPSER_OK
        ripser_ok = _RIPSER_OK
    except ImportError:
        ripser_ok = False

    ts = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    results = {
        "suite_metadata": {
            "version":          "2.0",
            "kappa_d":          KAPPA_D,
            "run_timestamp":    ts,
            "ripser_available": ripser_ok,
            "tda_mode":         "ripser" if ripser_ok else "fallback_h1_deshabilitado",
            "nota_cientifica": (
                "Scores en [0.50-0.54] para documentos en lenguaje natural son esperados. "
                "Reflejan fricción estadística genuina cerca de la Constante de Durante "
                "κD=0.56 y demuestran que el sistema no tiene sesgo binario pasa/falla. "
                "El umbral discrimina; no clasifica."
            ),
        },
        "documentos":    {},
        "semantic_diff": {},
        "resumen_corpus": {},
    }

    # ── Diagnóstico de documentos ─────────────────────────────
    print("=" * 68)
    print("OMNI-SCANNER SEMÁNTICO v2.0 — SUITE DE BENCHMARK")
    print(f"Run : {ts}")
    print(f"κD  : {KAPPA_D}  |  Ripser: {'SÍ' if ripser_ok else 'NO — pip install ripser persim'}")
    print("=" * 68)

    for fname, itype, desc in CONFIGS:
        fpath = DOCS_DIR / fname
        if not fpath.exists():
            print(f"\n⚠ OMITIR  {fname}  (archivo no encontrado en {DOCS_DIR})")
            continue

        text  = fpath.read_text(encoding="utf-8")
        words = len(text.split())
        t0    = time.time()

        try:
            r     = diag.run(text, input_type=itype)
            tda_r = tda.attest(text)
            ms    = int((time.time() - t0) * 1000)
            le    = ledger.sign(text, r.manifold_score, r.overall_verdict, KAPPA_D)
            error = None
        except Exception as e:
            ms, r, tda_r, le = 0, None, None, None
            error = str(e)
            print(f"\n✗ ERROR  {fname}  — {error}")
            results["documentos"][fname] = {
                "descripcion": desc, "archivo": fname,
                "error": error, "pasa_kd": False,
            }
            continue

        pasa = r.manifold_score >= KAPPA_D
        delta = r.manifold_score - KAPPA_D

        results["documentos"][fname] = {
            "descripcion":       desc,
            "archivo":           fname,
            "tipo_input":        itype,
            "cantidad_palabras": words,
            "manifold_score":    r.manifold_score,
            "veredicto_manifold": r.manifold_verdict,
            "coherencia":        r.coherence_score,
            "topology_flag":     r.topology_flag,
            "riesgo_dominio":    r.domain_risk,
            "veredicto_global":  r.overall_verdict,
            "confianza":         r.confidence,
            "pasa_kd":           pasa,
            "delta_a_kd":        round(delta, 4),
            "tda_veredicto":     tda_r.verdict,
            "tda_h1_total":      tda_r.h1_total,
            "tda_h1_falsedades": tda_r.h1_structural_falsehoods,
            "tda_integridad":    tda_r.integrity_score,
            "tda_fallback":      tda_r.fallback_used,
            "forensic_ledger": {
                "entry_hash":    le.entry_hash,
                "doc_hash":      le.doc_hash,
                "timestamp":     le.timestamp_utc,
                "ots_payload":   le.ots_payload,
                "eth_calldata":  le.eth_calldata,
            },
            "tiempo_ms": ms,
            "error":     None,
        }

        flag = "✓ PASA" if pasa else "✗ FALLA"
        print(f"\n{flag}  {fname}")
        print(f"  {desc}")
        print(f"  palabras={words:4d}  score={r.manifold_score:.4f}"
              f"  (Δ a κD: {delta:+.4f})  global={r.overall_verdict}")
        print(f"  coherencia={r.coherence_score:.4f}  topology={r.topology_flag}"
              f"  riesgo_dominio={r.domain_risk:.4f}  confianza={r.confidence:.1%}")
        if ripser_ok:
            print(f"  TDA: {tda_r.verdict}  H1={tda_r.h1_total}"
                  f"  falsedades={tda_r.h1_structural_falsehoods}"
                  f"  integridad={tda_r.integrity_score:.4f}")
        else:
            print(f"  TDA: {tda_r.verdict} (H1 deshabilitado — instalar ripser para TDA completo)")
        print(f"  ledger: {le.entry_hash}")
        print(f"  tiempo: {ms}ms")

    # ── Diff Semántico ────────────────────────────────────────
    print("\n" + "=" * 68)
    print("DIFF SEMÁNTICO — ANÁLISIS DE DISTANCIA TOPOLÓGICA H1")
    print("=" * 68)

    for fa, fb, label in DIFF_PAIRS:
        pa, pb = DOCS_DIR / fa, DOCS_DIR / fb
        if not pa.exists() or not pb.exists():
            print(f"\n  OMITIR  {label}  (archivo no encontrado)")
            continue
        try:
            dr    = sdiff.compare_manifolds(pa.read_text(), pb.read_text())
            alerta = "⚠ ALERTA DE MANIPULACIÓN" if dr.manipulation_alert else "✓ sin alerta"
            print(f"\n  {label}")
            print(f"    Wasserstein H1: {dr.wasserstein_h1:.6f}"
                  f"  Bottleneck: {dr.bottleneck_h1:.6f}")
            print(f"    ISI: {dr.invariant_similarity_index:.6f}"
                  f"  Veredicto: {dr.verdict}  {alerta}")
            results["semantic_diff"][label] = {
                "doc_a":              fa,
                "doc_b":              fb,
                "wasserstein_h1":     dr.wasserstein_h1,
                "bottleneck_h1":      dr.bottleneck_h1,
                "isi":                dr.invariant_similarity_index,
                "veredicto":          dr.verdict,
                "alerta_manipulacion": dr.manipulation_alert,
                "delta": {
                    "ciclos_h1":         dr.delta.delta_h1_total,
                    "falsedades_struct":  dr.delta.delta_structural_faults,
                    "integridad":         dr.delta.delta_integrity,
                },
            }
        except Exception as e:
            print(f"\n  {label}  ERROR: {e}")

    # ── Resumen de corpus ─────────────────────────────────────
    docs_ok = {k: v for k, v in results["documentos"].items()
               if not v.get("error")}
    pasan   = sum(1 for v in docs_ok.values() if v["pasa_kd"])
    total   = len(docs_ok)
    tic     = pasan / total if total else 0
    scores  = [v["manifold_score"] for v in docs_ok.values()
               if v.get("manifold_score") is not None]
    riesgos = [v["riesgo_dominio"] for v in docs_ok.values()
               if v.get("riesgo_dominio") is not None]

    results["resumen_corpus"] = {
        "total_documentos":    total,
        "pasan_kd":            pasan,
        "fallan_kd":           total - pasan,
        "tic":                 round(tic, 4),
        "veredicto_corpus": (
            "ÍNTEGRO"     if tic >= 0.8 else
            "EN REVISIÓN" if tic >= 0.5 else
            "COMPROMETIDO"
        ),
        "score_promedio": round(sum(scores) / len(scores), 4) if scores else None,
        "rango_scores": {
            "min":    round(min(scores), 4) if scores else None,
            "max":    round(max(scores), 4) if scores else None,
            "spread": round(max(scores) - min(scores), 4) if scores else None,
        },
        "max_riesgo_dominio": round(max(riesgos), 4) if riesgos else None,
        "interpretacion": {
            "honestidad_manifold": (
                "Scores [0.50-0.54] son esperados cerca de κD=0.56. "
                "Sin sesgo binario — fricción estadística genuina."
            ),
            "pesos_300_palabras": (
                "entropía w=0.45 domina sobre topología w=0.25"
            ),
            "pesos_600_palabras": (
                "topología sube a w=0.40 — ciclos H1 cada vez más relevantes"
            ),
            "deteccion_redundante": (
                "LawAuditor señala riesgo_dominio>0 en docs manipulados "
                "aunque las diferencias de ManifoldScore sean pequeñas. "
                "Arquitectura radar + sonar: si uno no detecta, el otro sí."
            ),
        },
    }

    print("\n" + "=" * 68)
    print("RESUMEN DE CORPUS")
    print("=" * 68)
    rc = results["resumen_corpus"]
    print(f"  Documentos     : {total}")
    print(f"  Pasan κD={KAPPA_D} : {pasan}/{total}  (TIC = {tic:.1%})")
    print(f"  Veredicto      : {rc['veredicto_corpus']}")
    if scores:
        print(f"  Rango scores   : [{rc['rango_scores']['min']:.4f},"
              f" {rc['rango_scores']['max']:.4f}]"
              f"  spread={rc['rango_scores']['spread']:.4f}")
        print(f"  Score promedio : {rc['score_promedio']:.4f}")
    if riesgos:
        print(f"  Max riesgo dominio: {rc['max_riesgo_dominio']:.4f}"
              f"  (señal LawAuditor)")
    print()

    # ── Guardar salidas ───────────────────────────────────────
    json_out = RESULTS_DIR / "benchmark_results.json"
    with open(json_out, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)

    txt_out = RESULTS_DIR / "benchmark_summary.txt"
    _escribir_resumen(results, txt_out)

    print(f"✓ JSON → {json_out}")
    print(f"✓ TXT  → {txt_out}")
    return results


def _escribir_resumen(results: dict, path: Path) -> None:
    """Escribe resumen legible por humanos en archivo de texto."""
    rc = results.get("resumen_corpus", {})
    sm = results["suite_metadata"]
    lines = [
        "OMNI-SCANNER SEMÁNTICO v2.0 — RESUMEN DE BENCHMARK",
        "=" * 62,
        f"Ejecución : {sm['run_timestamp']}",
        f"κD        : {sm['kappa_d']}",
        f"Ripser    : {'SÍ — TDA H1 completo' if sm['ripser_available'] else 'NO — H1 deshabilitado (pip install ripser)'}",
        f"Modo TDA  : {sm['tda_mode']}",
        "",
        "RESULTADOS POR DOCUMENTO",
        "-" * 62,
    ]
    for fname, v in results.get("documentos", {}).items():
        if v.get("error"):
            lines += [f"ERROR  {fname}", f"       {v['error']}", ""]
            continue
        flag = "PASA" if v.get("pasa_kd") else "FALLA"
        lines += [
            f"{flag}  {fname}",
            f"       {v.get('descripcion', '')}",
            f"       palabras={v.get('cantidad_palabras','?')}"
            f"  score={v.get('manifold_score','?'):.4f}"
            f"  delta={v.get('delta_a_kd','?'):+.4f}"
            f"  veredicto={v.get('veredicto_manifold','?')}",
            f"       coherencia={v.get('coherencia','?'):.4f}"
            f"  topology={v.get('topology_flag','?')}"
            f"  riesgo_dominio={v.get('riesgo_dominio','?'):.4f}"
            f"  confianza={v.get('confianza','?'):.1%}",
            f"       TDA: {v.get('tda_veredicto','?')}  H1={v.get('tda_h1_total','?')}",
            f"       ledger: {v.get('forensic_ledger',{}).get('entry_hash','?')}",
            "",
        ]

    lines += ["DIFF SEMÁNTICO", "-" * 62]
    for label, v in results.get("semantic_diff", {}).items():
        alerta = "ALERTA" if v.get("alerta_manipulacion") else "limpio"
        lines += [
            f"  {label}",
            f"    Wasserstein={v.get('wasserstein_h1','?'):.6f}"
            f"  Bottleneck={v.get('bottleneck_h1','?'):.6f}"
            f"  ISI={v.get('isi','?'):.6f}",
            f"    Veredicto: {v.get('veredicto','?')}  [{alerta}]",
            "",
        ]

    lines += [
        "RESUMEN DE CORPUS",
        "-" * 62,
        f"  TIC     : {rc.get('tic', 0):.1%}"
        f"  ({rc.get('pasan_kd','?')}/{rc.get('total_documentos','?')})",
        f"  Veredicto: {rc.get('veredicto_corpus','?')}",
    ]
    if rc.get("rango_scores", {}).get("min") is not None:
        lines += [
            f"  Rango   : [{rc['rango_scores']['min']:.4f},"
            f" {rc['rango_scores']['max']:.4f}]"
            f"  spread={rc['rango_scores']['spread']:.4f}",
            f"  Promedio: {rc.get('score_promedio','?'):.4f}",
        ]
    lines += [
        "",
        "NOTA CIENTÍFICA",
        "-" * 62,
        sm.get("nota_cientifica", ""),
    ]
    path.write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    run_benchmark()
