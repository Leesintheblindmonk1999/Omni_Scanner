"""
interface/app.py — Omni-Scanner Semántico v3.0
──────────────────────────────────────────────
Módulos v3.0:
  · Módulo 4: Ghost Audit        (detector de degradación semántica)
  · Módulo 5: Shadow-Code        (análisis de autoría IA vs humano)
  · Ancla de Identidad           (embed PDF steganographic anchor)

Instalación:
    pip install streamlit plotly numpy networkx fpdf2 pyperclip
    pip install kaleido  # para exportar gráficos en PDF

Ejecución (desde la raíz del proyecto):
    streamlit run interface/app.py
"""
from __future__ import annotations
import sys
import os
import json
import math
import hashlib
import datetime
from pathlib import Path

# ── Path setup (ejecutar desde la raíz del proyecto) ──────────
ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

import streamlit as st
import numpy as np
import plotly.graph_objects as go
import plotly.express as px

# ── Imports del sistema ────────────────────────────────────────
from engines.full_diagnostic import FullDiagnostic, FullDiagnosticReport
from core.semantic_diff import SemanticDiff, SemanticDiffReport, quick_diff
from core.batch_auditor import BatchAuditor, BatchReport, FileResult
from core.stream_monitor import StreamMonitor, ContradictionProbe, StreamReport
from core.threshold_calibrator import ThresholdCalibrator, CalibrationResult
from logs.ledger_vanguard import LedgerVanguard, get_global_ledger
from utils.text_cleaner import TextCleaner
from utils.api_connector import ApiConnector
from protocols.metadata_origin import MetadataOrigin
from protocols import CONFIG

# ── Constants ─────────────────────────────────────────────────
K_DURANTE = CONFIG.stability_constant if CONFIG else 0.56
VAULT_DIR = ROOT / "logs" / "evidence_vault"
CSS_PATH  = Path(__file__).parent / "assets" / "style.css"
VERSION   = "v2.0 · ANEXA Ultra v4.0"

# ── Módulos v2.0 ───────────────────────────────────────────────
from interface.modules.clipboard_shield import (
    start_shield, stop_shield, is_active as shield_is_active,
    pyperclip_available,
)
from interface.modules.inverse_plagiarism import (
    InversePlagiarismDetector, PlagiarismReport
)
from reports.generators.genesis_certifier import GenesisCertifier

CERTIFIER  = GenesisCertifier()
PLAGIARISM = InversePlagiarismDetector()

# ── Módulos v3.0 ───────────────────────────────────────────────
from interface.modules.ghost_audit  import GhostAuditor,  GhostAuditReport
from interface.modules.shadow_code  import ShadowCodeDetector, ShadowCodeReport

GHOST_AUDITOR  = GhostAuditor()
SHADOW_DETECT  = ShadowCodeDetector()

# ── Módulo v3.1: Forensic Ledger ───────────────────────────────
from logs.forensic_ledger import (
    append_entry  as ledger_append,
    read_entries  as ledger_read,
    entry_count   as ledger_count,
    verify_integrity as ledger_verify,
)

# ══════════════════════════════════════════════════════════════
# CONFIGURACIÓN DE PÁGINA
# ══════════════════════════════════════════════════════════════

st.set_page_config(
    page_title="Omni-Scanner Semántico v1.0",
    page_icon="⬡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Cargar CSS ─────────────────────────────────────────────────
# Inyectar fuentes via <link> directo (más confiable que @import en Streamlit)
st.markdown("""
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Orbitron:wght@400;700;900&display=swap" rel="stylesheet">
""", unsafe_allow_html=True)

if CSS_PATH.exists():
    st.markdown(f"<style>{CSS_PATH.read_text(encoding='utf-8')}</style>",
                unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════
# CONSTANTES Y SINGLETONS
# ══════════════════════════════════════════════════════════════

K_D = CONFIG.stability_constant if CONFIG else 0.56
NOISE_THRESHOLD = CONFIG.noise_gap_threshold if CONFIG else 0.15
PLAGIARISM_THRESHOLD = CONFIG.plagiarism_threshold if CONFIG else 0.85

CLEANER    = TextCleaner()
# min_tokens reducido a 20 para la interfaz — textos cortos como contratos
# breves deben analizarse. El núcleo sigue siendo configurable via config.yaml.
from core.entropy_analyzer import EntropyAnalyzer as _EA
from core.multifractal_processor import MultifractalProcessor as _MFP
from core.manifold_engine import ManifoldEngine as _ME
from core.topology_mapper import TopologyMapper as _TM
_me = _ME(K_DURANTE=K_D)
_me._entropy    = _EA(noise_gap_threshold=NOISE_THRESHOLD, min_tokens=20)
_me._fractal    = _MFP(stability_threshold=K_D, min_series_len=20)
_topo = _TM()
if hasattr(_topo, 'min_sentences'):
    _topo.min_sentences = 2
_me._topology = _topo
DIAGNOSTIC = FullDiagnostic(stability_threshold=K_D)
DIAGNOSTIC.manifold = _me
CONNECTOR  = ApiConnector(base_dir=str(ROOT))
SIGNER     = MetadataOrigin()

# ══════════════════════════════════════════════════════════════
# SESSION STATE
# ══════════════════════════════════════════════════════════════

def _init_state():
    defaults = {
        "report":            None,
        "signed_report":     None,
        "raw_text":          "",
        "clean_text":        "",
        "scan_log":          [],
        "sealed":            False,
        "scan_count":        0,
        # v2.0
        "cert_path":         None,       # Path al último PDF generado
        "cert_bytes":        None,       # Bytes del PDF para descarga
        "clip_alerts":       [],         # Alertas del Clipboard Shield
        "clip_shield_on":    False,      # Estado del shield
        "clip_stop_event":   None,       # threading.Event para detenerlo
        "plag_report":       None,       # Último PlagiarismReport
        "plag_code":         "",         # Código sospechoso analizado
        # v3.0
        "ghost_report":      None,       # GhostAuditReport del texto actual
        "shadow_report":     None,       # ShadowCodeReport
        "shadow_code":       "",         # Código analizado por Shadow
        "anchor_data":       None,       # Payload del Ancla de Identidad
        # v5.5 wizard
        "wizard_done":       False,      # True una vez completado el onboarding
        "node_lens":         "FULL",     # MACHINE | HUMAN | FULL
        "kd_calibrated":     0.56,       # κD calibrado por el usuario
        "sigma_threshold":   0.05,       # umbral σ para degradación manifold
        "entropy_sens":      0.15,       # sensibilidad de entropía (clipboard)
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

_init_state()

# ══════════════════════════════════════════════════════════════
# WIZARD DE INICIALIZACIÓN v5.5 (se ejecuta solo en primer acceso)
# ══════════════════════════════════════════════════════════════

if not st.session_state["wizard_done"]:
    st.markdown("""
    <style>
    .stApp { background: #000 !important; }
    .wz-title { text-align:center; font-family:Orbitron,monospace;
                font-size:1.55rem; color:#FFB100; letter-spacing:.25em;
                text-shadow:0 0 18px rgba(255,177,0,.55);
                padding:2.5rem 0 .4rem; }
    .wz-sub   { text-align:center; font-size:.7rem;
                color:rgba(255,177,0,.4); letter-spacing:.15em;
                margin-bottom:2rem; }
    .wz-box   { background:#0D0D0D; border:1px solid rgba(255,177,0,.2);
                border-radius:6px; padding:1.4rem 1.6rem; margin-bottom:1rem; }
    .wz-label { font-family:Orbitron,monospace; font-size:.75rem;
                color:#FFB100; letter-spacing:.12em; margin-bottom:.7rem; }
    </style>
    """, unsafe_allow_html=True)

    st.markdown('<div class="wz-title">⬡ OMNI-SCANNER SEMÁNTICO v5.5</div>',
                unsafe_allow_html=True)
    st.markdown('<div class="wz-sub">INICIALIZACIÓN DE SESIÓN · CALIBRACIÓN DE PARÁMETROS</div>',
                unsafe_allow_html=True)

    _, wzcol, _ = st.columns([1, 2, 1])
    with wzcol:

        # ── PASO 1 ───────────────────────────────────────────
        st.markdown('<div class="wz-box"><div class="wz-label">PASO 1 · IDENTIFICACIÓN DE NODO</div>',
                    unsafe_allow_html=True)
        node_map = {
            "🖥  MACHINE — Manifold · Shadow-Code · Gaslighting": "MACHINE",
            "👤  HUMAN  — Contratos · NDAs · Delay Tactics":      "HUMAN",
            "⬡  FULL   — Pipeline completo (todos los módulos)":  "FULL",
        }
        node_choice = st.radio("nodo", list(node_map.keys()),
                               index=2, label_visibility="collapsed")
        st.markdown('</div>', unsafe_allow_html=True)

        # ── PASO 2 ───────────────────────────────────────────
        st.markdown('<div class="wz-box"><div class="wz-label">PASO 2 · CALIBRACIÓN DE PARÁMETROS</div>',
                    unsafe_allow_html=True)
        c1, c2 = st.columns(2)
        with c1:
            kd_val = st.slider("κD — Constante de estabilidad",
                               0.40, 0.80, 0.56, 0.01,
                               help="Umbral ManifoldEngine. Referencia: 0.56")
        with c2:
            sigma_pct = st.slider("σ — Umbral de degradación (%)",
                                  1, 30, 5, 1)
            sigma_val = sigma_pct / 100.0
        c3, _ = st.columns(2)
        with c3:
            ent_sens = st.slider("Sensibilidad entropía (Clipboard)",
                                 0.05, 0.50, 0.15, 0.01)

        thr2 = sigma_val * 3
        st.markdown(f"""
        <div style="font-size:.62rem;color:rgba(255,177,0,.5);
                    font-family:Share Tech Mono,monospace;
                    line-height:2;margin-top:.5rem;">
        σ &lt; {sigma_val:.0%} &nbsp;→&nbsp;
        <span style="color:#00FF88">ESTABILIDAD SOBERANA</span><br>
        σ {sigma_val:.0%}–{thr2:.0%} &nbsp;→&nbsp;
        <span style="color:#FFB100">DEGRADACIÓN</span><br>
        σ &gt; {thr2:.0%} &nbsp;→&nbsp;
        <span style="color:#FF2D2D">COLAPSO DEL MANIFOLD</span>
        </div>
        """, unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)

        # ── PASO 3 ───────────────────────────────────────────
        st.markdown('<div class="wz-box"><div class="wz-label">PASO 3 · CONFIRMAR E INICIAR</div>',
                    unsafe_allow_html=True)
        st.markdown(f"""
        <div style="font-size:.68rem;color:rgba(255,177,0,.65);
                    font-family:Share Tech Mono,monospace;line-height:2;">
        NODO &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {node_map[node_choice]}<br>
        κD &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {kd_val}<br>
        σ UMBRAL &nbsp; {sigma_val:.0%}<br>
        ENTROPÍA &nbsp; {ent_sens}<br>
        PROTOCOLO ANEXA ULTRA v4.0
        </div>
        """, unsafe_allow_html=True)
        if st.button("⬡  INICIAR SESIÓN DE AUDITORÍA",
                     use_container_width=True, type="primary"):
            st.session_state.update({
                "wizard_done":     True,
                "node_lens":       node_map[node_choice],
                "kd_calibrated":   kd_val,
                "sigma_threshold": sigma_val,
                "entropy_sens":    ent_sens,
            })
            # Recalibrar motores en vivo
            try:
                if hasattr(_me._entropy, '_noise_gap_threshold'):
                    _me._entropy._noise_gap_threshold = ent_sens
                if hasattr(_me._fractal, '_stability_threshold'):
                    _me._fractal._stability_threshold = kd_val
            except Exception:
                pass
            st.rerun()
        st.markdown('</div>', unsafe_allow_html=True)

    st.stop()  # No renderizar nada más hasta completar el wizard


# ══════════════════════════════════════════════════════════════
# HELPERS DE VISUALIZACIÓN
# ══════════════════════════════════════════════════════════════

def _verdict_css(verdict: str) -> str:
    return {
        "CLEAR":     "verdict-clear",
        "REVIEW":    "verdict-review",
        "HIGH_RISK": "verdict-highrisk",
    }.get(verdict, "verdict-review")


def _badge(text: str, kind: str = "review") -> str:
    return f'<span class="badge badge-{kind}">{text}</span>'


def _metric_card(label: str, value: str, delta: str = "",
                 kind: str = "const") -> str:
    return f"""
    <div class="metric-card">
        <div class="metric-label">{label}</div>
        <div class="metric-value {kind}">{value}</div>
        {"<div class='metric-delta'>" + delta + "</div>" if delta else ""}
    </div>
    """


def _stability_bar(score: float, risk: bool = False) -> str:
    pct = max(0, min(100, score * 100))
    cls = "risk" if risk else ""
    return f"""
    <div class="stability-bar">
        <div class="stability-fill {cls}" style="width:{pct:.1f}%"></div>
    </div>
    <div style="font-size:0.65rem;color:var(--text-dim);margin-top:2px;">
        Score: {score:.4f}
    </div>
    """


def _log(msg: str, level: str = "warn") -> None:
    ts = datetime.datetime.now().strftime("%H:%M:%S")
    st.session_state["scan_log"].append(
        f'<span class="log-{level}">[{ts}] {msg}</span>'
    )


# ══════════════════════════════════════════════════════════════
# GRÁFICOS PLOTLY
# ══════════════════════════════════════════════════════════════

AMBER = "#FFB100"
RED   = "#FF2D2D"
GREEN = "#00FF88"
BG    = "#000000"
PANEL = "#0D0D0D"

_PLOTLY_LAYOUT = dict(
    paper_bgcolor=BG,
    plot_bgcolor=PANEL,
    font=dict(family="IBM Plex Mono, monospace", color=AMBER, size=10),
    margin=dict(l=10, r=10, t=40, b=10),
)


def build_topology_3d(report: FullDiagnosticReport) -> go.Figure:
    """
    Superficie 3D que representa la topología semántica del espacio latente.
    Ejes: Entropía × Dimensión Fractal × ManifoldScore
    Zonas de Mala Fe (score < 0.3) pulsantes en rojo.
    """
    score = report.manifold_score if not math.isnan(report.manifold_score) else 0.0
    if score < 0 or score == -1.0:
        score = 0.0
    coherence = max(report.coherence_score, 0.0)
    risk = max(report.domain_risk, 0.0)

    # Grid del manifold
    x = np.linspace(0, 1, 40)
    y = np.linspace(0, 2, 40)
    X, Y = np.meshgrid(x, y)

    # Superficie = proyección gaussiana del punto de análisis real
    # centrada en (entropy_norm, higuchi_dim_norm)
    raw_reports = report.raw_reports
    try:
        manifold_txt = raw_reports.get("manifold_summary", "")
        higuchi = float(
            next((l.split(":")[1].strip().split()[0]
                  for l in manifold_txt.split("\n") if "Higuchi" in l), "1.5")
        )
    except Exception:
        higuchi = 1.5

    cx = min(risk, 1.0)
    cy = min(higuchi / 2.0, 1.0) * 2

    # Z: siempre genera relieve visual usando el riesgo y la dimensión fractal
    # aunque el manifold_score sea bajo. Mínimo de amplitud garantizado.
    sigma = 0.35
    rng = np.random.default_rng(42)
    Z_gauss = np.exp(-((X - cx)**2 + (Y - cy)**2) / (2 * sigma**2))
    Z_noise = 0.12 * rng.standard_normal(X.shape)
    # Amplitud mínima 0.35 para que la superficie nunca quede plana
    amplitude = max(score, 0.35) + risk * 0.4
    Z = Z_gauss * amplitude + Z_noise * 0.4 + 0.1

    # Picos de mala fe: si hay hallazgos críticos, insertar spikes rojos
    domain_data = raw_reports.get("domain", {})
    n_findings  = len(domain_data.get("critical_findings", []))
    if n_findings > 0:
        for i in range(min(n_findings, 3)):
            px_ = rng.uniform(0.6, 0.95)
            py_ = rng.uniform(0.8, 1.6)
            spike = 0.5 * np.exp(-((X - px_)**2 + (Y - py_)**2) / 0.02)
            Z += spike

    # Color: rojo en zonas de mala fe (Z alto + riesgo alto)
    colorscale = [
        [0.0,  "#001A00"],
        [0.35, "#1A3300"],
        [0.55, AMBER],
        [0.80, "#FF6600"],
        [1.0,  RED],
    ] if risk > 0.3 else [
        [0.0,  "#001A00"],
        [0.40, "#003311"],
        [0.70, AMBER],
        [1.0,  "#FFD966"],
    ]

    fig = go.Figure(data=[go.Surface(
        x=X, y=Y, z=Z,
        colorscale=colorscale,
        showscale=False,
        opacity=0.88,
        contours=dict(
            z=dict(show=True, usecolormap=True,
                   highlightcolor=RED if risk > 0.3 else AMBER,
                   project_z=True)
        ),
    )])

    # Punto de análisis real
    fig.add_trace(go.Scatter3d(
        x=[cx], y=[cy], z=[score],
        mode="markers+text",
        marker=dict(size=8, color=RED if risk > 0.3 else GREEN,
                    symbol="diamond",
                    line=dict(color=AMBER, width=2)),
        text=[f"κD={K_D}"],
        textfont=dict(color=AMBER, size=9),
    ))

    # Plano de estabilidad κD
    fig.add_trace(go.Surface(
        x=X, y=Y,
        z=np.full_like(Z, K_D),
        colorscale=[[0, "rgba(255,177,0,0.04)"], [1, "rgba(255,177,0,0.04)"]],
        showscale=False, opacity=0.25,
    ))

    fig.update_layout(
        **_PLOTLY_LAYOUT,
        title=dict(text="TOPOLOGÍA DEL ESPACIO LATENTE", font=dict(size=11, color=AMBER)),
        scene=dict(
            xaxis=dict(title="RIESGO / ENTROPÍA", color=AMBER,
                       gridcolor="rgba(255,177,0,0.15)", showbackground=False),
            yaxis=dict(title="DIM. FRACTAL", color=AMBER,
                       gridcolor="rgba(255,177,0,0.15)", showbackground=False),
            zaxis=dict(title="MANIFOLD SCORE", color=AMBER,
                       gridcolor="rgba(255,177,0,0.15)", showbackground=False,
                       range=[0, 1]),
            bgcolor=BG,
            camera=dict(eye=dict(x=1.4, y=1.4, z=0.9)),
        ),
        height=440,
    )
    return fig


def build_hausdorff_chart(report: FullDiagnosticReport) -> go.Figure:
    """
    Gráfico de rugosidad semántica: simula la curva de dimensión de Hausdorff
    a través de escalas, usando los datos reales del reporte.
    """
    raw = report.raw_reports
    try:
        manifold_txt = raw.get("manifold_summary", "")
        higuchi = float(
            next((l.split(":")[1].strip().split()[0]
                  for l in manifold_txt.split("\n") if "Higuchi" in l), "1.5")
        )
    except Exception:
        higuchi = 1.5

    # Curva log-log simulada basada en la dimensión real
    rng = np.random.default_rng(42)
    scales = np.logspace(-1, 1, 30)
    # N(s) ~ s^(-D)  con ruido realista
    counts = scales ** (-higuchi) * (1 + 0.06 * rng.standard_normal(30))
    counts = np.clip(counts, 0.01, None)

    # Referencia: dimensión ideal 1.58
    ref_counts = scales ** (-1.58)

    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=np.log(1 / scales), y=np.log(counts),
        mode="lines+markers",
        name=f"Hausdorff estimado (D={higuchi:.3f})",
        line=dict(color=AMBER, width=2),
        marker=dict(size=4, color=AMBER),
    ))

    fig.add_trace(go.Scatter(
        x=np.log(1 / scales), y=np.log(ref_counts),
        mode="lines",
        name="Referencia (D=1.58)",
        line=dict(color="rgba(255,177,0,0.30)", width=1, dash="dot"),
    ))

    # Zona de estabilidad κD
    fig.add_hrect(
        y0=np.log(scales[0] ** (-K_D)) * 0.85,
        y1=np.log(scales[0] ** (-K_D)) * 1.15,
        fillcolor="rgba(255,177,0,0.04)",
        line_width=0,
        annotation_text=f"κD={K_D} ± 15%",
        annotation_font=dict(color=AMBER, size=8),
    )

    fig.update_layout(
        **_PLOTLY_LAYOUT,
        title=dict(text="RUGOSIDAD SEMÁNTICA DE HAUSDORFF", font=dict(size=11, color=AMBER)),
        xaxis=dict(title="log(1/escala)", color=AMBER,
                   gridcolor="rgba(255,177,0,0.10)", showgrid=True),
        yaxis=dict(title="log(N(s))", color=AMBER,
                   gridcolor="rgba(255,177,0,0.10)", showgrid=True),
        legend=dict(font=dict(size=8, color=AMBER),
                    bgcolor="rgba(0,0,0,0.6)", bordercolor=AMBER, borderwidth=1),
        height=300,
    )
    return fig


def build_risk_radar(report: FullDiagnosticReport) -> go.Figure:
    """Radar de señales de riesgo por dimensión."""
    domain = report.raw_reports.get("domain", {})

    legal_risk    = domain.get("legal_risk_score",    report.domain_risk)
    gaslighting   = domain.get("gaslighting_score",   domain.get("risk_score", 0))
    coherence_inv = 1.0 - report.coherence_score
    manifold_gap  = 1.0 - max(report.manifold_score, 0)
    plagiarism    = domain.get("plagiarism_risk", 0) / 100 if "plagiarism_risk" in domain else 0

    categories = ["LEGAL", "GASLIGHTING", "FRAGMENTACIÓN", "ANOMALÍA\nMANIFOLD", "PLAGIO"]
    values = [legal_risk, gaslighting, coherence_inv, manifold_gap, plagiarism]
    values_closed = values + [values[0]]
    categories_closed = categories + [categories[0]]

    color = RED if report.overall_verdict == "HIGH_RISK" else AMBER

    fig = go.Figure(go.Scatterpolar(
        r=values_closed,
        theta=categories_closed,
        fill="toself",
        fillcolor=f"rgba(255,177,0,0.08)" if color == AMBER else "rgba(255,45,45,0.10)",
        line=dict(color=color, width=2),
        marker=dict(color=color, size=6),
    ))

    fig.update_layout(
        **_PLOTLY_LAYOUT,
        title=dict(text="SEÑALES DE RIESGO", font=dict(size=11, color=AMBER)),
        polar=dict(
            bgcolor=PANEL,
            radialaxis=dict(visible=True, range=[0, 1],
                            color=AMBER, gridcolor="rgba(255,177,0,0.12)",
                            tickfont=dict(size=8)),
            angularaxis=dict(color=AMBER, gridcolor="rgba(255,177,0,0.15)",
                             tickfont=dict(size=8)),
        ),
        height=320,
    )
    return fig


# ══════════════════════════════════════════════════════════════
# SIDEBAR
# ══════════════════════════════════════════════════════════════

with st.sidebar:
    st.markdown("""
    <div style="font-size:0.65rem;color:rgba(255,177,0,0.4);
                letter-spacing:0.18em;border-bottom:1px solid rgba(255,177,0,0.2);
                padding-bottom:0.6rem;margin-bottom:1rem;">
    ⬡ SISTEMA / CONFIGURACIÓN
    </div>
    """, unsafe_allow_html=True)

    input_type = st.selectbox(
        "TIPO DE DOCUMENTO",
        options=["legal", "code", "discourse", "finance", "generic"],
        index=0,
        help="Selecciona el motor de análisis de dominio."
    )

    st.markdown("---")
    st.markdown(f"""
    <div style="font-size:0.65rem;color:rgba(255,177,0,0.4);letter-spacing:0.14em;">
    PARÁMETROS ACTIVOS
    </div>
    <div style="font-size:0.72rem;color:rgba(255,177,0,0.7);margin-top:0.5rem;line-height:1.9;">
    κD (estabilidad)  <strong style="color:#FFB100">{K_D}</strong><br>
    Gap máximo        <strong style="color:#FFB100">{NOISE_THRESHOLD}</strong><br>
    Umbral plagio     <strong style="color:#FFB100">{PLAGIARISM_THRESHOLD}</strong><br>
    Protocolo         <strong style="color:#FFB100">ANEXA Ultra v4.0</strong>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown(f"""
    <div style="font-size:0.65rem;color:rgba(255,177,0,0.4);letter-spacing:0.14em;">
    ESTADO DE SESIÓN
    </div>
    <div style="font-size:0.72rem;color:rgba(255,177,0,0.6);margin-top:0.5rem;line-height:1.9;">
    Escaneos         <strong style="color:#FFB100">{st.session_state['scan_count']}</strong><br>
    Sellados         <strong style="color:#FFB100">{'SÍ' if st.session_state['sealed'] else 'NO'}</strong>
    </div>
    """, unsafe_allow_html=True)

    if st.button("⟳  RESETEAR SESIÓN"):
        for k in list(st.session_state.keys()):
            del st.session_state[k]
        _init_state()
        st.rerun()

    # ── MÓDULO 1: Clipboard Shield ──────────────────────────────
    st.markdown("---")
    st.markdown(f"""
    <div style="font-size:0.65rem;color:rgba(255,177,0,0.4);letter-spacing:0.14em;">
    CLIPBOARD SHIELD v2.0
    </div>
    """, unsafe_allow_html=True)

    shield_on  = st.session_state.get("clip_shield_on", False)
    shield_avail = pyperclip_available()

    if not shield_avail:
        st.markdown("""
        <div style="font-size:0.65rem;color:rgba(255,100,0,0.7);margin-top:0.4rem;">
        ⚠ Instalar pyperclip:<br><code>pip install pyperclip</code>
        </div>
        """, unsafe_allow_html=True)
    else:
        _shield_label = "⬛ DETENER SHIELD" if shield_on else "⬡ ACTIVAR SHIELD"
        if st.button(_shield_label, use_container_width=True):
            if shield_on:
                stop_ev = st.session_state.get("clip_stop_event")
                if stop_ev:
                    stop_shield(stop_ev)
                st.session_state["clip_shield_on"]  = False
                st.session_state["clip_stop_event"] = None
                _log("Clipboard Shield desactivado.", "dim")
            else:
                alerts_queue = st.session_state["clip_alerts"]
                stop_ev = start_shield(alerts_queue, threshold=NOISE_THRESHOLD, poll_interval=2.5)
                st.session_state["clip_shield_on"]  = True
                st.session_state["clip_stop_event"] = stop_ev
                _log("Clipboard Shield activado. Monitoreando entropía...", "ok")
            st.rerun()

        _status_color = "#00FF88" if shield_on else "rgba(255,177,0,0.3)"
        _status_text  = "ACTIVO" if shield_on else "INACTIVO"
        st.markdown(f"""
        <div style="font-size:0.65rem;color:{_status_color};
                    letter-spacing:0.1em;margin-top:0.3rem;">
        ● {_status_text}
        {"· Gap umbral: " + str(NOISE_THRESHOLD) if shield_on else ""}
        </div>
        """, unsafe_allow_html=True)

        if st.session_state.get("clip_alerts"):
            nalerts = len(st.session_state["clip_alerts"])
            st.markdown(f"""
            <div style="font-size:0.65rem;color:#FF2D2D;animation:pulse 1s infinite;">
            ⚠ {nalerts} alerta(s) pendiente(s)
            </div>
            """, unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════
# HEADER PRINCIPAL
# ══════════════════════════════════════════════════════════════

st.markdown("""
<div class="omni-header">
  <div class="omni-title flicker">⬡ OMNI-SCANNER SEMÁNTICO v3.0</div>
  <div class="omni-subtitle cursor">
    SISTEMA DE AUDITORÍA SEMÁNTICA · FÍSICA DE LA INFORMACIÓN · NODO DE ORIGEN ACTIVO
  </div>
</div>
""", unsafe_allow_html=True)

# ── Clipboard Shield: mostrar alertas pendientes ──────────────
_clip_alerts: list[dict] = st.session_state.get("clip_alerts", [])
if _clip_alerts:
    for _alert in _clip_alerts:
        _level = _alert.get("level", "MEDIUM")
        _gap   = _alert.get("gap", 0)
        _prev  = _alert.get("preview", "")[:60]
        _msg   = f"⚠ CLIPBOARD SHIELD: Gap entrópico {_gap:.3f} [{_level}] · {_prev}..."
        st.toast(_msg, icon="⚠")
    # Limpiar después de mostrar (evitar spam en reruns)
    st.session_state["clip_alerts"] = []


# ── Monitor de Invarianza (KPI row) ───────────────────────────
report: FullDiagnosticReport | None = st.session_state["report"]

gaslighting_val = "—"
gaslighting_kind = "const"
if report:
    domain = report.raw_reports.get("domain", {})
    gas = domain.get("gaslighting_score", domain.get("risk_score", None))
    if gas is not None:
        gaslighting_val = f"{gas:.4f}"
        gaslighting_kind = "risk" if gas > 0.3 else ("warn" if gas > 0.1 else "ok")

nist_status = "SINCRONIZADO" if report else "EN ESPERA"
nist_kind   = ("ok" if report and report.overall_verdict == "CLEAR"
               else "risk" if report and report.overall_verdict == "HIGH_RISK"
               else "const")

c1, c2, c3 = st.columns(3)
with c1:
    st.markdown(_metric_card("κD — CONSTANTE DE ESTABILIDAD", f"{K_D}", "Invarianza semántica", "const"),
                unsafe_allow_html=True)
with c2:
    st.markdown(_metric_card("ÍNDICE DE GASLIGHTING", gaslighting_val,
                             "Manipulación discursiva detectada", gaslighting_kind),
                unsafe_allow_html=True)
with c3:
    st.markdown(_metric_card("ESTADO NIST/TAD", nist_status,
                             f"Protocolo: ANEXA Ultra v4.0", nist_kind),
                unsafe_allow_html=True)

st.markdown("<div style='margin-top:1.4rem'></div>", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════
# TABS PRINCIPALES
# ══════════════════════════════════════════════════════════════

tab_scan, tab_viz, tab_vault, tab_plag, tab_shadow, tab_ledger, tab_diff, tab_batch, tab_shield, tab_calibrate, tab_ledger2, tab_log = st.tabs([
    "⬡  TERMINAL DE AUDITORÍA",
    "◈  ESPACIO LATENTE",
    "⬥  BÓVEDA DE EVIDENCIA",
    "⬣  INYECTOR DE ORDEN",
    "◉  SHADOW-CODE",
    "▦  HISTORIAL DE INVARIANZA",
    "◑  DIFF SEMÁNTICO",
    "≣  AUDITORÍA MASIVA",
    "⬡  ESCUDO DE INVARIANZA",
    "⚙  CALIBRACIÓN κD",
    "⛓  FORENSIC LEDGER",
    "⬦  LOG DE SISTEMA",
])


# ══════════════════════════════════════════════════════════════
# TAB 1: TERMINAL DE AUDITORÍA
# ══════════════════════════════════════════════════════════════

with tab_scan:
    col_input, col_result = st.columns([1, 1], gap="medium")

    with col_input:
        st.markdown("""
        <div class="section-title"><span>▸</span> ENTRADA DE DATOS</div>
        """, unsafe_allow_html=True)

        upload_mode = st.radio(
            "Fuente",
            ["Archivo", "Texto directo"],
            horizontal=True,
            label_visibility="collapsed",
        )

        raw_text = ""

        if upload_mode == "Archivo":
            uploaded = st.file_uploader(
                "Arrastre aquí su documento",
                type=["txt", "py", "md", "json", "csv"],
                label_visibility="collapsed",
            )
            if uploaded:
                try:
                    raw_text = uploaded.read().decode("utf-8", errors="replace")
                    st.markdown(
                        f'<div class="hash-display"><strong>Archivo:</strong> {uploaded.name} '
                        f'({len(raw_text):,} chars)</div>',
                        unsafe_allow_html=True,
                    )
                except Exception as e:
                    st.error(f"Error leyendo archivo: {e}")
        else:
            raw_text = st.text_area(
                "Ingrese texto a auditar",
                height=200,
                placeholder="Pegue aquí el contrato, código o discurso a analizar...",
                label_visibility="collapsed",
            )

            # ── Ghost Audit: análisis inline en tiempo real ────────
            if raw_text and len(raw_text.strip()) > 40:
                _ghost = GHOST_AUDITOR.analyze(raw_text)
                st.session_state["ghost_report"] = _ghost
                if _ghost.alert_level != "SALUDABLE" and _ghost.alert_level != "INSUFICIENTE":
                    _ghost_colors = {
                        "DEGRADACIÓN CRÍTICA": "#FF2D2D",
                        "RIESGO SEMÁNTICO":    "#FF6600",
                        "POTENCIAL REDUCIDO":  "#FFB100",
                    }
                    _gc = _ghost_colors.get(_ghost.alert_level, "#FFB100")
                    st.markdown(f"""
                    <div style="border-left:3px solid {_gc};padding:.5rem .8rem;
                                margin:.4rem 0;background:rgba(255,45,45,0.05);">
                        <span style="color:{_gc};font-family:Orbitron,monospace;
                                     font-size:.7rem;letter-spacing:.1em;">
                        ⚠ {_ghost.alert_level}
                        </span>
                        <span style="color:rgba(255,177,0,0.6);font-size:.65rem;margin-left:.5rem;">
                        Score: {_ghost.overall_score:.3f} · Buzzwords: {len(_ghost.buzzwords_found)}
                        {"· Templates: " + str(len(_ghost.template_hits)) if _ghost.template_hits else ""}
                        </span>
                        <br><span style="color:rgba(255,177,0,0.45);font-size:.62rem;">
                        {_ghost.recommendation[:120]}
                        </span>
                    </div>
                    """, unsafe_allow_html=True)

        ref_text = ""
        if input_type == "code":
            with st.expander("◈ Prior Art / Código de Referencia"):
                ref_upload = st.file_uploader("Referencia", type=["py", "txt"],
                                              key="ref_upload")
                if ref_upload:
                    ref_text = ref_upload.read().decode("utf-8", errors="replace")
                    st.caption(f"Referencia: {ref_upload.name}")

        st.markdown("<div style='margin-top:0.8rem'></div>", unsafe_allow_html=True)

        btn_scan = st.button("⬡  EJECUTAR ESCANEO MULTIFRACTAL", use_container_width=True)

        if btn_scan:
            if not raw_text.strip():
                st.warning("No hay contenido para analizar.")
            else:
                with st.spinner("Analizando espacio latente..."):
                    try:
                        _log("Iniciando limpieza léxica...", "dim")
                        clean = CLEANER.clean_for_analysis(raw_text)
                        meta = CLEANER.extract_metadata(clean)
                        st.session_state["raw_text"]   = raw_text
                        st.session_state["clean_text"] = clean

                        _log(f"Tokens limpios: {len(clean.split())} | "
                             f"Refs. legales: {len(meta['legal_references'])}", "dim")

                        _log("Ejecutando ManifoldEngine + EntropíaAnalyzer...", "warn")
                        result = DIAGNOSTIC.run(clean, input_type=input_type,
                                                reference_code=ref_text)

                        st.session_state["report"]  = result
                        st.session_state["sealed"]  = False
                        st.session_state["scan_count"] += 1

                        CONNECTOR.log_scan(result.__dict__)

                        level = {"CLEAR": "ok", "REVIEW": "warn",
                                 "HIGH_RISK": "risk"}.get(result.overall_verdict, "warn")
                        ms_display = (
                            f"{result.manifold_score:.4f}"
                            if result.manifold_score not in (float("nan"), -1.0)
                            and result.manifold_score == result.manifold_score
                            else "INSUF."
                        )
                        _log(f"Veredicto: {result.overall_verdict} | "
                             f"ManifoldScore: {ms_display}", level)
                        _log(f"Confianza: {result.confidence:.1%} | "
                             f"Tipo: {input_type}", "dim")

                        st.rerun()
                    except Exception as e:
                        _log(f"ERROR: {e}", "risk")
                        st.error(f"Error durante el análisis: {e}")

    with col_result:
        st.markdown("""
        <div class="section-title"><span>▸</span> VEREDICTO</div>
        """, unsafe_allow_html=True)

        if report is None:
            st.markdown("""
            <div style="color:rgba(255,177,0,0.25);font-size:0.75rem;
                        text-align:center;padding:3rem 1rem;
                        border:1px dashed rgba(255,177,0,0.15);">
            SISTEMA EN ESPERA<br>
            <span style="font-size:0.65rem">Cargue un documento y ejecute el escaneo</span>
            </div>
            """, unsafe_allow_html=True)
        else:
            # Banner de veredicto
            v_css = _verdict_css(report.overall_verdict)
            v_icons = {"CLEAR": "✓", "REVIEW": "⚡", "HIGH_RISK": "⚠"}
            st.markdown(f"""
            <div class="verdict-banner {v_css}">
                {v_icons.get(report.overall_verdict,'?')} &nbsp;
                {report.overall_verdict}
            </div>
            """, unsafe_allow_html=True)

            st.markdown("<div style='margin-top:1rem'></div>", unsafe_allow_html=True)

            # Métricas secundarias
            mc1, mc2 = st.columns(2)
            with mc1:
                ms_val = report.manifold_score
                ms_valid = ms_val not in (-1.0,) and ms_val == ms_val  # not NaN, not -1
                ms_str = f"{ms_val:.4f}" if ms_valid else "INSUF."
                kind = ("ok" if ms_valid and ms_val > 0.6
                        else "risk" if ms_valid and ms_val < 0.3
                        else "const")
                st.markdown(_metric_card(
                    "MANIFOLD SCORE", ms_str,
                    report.manifold_verdict, kind),
                    unsafe_allow_html=True)
            with mc2:
                coh_kind = "ok" if report.coherence_score > 0.5 else "risk"
                st.markdown(_metric_card(
                    "COHERENCIA TOPOLÓGICA",
                    f"{report.coherence_score:.4f}",
                    report.topology_flag, coh_kind),
                    unsafe_allow_html=True)

            st.markdown("<div style='margin-top:0.8rem'></div>", unsafe_allow_html=True)

            # Barra de estabilidad
            ms = report.manifold_score if not math.isnan(report.manifold_score) else 0.0
            st.markdown(
                f'<div class="metric-label">ÍNDICE DE ESTABILIDAD SEMÁNTICA</div>'
                + _stability_bar(ms, risk=report.overall_verdict == "HIGH_RISK"),
                unsafe_allow_html=True,
            )

            st.markdown("<div style='margin-top:0.8rem'></div>", unsafe_allow_html=True)

            # Detalle del análisis Manifold
            with st.expander("◈ DETALLE MANIFOLD + ENTROPÍA"):
                summary = report.raw_reports.get("manifold_summary", "Sin datos")
                st.markdown(
                    f'<div class="terminal-output">{summary}</div>',
                    unsafe_allow_html=True,
                )

            # Detalle dominio — con limpieza de regex crudas
            with st.expander("◈ DETALLE DE DOMINIO"):
                import re as _re
                domain_raw = report.raw_reports.get("domain", {})

                def _clean_regex(val):
                    """Convierte patrones regex a texto legible."""
                    if isinstance(val, str):
                        return _re.sub(r'\\s\+', ' ', _re.sub(r'\\b|\\s\*|\(\?i\)', '', val))
                    if isinstance(val, list):
                        return [_clean_regex(v) for v in val]
                    if isinstance(val, dict):
                        return {k: _clean_regex(v) for k, v in val.items()}
                    return val

                domain_clean = _clean_regex(domain_raw)

                # Display elegante por secciones en lugar de st.json crudo
                findings = domain_clean.get("critical_findings", [])
                traps    = domain_clean.get("trap_clause_hits", [])
                coerce   = domain_clean.get("coercion_hits", [])
                verdict  = domain_clean.get("verdict", "—")
                risk_sc  = domain_clean.get("legal_risk_score", 0)
                entropy  = domain_clean.get("noise_level", 0)

                if findings:
                    st.markdown("**🔴 HALLAZGOS CRÍTICOS**")
                    for f in findings:
                        st.markdown(
                            f"<div style='padding:.3rem .8rem;margin:.2rem 0;"
                            f"border-left:3px solid #FF2D2D;color:#FF2D2D;"
                            f"font-size:.75rem;'>{f}</div>",
                            unsafe_allow_html=True)

                if traps:
                    st.markdown("**⚠ CLÁUSULAS TRAMPA**")
                    for t in traps:
                        st.markdown(
                            f"<div style='padding:.3rem .8rem;margin:.2rem 0;"
                            f"border-left:3px solid #FF6600;color:#FFB100;"
                            f"font-size:.75rem;'>{t}</div>",
                            unsafe_allow_html=True)

                if coerce:
                    st.markdown("**⚡ PATRONES DE COERCIÓN**")
                    for c in coerce:
                        st.markdown(
                            f"<div style='padding:.3rem .8rem;margin:.2rem 0;"
                            f"border-left:3px solid #FFB100;color:#CC8D00;"
                            f"font-size:.75rem;'>{c}</div>",
                            unsafe_allow_html=True)

                c_v1, c_v2, c_v3 = st.columns(3)
                c_v1.metric("Veredicto Dominio",  verdict)
                c_v2.metric("Score de Riesgo Legal", f"{risk_sc:.4f}")
                c_v3.metric("Nivel de Ruido (bits)", f"{entropy:.2f}")

            st.markdown("<div style='margin-top:1rem'></div>", unsafe_allow_html=True)

            # Botón Firmar y Sellar — Módulo 2: Genesis Certifier
            if not st.session_state["sealed"]:
                if st.button("⬥  FIRMAR Y SELLAR EN EVIDENCE VAULT",
                             use_container_width=True):
                    with st.spinner("Generando firma criptográfica y certificado PDF..."):
                        signed = SIGNER.sign_report(report.__dict__)
                        vault_path = CONNECTOR.export_evidence(
                            signed,
                            label=f"{input_type}_{report.overall_verdict}"
                        )
                        st.session_state["signed_report"] = signed
                        st.session_state["sealed"] = True
                        sig = signed["authorship"]
                        _log(f"Sellado: {vault_path.name}", "ok")
                        _log(f"SHA-256: {sig['content_hash']}", "dim")

                        # ── Generar PDF Certificate ────────────────
                        try:
                            # Obtener figura 3D actual
                            _topo_fig = build_topology_3d(report)
                            cert_path = CERTIFIER.generate(
                                report_dict   = report.__dict__,
                                raw_text      = st.session_state.get("raw_text", ""),
                                signed_report = signed,
                                topology_fig  = _topo_fig,
                                input_type    = input_type,
                            )
                            # ── Ancla de Identidad v3.0 ───────────
                            cert_id_for_anchor = Path(cert_path).stem
                            try:
                                anchor_data = SIGNER.embed_identity_anchor(
                                    cert_path,
                                    cert_id=cert_id_for_anchor,
                                )
                                st.session_state["anchor_data"] = anchor_data
                                _log(f"Ancla de Identidad insertada · Origin: {anchor_data['origin_hash'][:16]}...", "ok")
                            except Exception as _ae:
                                _log(f"Ancla no insertada: {_ae}", "dim")

                            # Guardar bytes para descarga inmediata
                            cert_bytes = cert_path.read_bytes()
                            st.session_state["cert_path"]  = str(cert_path)
                            st.session_state["cert_bytes"] = cert_bytes
                            _log(f"Certificado PDF: {cert_path.name}", "ok")
                        except ImportError as e:
                            _log(f"PDF no generado (fpdf2 no instalado): {e}", "dim")
                            st.session_state["cert_path"]  = None
                            st.session_state["cert_bytes"] = None
                        except Exception as e:
                            _log(f"Error generando PDF: {e}", "warn")
                            st.session_state["cert_path"]  = None
                            st.session_state["cert_bytes"] = None

                        # ── Forensic Ledger ────────────────────────
                        try:
                            _ledger_entry = ledger_append(
                                raw_text         = st.session_state.get("raw_text", ""),
                                report_dict      = report.__dict__,
                                authorship       = sig,
                                cert_path        = str(cert_path) if st.session_state.get("cert_path") else None,
                                anchor_data      = st.session_state.get("anchor_data"),
                            )
                            _log(f"Ledger: entrada #{ledger_count()} registrada.", "ok")
                        except Exception as _le:
                            _log(f"Ledger error: {_le}", "dim")

                        st.rerun()
            else:
                signed = st.session_state.get("signed_report", {})
                sig = signed.get("authorship", {})
                st.markdown(f"""
                <div class="hash-display">
                    <strong>SELLADO POR:</strong> {sig.get('signed_by','—')}<br>
                    <strong>PROTOCOLO :</strong> {sig.get('protocol','—')}<br>
                    <strong>TIMESTAMP :</strong> {sig.get('timestamp','—')}<br>
                    <strong>SHA-256   :</strong> {sig.get('content_hash','—')}
                </div>
                """, unsafe_allow_html=True)
                st.markdown(_badge("EVIDENCIA SELLADA", "ok"), unsafe_allow_html=True)

                # Mostrar Ancla de Identidad si existe
                anchor_data = st.session_state.get("anchor_data")
                if anchor_data:
                    with st.expander("◈ ANCLA DE IDENTIDAD v3.0"):
                        st.markdown(f"""
                        <div class="hash-display" style="font-size:.68rem;">
                        <strong>ORIGIN HASH:</strong> {anchor_data.get('origin_hash','—')[:32]}...<br>
                        <strong>TAD TIMESTAMP:</strong> {anchor_data.get('tad_timestamp','—')}<br>
                        <strong>κD NODE:</strong> {anchor_data.get('nist_node','—')}<br>
                        <strong>PDF SHA-256:</strong> {anchor_data.get('anchored_pdf_sha256','—')[:32]}...<br>
                        <strong>CERT-ID:</strong> {anchor_data.get('cert_id','—')}
                        </div>
                        """, unsafe_allow_html=True)
                        st.markdown(
                            _badge("METADATOS XMP INSERTADOS EN PDF", "ok"),
                            unsafe_allow_html=True
                        )

                # Botón de descarga del PDF si está disponible
                cert_bytes = st.session_state.get("cert_bytes")
                cert_path  = st.session_state.get("cert_path")

                # Fix: si cert_bytes se perdió en serialización, re-leer del archivo
                if not cert_bytes and cert_path:
                    try:
                        _cp = Path(cert_path)
                        if _cp.exists():
                            cert_bytes = _cp.read_bytes()
                            st.session_state["cert_bytes"] = cert_bytes
                    except Exception:
                        pass

                if cert_bytes:
                    cert_name = Path(cert_path).name if cert_path else "genesis_cert.pdf"
                    st.download_button(
                        label     = "⬇  DESCARGAR CERTIFICADO PDF",
                        data      = cert_bytes,
                        file_name = cert_name,
                        mime      = "application/pdf",
                        use_container_width=True,
                    )
                    st.markdown(
                        _badge("CERTIFICADO DE GÉNESIS GENERADO", "ok"),
                        unsafe_allow_html=True
                    )
                else:
                    st.markdown(
                        '<div style="font-size:0.7rem;color:rgba(255,177,0,0.4);margin-top:0.5rem;">'
                        'PDF no disponible — instalar fpdf2: <code>pip install fpdf2 kaleido</code>'
                        '</div>',
                        unsafe_allow_html=True
                    )


# ══════════════════════════════════════════════════════════════
# TAB 2: ESPACIO LATENTE (Visualizaciones)
# ══════════════════════════════════════════════════════════════

with tab_viz:
    if report is None:
        st.markdown("""
        <div style="color:rgba(255,177,0,0.25);font-size:0.75rem;
                    text-align:center;padding:4rem 1rem;">
        EJECUTE UN ESCANEO PARA VISUALIZAR EL ESPACIO LATENTE
        </div>
        """, unsafe_allow_html=True)
    else:
        st.markdown("""
        <div class="section-title"><span>▸</span> VISUALIZADOR DEL ESPACIO LATENTE</div>
        """, unsafe_allow_html=True)

        # Gráfico 3D principal
        st.plotly_chart(build_topology_3d(report),
                        use_container_width=True, key="chart_3d")

        col_hd, col_radar = st.columns([3, 2], gap="medium")
        with col_hd:
            st.markdown("""
            <div class="section-title"><span>▸</span>
            RUGOSIDAD DE HAUSDORFF</div>
            """, unsafe_allow_html=True)
            st.plotly_chart(build_hausdorff_chart(report),
                            use_container_width=True, key="chart_hd")

        with col_radar:
            st.markdown("""
            <div class="section-title"><span>▸</span>
            RADAR DE RIESGO</div>
            """, unsafe_allow_html=True)
            st.plotly_chart(build_risk_radar(report),
                            use_container_width=True, key="chart_radar")

        # Métricas de topología
        topo = report.raw_reports.get("topology", {})
        if topo:
            st.markdown("""
            <div class="section-title" style="margin-top:1rem">
            <span>▸</span> MÉTRICAS TOPOLÓGICAS</div>
            """, unsafe_allow_html=True)
            t1, t2, t3, t4 = st.columns(4)
            with t1:
                st.markdown(_metric_card("NODOS", str(topo.get("node_count","—")),
                                         "Unidades de pensamiento"), unsafe_allow_html=True)
            with t2:
                st.markdown(_metric_card("ARISTAS", str(topo.get("edge_count","—")),
                                         "Conexiones lógicas"), unsafe_allow_html=True)
            with t3:
                comp = topo.get("components", 1)
                comp_kind = "risk" if comp > 3 else "ok"
                st.markdown(_metric_card("COMPONENTES", str(comp),
                                         "Fragmentación lógica", comp_kind),
                            unsafe_allow_html=True)
            with t4:
                circ = topo.get("circular_logic_detected", False)
                st.markdown(_metric_card("LÓGICA CIRCULAR",
                                         "SÍ" if circ else "NO",
                                         "Argumento cíclico",
                                         "risk" if circ else "ok"),
                            unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════
# TAB 3: BÓVEDA DE EVIDENCIA
# ══════════════════════════════════════════════════════════════

with tab_vault:
    st.markdown("""
    <div class="section-title"><span>▸</span> BÓVEDA DE EVIDENCIA</div>
    """, unsafe_allow_html=True)

    vault_dir = ROOT / "logs" / "evidence_vault"
    vault_files = sorted(vault_dir.glob("*.json"), reverse=True) \
        if vault_dir.exists() else []

    # Filtrar manifests
    evidence_files = [f for f in vault_files if ".manifest." not in f.name]

    if not evidence_files:
        st.markdown("""
        <div style="color:rgba(255,177,0,0.25);font-size:0.75rem;
                    text-align:center;padding:2rem;">
        BÓVEDA VACÍA — SELLE EVIDENCIA DESDE LA TERMINAL DE AUDITORÍA
        </div>
        """, unsafe_allow_html=True)
    else:
        # Construir tabla
        rows = []
        for f in evidence_files:
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                manifest_f = vault_dir / (f.name + ".manifest.json")
                sha = ""
                if manifest_f.exists():
                    m = json.loads(manifest_f.read_text())
                    sha = m.get("sha256", "")[:20] + "..."

                verdict  = data.get("overall_verdict", data.get("verdict", "N/A"))
                inp_type = data.get("input_type", "—")
                score    = data.get("manifold_score", "—")
                ts       = f.name[:15].replace("_", " ")
                auth     = data.get("authorship", {}).get("signed_by", "—")

                rows.append({
                    "Timestamp":      ts,
                    "Tipo":           inp_type,
                    "Veredicto":      verdict,
                    "ManifoldScore":  f"{score:.4f}" if isinstance(score, float) else score,
                    "Firmado por":    auth,
                    "SHA-256":        sha,
                    "Archivo":        f.name,
                })
            except Exception:
                continue

        if rows:
            import pandas as pd
            df = pd.DataFrame(rows)
            st.dataframe(
                df.drop(columns=["Archivo"]),
                use_container_width=True,
                hide_index=True,
            )

            # Selector para ver detalles
            selected = st.selectbox(
                "Ver detalle de evidencia:",
                options=[r["Archivo"] for r in rows],
                format_func=lambda x: x[:50],
            )
            if selected:
                sel_path = vault_dir / selected
                try:
                    sel_data = json.loads(sel_path.read_text(encoding="utf-8"))
                    with st.expander(f"◈ DETALLE: {selected}"):
                        st.json(sel_data)

                    # Exportar JSON
                    st.download_button(
                        label="⬇  EXPORTAR EVIDENCIA (JSON)",
                        data=json.dumps(sel_data, default=str, indent=2),
                        file_name=selected,
                        mime="application/json",
                    )
                except Exception as e:
                    st.error(f"Error leyendo evidencia: {e}")

        col_stats1, col_stats2, col_stats3 = st.columns(3)
        with col_stats1:
            st.markdown(_metric_card("TOTAL SELLADOS", str(len(evidence_files)),
                                     "Evidencias en bóveda"), unsafe_allow_html=True)
        with col_stats2:
            high_risk = sum(1 for r in rows if r["Veredicto"] == "HIGH_RISK")
            st.markdown(_metric_card("ALTO RIESGO", str(high_risk),
                                     "Documentos críticos",
                                     "risk" if high_risk > 0 else "ok"),
                        unsafe_allow_html=True)
        with col_stats3:
            clear = sum(1 for r in rows if r["Veredicto"] == "CLEAR")
            st.markdown(_metric_card("LIMPIOS", str(clear),
                                     "Sin anomalías detectadas", "ok"),
                        unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════
# TAB 4: INYECTOR DE ORDEN (Plagio Inverso)
# ══════════════════════════════════════════════════════════════

with tab_plag:
    st.markdown("""
    <div class="section-title"><span>▸</span> INYECTOR DE ORDEN — AUDITORÍA DE PLAGIO INVERSO</div>
    """, unsafe_allow_html=True)

    st.markdown(f"""
    <div style="font-size:0.72rem;color:rgba(255,177,0,0.5);margin-bottom:1rem;
                border-left:3px solid rgba(255,177,0,0.3);padding-left:0.8rem;">
    Compara código externo contra <code>core/manifold_engine.py</code>.
    Detecta replicación de la lógica κD = {K_D} bajo cualquier nombre de variable.
    </div>
    """, unsafe_allow_html=True)

    col_plag_in, col_plag_out = st.columns([1, 1], gap="medium")

    with col_plag_in:
        st.markdown("""
        <div class="section-title" style="font-size:0.75rem">
        <span>▸</span> CÓDIGO SOSPECHOSO</div>
        """, unsafe_allow_html=True)

        plag_upload_mode = st.radio(
            "Fuente código",
            ["Archivo .py", "Texto directo"],
            horizontal=True,
            label_visibility="collapsed",
            key="plag_mode",
        )

        suspicious_code = ""
        if plag_upload_mode == "Archivo .py":
            plag_file = st.file_uploader(
                "Subir código sospechoso",
                type=["py", "txt", "js", "ts", "cpp", "java"],
                label_visibility="collapsed",
                key="plag_uploader",
            )
            if plag_file:
                suspicious_code = plag_file.read().decode("utf-8", errors="replace")
        else:
            suspicious_code = st.text_area(
                "Pegar código sospechoso:",
                height=280,
                placeholder="# Pegar código a analizar...\n\ndef stability_factor(x):\n    return x * 0.56",
                label_visibility="collapsed",
                key="plag_textarea",
            )

        # Mostrar info de referencia
        ref_exists = (ROOT / "core" / "manifold_engine.py").exists()
        ref_lines  = 0
        if ref_exists:
            ref_lines = len((ROOT / "core" / "manifold_engine.py").read_text(encoding="utf-8", errors="replace").splitlines())
        st.markdown(f"""
        <div style="font-size:0.65rem;color:rgba(255,177,0,0.35);margin-top:0.5rem;">
        REFERENCIA: core/manifold_engine.py
        {"· " + str(ref_lines) + " líneas" if ref_exists else " · NO ENCONTRADO"}
        </div>
        """, unsafe_allow_html=True)

        st.markdown("<div style='margin-top:0.8rem'></div>", unsafe_allow_html=True)
        run_plag = st.button("⬣  EJECUTAR ANÁLISIS DE PLAGIO ESTRUCTURAL",
                             use_container_width=True,
                             key="btn_plag")

    with col_plag_out:
        st.markdown("""
        <div class="section-title" style="font-size:0.75rem">
        <span>▸</span> RESULTADO</div>
        """, unsafe_allow_html=True)

        if run_plag:
            if not suspicious_code.strip():
                st.warning("No hay código para analizar.")
            else:
                with st.spinner("Analizando similitud estructural..."):
                    _log("Iniciando análisis de plagio inverso...", "warn")
                    p_report = PLAGIARISM.analyze(suspicious_code)
                    st.session_state["plag_report"] = p_report
                    st.session_state["plag_code"]   = suspicious_code
                    level = ("risk" if "PLAGIO" in p_report.verdict
                             else "warn" if "SOSPECHOSA" in p_report.verdict
                             else "ok")
                    _log(f"Plagio: {p_report.verdict} | Score: {p_report.overall_score:.4f}", level)
                st.rerun()

        p_rep: PlagiarismReport | None = st.session_state.get("plag_report")

        if p_rep is None:
            st.markdown("""
            <div style="color:rgba(255,177,0,0.2);font-size:0.75rem;
                        text-align:center;padding:3rem 1rem;
                        border:1px dashed rgba(255,177,0,0.1);">
            SISTEMA EN ESPERA<br>
            <span style="font-size:0.65rem">Cargue código y ejecute el análisis</span>
            </div>
            """, unsafe_allow_html=True)
        else:
            # Banner de veredicto
            v_colors = {
                "INTENTO DE PLAGIO ESTRUCTURAL": ("verdict-highrisk", "⚠"),
                "SIMILITUD SOSPECHOSA":           ("verdict-review",   "⚡"),
                "ORIGINAL":                       ("verdict-clear",    "✓"),
            }
            v_css, v_icon = v_colors.get(p_rep.verdict, ("verdict-review", "?"))
            st.markdown(f"""
            <div class="{v_css}">
                {v_icon} &nbsp; {p_rep.verdict}
            </div>
            """, unsafe_allow_html=True)

            st.markdown("<div style='margin-top:1rem'></div>", unsafe_allow_html=True)

            # Score desglosado
            p1, p2 = st.columns(2)
            with p1:
                score_kind = ("risk" if p_rep.overall_score >= 0.6
                              else "warn" if p_rep.overall_score >= 0.35
                              else "ok")
                st.markdown(_metric_card(
                    "SCORE GLOBAL", f"{p_rep.overall_score:.4f}",
                    p_rep.verdict[:20], score_kind),
                    unsafe_allow_html=True)
            with p2:
                st.markdown(_metric_card(
                    "SIMILITUD κD", f"{p_rep.constant_sim:.4f}",
                    f"{len(p_rep.kappa_hits)} constante(s) detectada(s)",
                    "risk" if p_rep.constant_sim > 0.5 else "const"),
                    unsafe_allow_html=True)

            st.markdown("<div style='margin-top:0.8rem'></div>", unsafe_allow_html=True)

            p3, p4 = st.columns(2)
            with p3:
                st.markdown(_metric_card(
                    "ESTRUCTURAL AST", f"{p_rep.structural_sim:.4f}",
                    p_rep.structural_details[:40] + "...",
                    "warn" if p_rep.structural_sim > 0.3 else "ok"),
                    unsafe_allow_html=True)
            with p4:
                st.markdown(_metric_card(
                    "API SURFACE", f"{p_rep.api_sim:.4f}",
                    f"{len(p_rep.api_hits)} función(es) coincidente(s)",
                    "risk" if p_rep.api_sim > 0.3 else "ok"),
                    unsafe_allow_html=True)

            # Barra visual del score
            st.markdown(
                '<div class="metric-label" style="margin-top:0.8rem;">ÍNDICE DE SIMILITUD ESTRUCTURAL</div>'
                + _stability_bar(p_rep.overall_score, risk=p_rep.overall_score >= 0.6),
                unsafe_allow_html=True,
            )

            # κD hits detalle
            if p_rep.kappa_hits:
                with st.expander(f"◈ CONSTANTES κD DETECTADAS ({len(p_rep.kappa_hits)})"):
                    for h in p_rep.kappa_hits:
                        color = {"EXACTO": "#FF2D2D", "EQUIVALENTE": "#FF6600",
                                 "PRÓXIMO": "#FFB100"}.get(h["type"], "#CC8D00")
                        st.markdown(
                            f"<div style='padding:.3rem .8rem;margin:.2rem 0;"
                            f"border-left:3px solid {color};font-size:.75rem;'>"
                            f"<span style='color:{color}'>[{h['type']}]</span> "
                            f"Línea <strong>{h['line']}</strong>: "
                            f"<code>{h['value']}</code> "
                            f"(Δ={h['delta']:.4f})</div>",
                            unsafe_allow_html=True,
                        )

            # API hits
            if p_rep.api_hits:
                with st.expander(f"◈ FIRMAS API COINCIDENTES ({len(p_rep.api_hits)})"):
                    for h in p_rep.api_hits:
                        st.markdown(
                            f"<div style='padding:.3rem .8rem;border-left:3px solid #FF6600;"
                            f"font-size:.75rem;color:#FFB100;'>{h}</div>",
                            unsafe_allow_html=True,
                        )

            # Patrones semánticos
            if p_rep.pattern_hits:
                with st.expander(f"◈ PATRONES SEMÁNTICOS ({len(p_rep.pattern_hits)})"):
                    for h in p_rep.pattern_hits:
                        st.markdown(
                            f"<div style='padding:.3rem .8rem;border-left:3px solid #CC8D00;"
                            f"font-size:.75rem;color:#CC8D00;'>{h}</div>",
                            unsafe_allow_html=True,
                        )

            # Evidencia completa
            with st.expander("◈ RESUMEN DE EVIDENCIA COMPLETO"):
                st.markdown(
                    f'<div class="terminal-output">{p_rep.evidence_summary.replace(chr(10),"<br>")}</div>',
                    unsafe_allow_html=True,
                )


# ══════════════════════════════════════════════════════════════
# TAB 5: SHADOW-CODE DETECTOR
# ══════════════════════════════════════════════════════════════

with tab_shadow:
    st.markdown("""
    <div class="section-title"><span>▸</span> SHADOW-CODE DETECTOR — ANÁLISIS DE AUTORÍA COMPUTACIONAL</div>
    """, unsafe_allow_html=True)
    st.markdown(f"""
    <div style="font-size:.72rem;color:rgba(255,177,0,.5);margin-bottom:1rem;
                border-left:3px solid rgba(255,177,0,.3);padding-left:.8rem;">
    Detecta si el código fue escrito por un humano o generado por IA intentando
    replicar la lógica de invarianza κD = {K_D}.
    Métricas: rugosidad fractal · burstiness léxico · densidad de comentarios ·
    entropía de naming · regularidad estructural.
    </div>
    """, unsafe_allow_html=True)

    col_sd_in, col_sd_out = st.columns([1, 1], gap="medium")

    with col_sd_in:
        st.markdown('<div class="section-title" style="font-size:.75rem"><span>▸</span> CÓDIGO A EXAMINAR</div>',
                    unsafe_allow_html=True)

        sd_mode = st.radio("Fuente shadow", ["Archivo", "Texto directo"],
                           horizontal=True, label_visibility="collapsed", key="sd_mode")

        shadow_source = ""
        if sd_mode == "Archivo":
            sd_file = st.file_uploader("Código a examinar",
                                       type=["py", "js", "ts", "cpp", "java", "txt"],
                                       label_visibility="collapsed", key="sd_upload")
            if sd_file:
                shadow_source = sd_file.read().decode("utf-8", errors="replace")
        else:
            shadow_source = st.text_area(
                "Pegar código:",
                height=300,
                placeholder="# Código a examinar...",
                label_visibility="collapsed",
                key="sd_text",
            )

        run_shadow = st.button("◉  EJECUTAR SHADOW-CODE ANALYSIS",
                               use_container_width=True, key="btn_shadow")

    with col_sd_out:
        st.markdown('<div class="section-title" style="font-size:.75rem"><span>▸</span> RESULTADO</div>',
                    unsafe_allow_html=True)

        if run_shadow:
            if not shadow_source.strip():
                st.warning("No hay código para analizar.")
            else:
                with st.spinner("Calculando rugosidad fractal de autoría..."):
                    _log("Shadow-Code analysis iniciado...", "warn")
                    sd_report = SHADOW_DETECT.analyze(shadow_source)
                    st.session_state["shadow_report"] = sd_report
                    st.session_state["shadow_code"]   = shadow_source
                    _log(f"Shadow: {sd_report.verdict} | Human: {sd_report.human_score:.4f}", "warn")
                st.rerun()

        sd_rep: ShadowCodeReport | None = st.session_state.get("shadow_report")

        if sd_rep is None:
            st.markdown("""
            <div style="color:rgba(255,177,0,.2);font-size:.75rem;text-align:center;
                        padding:3rem;border:1px dashed rgba(255,177,0,.1);">
            CARGUE CÓDIGO Y EJECUTE EL ANÁLISIS
            </div>""", unsafe_allow_html=True)
        else:
            # Veredicto banner
            _sd_css = {
                "PLAGIO ALGORÍTMICO PROBABLE": ("verdict-highrisk", "⚠"),
                "GENERADO POR IA":              ("verdict-highrisk", "⚠"),
                "ASISTIDO POR IA":              ("verdict-review",   "⚡"),
                "AUTORÍA HUMANA PROBABLE":      ("verdict-clear",    "✓"),
            }
            _sd_c, _sd_i = _sd_css.get(sd_rep.verdict, ("verdict-review", "?"))
            st.markdown(f'<div class="{_sd_c}">{_sd_i} &nbsp; {sd_rep.verdict}</div>',
                        unsafe_allow_html=True)
            st.markdown("<div style='margin-top:.8rem'></div>", unsafe_allow_html=True)

            sd1, sd2 = st.columns(2)
            with sd1:
                _hk = ("ok" if sd_rep.human_score > .6 else
                       "risk" if sd_rep.human_score < .35 else "const")
                st.markdown(_metric_card("HUMAN SCORE", f"{sd_rep.human_score:.4f}",
                                         sd_rep.verdict[:22], _hk), unsafe_allow_html=True)
            with sd2:
                st.markdown(_metric_card("FRACTAL ROUGHNESS", f"{sd_rep.fractal_roughness:.4f}",
                                         "Irregularidad de líneas",
                                         "ok" if sd_rep.fractal_roughness > .5 else "risk"),
                             unsafe_allow_html=True)
            st.markdown("<div style='margin-top:.5rem'></div>", unsafe_allow_html=True)
            sd3, sd4 = st.columns(2)
            with sd3:
                st.markdown(_metric_card("LEXICAL BURSTINESS", f"{sd_rep.lexical_burstiness:.4f}",
                                         "Gini del vocabulario",
                                         "ok" if sd_rep.lexical_burstiness > .5 else "risk"),
                             unsafe_allow_html=True)
            with sd4:
                st.markdown(_metric_card("COMMENT RATIO", f"{sd_rep.comment_ratio:.1%}",
                                         "Sobre-comentado" if sd_rep.comment_ratio > .3 else "Normal",
                                         "risk" if sd_rep.comment_ratio > .3 else "ok"),
                             unsafe_allow_html=True)

            # Barra de human score
            st.markdown(
                '<div class="metric-label" style="margin-top:.6rem;">ÍNDICE DE HUMANIDAD</div>'
                + _stability_bar(sd_rep.human_score, risk=sd_rep.human_score < .35),
                unsafe_allow_html=True)

            # Evidencia
            if sd_rep.evidence_points:
                with st.expander(f"◈ EVIDENCIA FORENSE ({len(sd_rep.evidence_points)} señales)"):
                    for ep in sd_rep.evidence_points:
                        _ec = "#FF2D2D" if "LLM" in ep else "#FFB100"
                        st.markdown(
                            f"<div style='padding:.3rem .8rem;margin:.2rem 0;"
                            f"border-left:3px solid {_ec};font-size:.75rem;color:{_ec};'>{ep}</div>",
                            unsafe_allow_html=True)

    # ── Gráfico de dispersión Plotly ──────────────────────────
    if st.session_state.get("shadow_report"):
        sd_rep = st.session_state["shadow_report"]
        st.markdown('<div class="section-title" style="margin-top:1rem"><span>▸</span> MAPA DE AUTORÍA — DISPERSIÓN FRACTAL</div>',
                    unsafe_allow_html=True)

        # Construir figura
        scatter_data = sd_rep.scatter_data
        fig_sc = go.Figure()

        # Zonas de fondo
        fig_sc.add_shape(type="rect", x0=0, y0=0, x1=0.5, y1=0.5,
                         fillcolor="rgba(255,45,45,0.06)", line_width=0, layer="below")
        fig_sc.add_shape(type="rect", x0=0.5, y0=0.5, x1=1, y1=1,
                         fillcolor="rgba(0,255,136,0.06)", line_width=0, layer="below")

        # Puntos de referencia
        ref_pts = [p for p in scatter_data if p.get("ref")]
        main_pt = [p for p in scatter_data if not p.get("ref")]

        if ref_pts:
            llm_pts  = [p for p in ref_pts if p["color"] == "#FF2D2D"]
            hum_pts  = [p for p in ref_pts if p["color"] == "#00FF88"]
            fig_sc.add_trace(go.Scatter(
                x=[p["x"] for p in llm_pts], y=[p["y"] for p in llm_pts],
                mode="markers", name="Zona IA",
                marker=dict(color="#FF2D2D", size=10, symbol="circle",
                            line=dict(color="#FF2D2D", width=1)),
                opacity=0.5,
            ))
            fig_sc.add_trace(go.Scatter(
                x=[p["x"] for p in hum_pts], y=[p["y"] for p in hum_pts],
                mode="markers", name="Zona Humana",
                marker=dict(color="#00FF88", size=10, symbol="circle",
                            line=dict(color="#00FF88", width=1)),
                opacity=0.5,
            ))

        # Punto analizado
        if main_pt:
            p = main_pt[0]
            hs = p.get("human_score", 0.5)
            pt_color = ("#00FF88" if hs > .6 else "#FF2D2D" if hs < .35 else "#FFB100")
            fig_sc.add_trace(go.Scatter(
                x=[p["x"]], y=[p["y"]],
                mode="markers+text",
                name="Documento analizado",
                text=[f"  Score={hs:.3f}"],
                textposition="middle right",
                textfont=dict(color=AMBER, size=10),
                marker=dict(color=pt_color, size=18, symbol="diamond",
                            line=dict(color=AMBER, width=2)),
            ))

        # Líneas de umbral
        fig_sc.add_hline(y=0.5, line_dash="dash", line_color=AMBER,
                         annotation_text=" Umbral Humano/IA",
                         annotation_font=dict(color=AMBER, size=8))
        fig_sc.add_vline(x=0.5, line_dash="dash", line_color=AMBER)

        # Anotaciones de zonas
        fig_sc.add_annotation(x=0.25, y=0.1, text="ZONA IA / LLM",
                               font=dict(color="#FF2D2D", size=9, family="Orbitron"),
                               showarrow=False)
        fig_sc.add_annotation(x=0.75, y=0.9, text="ZONA HUMANA",
                               font=dict(color="#00FF88", size=9, family="Orbitron"),
                               showarrow=False)

        fig_sc.update_layout(
            **_PLOTLY_LAYOUT,
            title=dict(text=f"DISPERSIÓN FRACTAL DE AUTORÍA — {sd_rep.verdict}",
                       font=dict(size=10, color=AMBER)),
            xaxis=dict(title="Fractal Roughness →", color=AMBER, range=[0, 1],
                       gridcolor="rgba(255,177,0,.1)"),
            yaxis=dict(title="Lexical Burstiness →", color=AMBER, range=[0, 1],
                       gridcolor="rgba(255,177,0,.1)"),
            legend=dict(font=dict(color=AMBER, size=9), bgcolor="rgba(0,0,0,.5)"),
            height=420,
        )
        st.plotly_chart(fig_sc, use_container_width=True, key="chart_shadow")

        # κD hits si existen
        if sd_rep.kappa_constants:
            st.markdown(f"""
            <div style="border:1px solid #FF2D2D;padding:.8rem;margin-top:.5rem;
                        background:rgba(255,45,45,.05);">
            <span style="color:#FF2D2D;font-family:Orbitron,monospace;font-size:.75rem;">
            ⚠ {len(sd_rep.kappa_constants)} CONSTANTE(S) κD-PROXIMAL(ES) DETECTADA(S)
            </span><br>
            <span style="color:rgba(255,177,0,.6);font-size:.65rem;">
            {'  |  '.join(f"L{h['line']}: {h['value']} (Δ={h['delta']})"
                          for h in sd_rep.kappa_constants[:5])}
            </span>
            </div>
            """, unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════
# TAB 6: HISTORIAL DE INVARIANZA (Forensic Ledger)
# ══════════════════════════════════════════════════════════════

with tab_ledger:
    st.markdown("""
    <div class="section-title"><span>▸</span> HISTORIAL DE INVARIANZA — FORENSIC LEDGER</div>
    """, unsafe_allow_html=True)

    # Integrity check + stats
    _integrity = ledger_verify()
    _n         = _integrity.get("entries", 0)

    lc1, lc2, lc3, lc4 = st.columns(4)
    with lc1:
        st.markdown(_metric_card("ENTRADAS TOTALES", str(_n), "Operaciones selladas", "const"),
                    unsafe_allow_html=True)
    with lc2:
        st.markdown(_metric_card("INTEGRIDAD", "✓ OK" if _integrity["valid"] else "⚠ ERROR",
                                 "Chain hash verificado", "ok"), unsafe_allow_html=True)
    with lc3:
        st.markdown(_metric_card("PRIMERA ENTRADA", _integrity.get("first_ts", "—")[:10] or "—",
                                 "UTC", "const"), unsafe_allow_html=True)
    with lc4:
        st.markdown(_metric_card("ÚLTIMA ENTRADA",  _integrity.get("last_ts",  "—")[:10] or "—",
                                 "UTC", "const"), unsafe_allow_html=True)

    if _integrity.get("chain_hash"):
        st.markdown(f"""
        <div style="font-size:.62rem;color:rgba(255,177,0,.35);margin:.4rem 0 1rem;
                    font-family:Share Tech Mono,monospace;letter-spacing:.05em;">
        CHAIN HASH: {_integrity['chain_hash']}
        </div>
        """, unsafe_allow_html=True)

    st.markdown("---")

    # Load and display entries
    _entries = ledger_read()

    if not _entries:
        st.markdown("""
        <div style="color:rgba(255,177,0,.2);font-size:.75rem;text-align:center;
                    padding:2.5rem;border:1px dashed rgba(255,177,0,.1);">
        LEDGER VACÍO — Las entradas aparecen al usar "Firmar y Sellar"
        </div>""", unsafe_allow_html=True)
    else:
        import pandas as pd

        rows = []
        for e in reversed(_entries):           # más reciente primero
            kd  = e.get("kd_result", {})
            auth = e.get("authorship_status", {})
            ms  = kd.get("manifold_score")
            rows.append({
                "Timestamp":    e.get("timestamp", "")[:19].replace("T", " "),
                "Tipo":         e.get("input_type", "—"),
                "Veredicto":    e.get("verdict", "—"),
                "ManifoldScore": f"{ms:.4f}" if ms is not None else "INSUF.",
                "κD":           str(kd.get("kappa_d", "0.56")),
                "Firmado":      "✓" if auth.get("signed") else "✗",
                "Anclado":      "✓" if auth.get("anchored") else "—",
                "Cert-ID":      (e.get("cert_id") or "—")[:20],
                "File Hash":    e.get("file_hash", "")[:16] + "...",
            })

        df = pd.DataFrame(rows)

        # Color rows by verdict
        def _color_row(row):
            c = {"HIGH_RISK": "color: #FF2D2D",
                 "REVIEW":    "color: #FFB100",
                 "CLEAR":     "color: #00FF88"}.get(row["Veredicto"], "color: #CC8D00")
            return [c] * len(row)

        st.dataframe(
            df.style.apply(_color_row, axis=1),
            use_container_width=True,
            hide_index=True,
            height=min(60 + len(rows) * 35, 500),
        )

        # Export
        col_ex1, col_ex2 = st.columns(2)
        with col_ex1:
            import json as _json
            st.download_button(
                "⬇  EXPORTAR LEDGER (JSONL)",
                data       = "\n".join(_json.dumps(e, ensure_ascii=False) for e in _entries),
                file_name  = "audit_ledger.jsonl",
                mime       = "application/jsonlines",
                use_container_width=True,
            )
        with col_ex2:
            st.download_button(
                "⬇  EXPORTAR LEDGER (CSV)",
                data       = df.to_csv(index=False),
                file_name  = "audit_ledger.csv",
                mime       = "text/csv",
                use_container_width=True,
            )

        # Detail expander for selected entry
        st.markdown("---")
        st.markdown('<div class="section-title" style="font-size:.75rem"><span>▸</span> DETALLE DE ENTRADA</div>',
                    unsafe_allow_html=True)
        _sel_idx = st.selectbox(
            "Seleccionar entrada:",
            options=range(len(_entries)),
            format_func=lambda i: (
                f"[{len(_entries)-i}] "
                f"{_entries[-(i+1)].get('timestamp','')[:19]}  "
                f"{_entries[-(i+1)].get('verdict','—')}  "
                f"{_entries[-(i+1)].get('input_type','—')}"
            ),
            label_visibility="collapsed",
        )
        with st.expander("◈ JSON COMPLETO", expanded=False):
            st.json(_entries[-(int(_sel_idx)+1)])


# ══════════════════════════════════════════════════════════════
# TAB 7: DIFF SEMÁNTICO — Termómetro de Durante
# ══════════════════════════════════════════════════════════════

with tab_diff:
    st.markdown("""
    <div class="section-title"><span>▸</span> DIFF SEMÁNTICO TOPOLÓGICO — COMPARADOR DE MANIFOLDS H₁</div>
    """, unsafe_allow_html=True)

    # ── Descripción ───────────────────────────────────────────
    st.markdown(f"""
    <div style="border:1px solid rgba(255,177,0,0.18);border-radius:6px;
                padding:0.8rem 1.1rem;margin-bottom:1.2rem;
                background:rgba(255,177,0,0.04);font-size:0.72rem;
                color:rgba(255,177,0,0.65);letter-spacing:0.06em;line-height:1.7;">
    Compara dos documentos a nivel de <strong style="color:#FFB100">estructura topológica H₁</strong>,
    no a nivel de palabras. Si una cláusula abusiva fue <em>parafraseada</em>
    manteniendo la presión semántica, la Distancia de Wasserstein lo detecta.<br>
    Si el <strong style="color:#FFB100">Índice de Similitud Invariante (ISI)</strong>
    cae por debajo de κD = {K_D}, el sistema dispara la
    <strong style="color:#FF2D2D">Alerta de Manipulación Estructural</strong>.
    </div>
    """, unsafe_allow_html=True)

    # ── Input: dos columnas de texto ──────────────────────────
    col_da, col_db = st.columns(2, gap="medium")

    with col_da:
        st.markdown("""
        <div style="font-size:0.65rem;color:#FFB100;letter-spacing:0.12em;
                    margin-bottom:0.4rem;">DOCUMENTO A — ORIGINAL / REFERENCIA</div>
        """, unsafe_allow_html=True)
        text_da = st.text_area(
            "doc_a",
            placeholder="Pegue aquí el documento original...",
            height=220,
            label_visibility="collapsed",
            key="diff_text_a",
        )

    with col_db:
        st.markdown("""
        <div style="font-size:0.65rem;color:#FFB100;letter-spacing:0.12em;
                    margin-bottom:0.4rem;">DOCUMENTO B — VERSIÓN MODIFICADA / SOSPECHOSA</div>
        """, unsafe_allow_html=True)
        text_db = st.text_area(
            "doc_b",
            placeholder="Pegue aquí la versión modificada o sospechosa...",
            height=220,
            label_visibility="collapsed",
            key="diff_text_b",
        )

    # ── Labels opcionales ─────────────────────────────────────
    col_la, col_lb, col_btn = st.columns([2, 2, 1], gap="small")
    with col_la:
        label_da = st.text_input("Nombre Doc A", value="Documento Original",
                                 key="diff_label_a", label_visibility="collapsed")
    with col_lb:
        label_db = st.text_input("Nombre Doc B", value="Versión Modificada",
                                 key="diff_label_b", label_visibility="collapsed")
    with col_btn:
        btn_diff = st.button("◑  COMPARAR MANIFOLDS", use_container_width=True,
                             key="btn_diff")

    # ── Ejecutar diff ─────────────────────────────────────────
    if btn_diff:
        if not text_da or not text_db:
            st.warning("⚠ Ingresá texto en ambos documentos para comparar.")
        elif text_da.strip() == text_db.strip():
            st.info("Los documentos son idénticos.")
        else:
            with st.spinner("Calculando distancias topológicas H₁..."):
                try:
                    _diff_engine = SemanticDiff(kappa_d=K_D)
                    _dr = _diff_engine.compare_manifolds(
                        text_da, text_db,
                        label_a=label_da,
                        label_b=label_db,
                    )
                    st.session_state["diff_report"] = _dr
                except Exception as _e:
                    st.error(f"Error en diff semántico: {_e}")
                    st.session_state["diff_report"] = None

    # ── Mostrar resultados ────────────────────────────────────
    dr: SemanticDiffReport | None = st.session_state.get("diff_report")

    if dr is not None:
        st.markdown("<div style='margin-top:1.2rem'></div>", unsafe_allow_html=True)

        # ── TERMÓMETRO DE DURANTE ─────────────────────────────
        isi_val  = dr.invariant_similarity_index
        alert    = dr.manipulation_alert
        verdict  = dr.verdict

        # Color de la barra según ISI
        if isi_val >= K_D:
            bar_color   = "#00CC66"     # verde: dentro del límite
            bar_label   = "✓ MANIFOLD ESTABLE"
            bar_sublabel = f"ISI = {isi_val:.4f} — Por encima del Límite de Invarianza"
            label_color = "#00CC66"
        elif isi_val >= K_D * 0.7:
            bar_color   = "#FFB100"     # ámbar: zona de tensión
            bar_label   = "△ CAMBIO ESTRUCTURAL"
            bar_sublabel = f"ISI = {isi_val:.4f} — Zona de Tensión Estructural"
            label_color = "#FFB100"
        else:
            bar_color   = "#FF2D2D"     # rojo: ruptura
            bar_label   = "⚠ MANIFOLD RUPTURE — Manipulación Estructural Detectada"
            bar_sublabel = f"ISI = {isi_val:.4f} — Por debajo del Límite de Invarianza de Durante"
            label_color = "#FF2D2D"

        # Posición del marcador κD en porcentaje de la barra
        kd_pct = K_D * 100  # ej. 56%

        st.markdown(f"""
        <div style="margin:0.5rem 0 1.4rem 0;">
            <div style="font-size:0.63rem;color:#FFB100;letter-spacing:0.14em;
                        margin-bottom:0.55rem;">
                TERMÓMETRO DE DURANTE — ÍNDICE DE SIMILITUD INVARIANTE (ISI)
            </div>

            <!-- Barra principal -->
            <div style="position:relative;width:100%;height:34px;
                        background:rgba(255,177,0,0.08);border-radius:4px;
                        border:1px solid rgba(255,177,0,0.18);overflow:visible;">

                <!-- Relleno de la barra -->
                <div style="position:absolute;top:0;left:0;height:100%;
                            width:{isi_val*100:.2f}%;
                            background:{bar_color};
                            border-radius:3px;
                            opacity:0.85;
                            transition:width 0.6s ease;">
                </div>

                <!-- Línea dorada κD -->
                <div style="position:absolute;top:-6px;left:{kd_pct:.1f}%;
                            width:2px;height:46px;
                            background:#FFB100;
                            box-shadow:0 0 6px rgba(255,177,0,0.6);
                            z-index:10;">
                </div>

                <!-- Etiqueta κD -->
                <div style="position:absolute;top:-22px;
                            left:calc({kd_pct:.1f}% - 38px);
                            font-size:0.58rem;color:#FFB100;
                            letter-spacing:0.08em;white-space:nowrap;
                            font-family:monospace;">
                    ◆ Límite de Invarianza de Durante&nbsp;κD={K_D}
                </div>

                <!-- Valor ISI dentro de la barra -->
                <div style="position:absolute;top:0;left:0;width:100%;height:100%;
                            display:flex;align-items:center;
                            padding-left:10px;box-sizing:border-box;">
                    <span style="font-size:0.7rem;font-family:monospace;
                                 color:#000;font-weight:700;
                                 text-shadow:0 0 4px rgba(255,255,255,0.4);">
                        ISI = {isi_val:.4f}
                    </span>
                </div>
            </div>

            <!-- Etiqueta de estado debajo de la barra -->
            <div style="margin-top:0.5rem;font-size:0.72rem;
                        color:{label_color};letter-spacing:0.10em;font-weight:700;">
                {bar_label}
            </div>
            <div style="font-size:0.62rem;color:rgba(255,177,0,0.50);
                        letter-spacing:0.06em;margin-top:0.15rem;">
                {bar_sublabel}
            </div>
        </div>
        """, unsafe_allow_html=True)

        # ── ALERTA ROJA si ISI < κD ───────────────────────────
        if alert:
            st.markdown(f"""
            <div style="border:2px solid #FF2D2D;border-radius:6px;
                        padding:0.9rem 1.2rem;margin:0.5rem 0 1rem 0;
                        background:rgba(255,45,45,0.08);">
                <div style="font-size:0.80rem;color:#FF2D2D;letter-spacing:0.14em;
                            font-weight:700;margin-bottom:0.5rem;">
                    ⚠&nbsp; ALERTA DE MANIPULACIÓN ESTRUCTURAL DETECTADA
                </div>
                <div style="font-size:0.68rem;color:rgba(255,100,100,0.85);
                            letter-spacing:0.06em;line-height:1.8;">
                    La distancia topológica entre los documentos supera el umbral de buena fe
                    estructural definido por la Constante de Durante (κD = {K_D}).<br>
                    El Documento B <strong>no puede considerarse una edición honesta</strong>
                    del Documento A.<br><br>
                    Distancia de Wasserstein H₁ &nbsp;=&nbsp;
                    <strong style="color:#FF2D2D">{dr.wasserstein_h1:.6f}</strong>
                    &nbsp;&nbsp;|&nbsp;&nbsp;
                    Distancia de Bottleneck &nbsp;=&nbsp;
                    <strong style="color:#FF2D2D">{dr.bottleneck_h1:.6f}</strong>
                </div>
            </div>
            """, unsafe_allow_html=True)

        # ── MÉTRICAS en 4 columnas ────────────────────────────
        st.markdown("""
        <div class="section-title" style="margin-top:0.8rem;">
            <span>▸</span> MÉTRICAS TOPOLÓGICAS
        </div>
        """, unsafe_allow_html=True)

        mc1, mc2, mc3, mc4 = st.columns(4, gap="small")

        def _diff_metric(col, label, value, note="", color="#FFB100"):
            col.markdown(f"""
            <div style="border:1px solid rgba(255,177,0,0.20);border-radius:5px;
                        padding:0.6rem 0.8rem;background:rgba(255,177,0,0.04);">
                <div style="font-size:0.58rem;color:rgba(255,177,0,0.55);
                            letter-spacing:0.10em;">{label}</div>
                <div style="font-size:1.05rem;color:{color};font-family:monospace;
                            font-weight:700;margin-top:0.2rem;">{value}</div>
                <div style="font-size:0.58rem;color:rgba(255,177,0,0.40);
                            margin-top:0.15rem;">{note}</div>
            </div>
            """, unsafe_allow_html=True)

        _diff_metric(mc1, "WASSERSTEIN H₁",
                     f"{dr.wasserstein_h1:.4f}",
                     "energía de transformación",
                     "#FF2D2D" if dr.wasserstein_h1 > K_D else "#FFB100")

        _diff_metric(mc2, "BOTTLENECK",
                     f"{dr.bottleneck_h1:.4f}",
                     "ciclo más perturbado",
                     "#FF2D2D" if dr.bottleneck_h1 > K_D * 0.5 else "#FFB100")

        _diff_metric(mc3, "Δ FALSEDADES H₁",
                     f"{dr.delta.delta_structural_faults:+d}",
                     "ciclos STRUCTURAL_FALSEHOOD",
                     "#FF2D2D" if dr.delta.delta_structural_faults > 0 else "#00CC66")

        _diff_metric(mc4, "Δ INTEGRIDAD",
                     f"{dr.delta.delta_integrity:+.4f}",
                     "integrity_score B − A",
                     "#FF2D2D" if dr.delta.delta_integrity < 0 else "#00CC66")

        # ── GRÁFICO: Diagrama de distancias ───────────────────
        st.markdown("""
        <div class="section-title" style="margin-top:1rem;">
            <span>▸</span> PERFIL COMPARATIVO H₁
        </div>
        """, unsafe_allow_html=True)

        rep_a_dict = dr.report_a or {}
        rep_b_dict = dr.report_b or {}

        h1_a_pairs = rep_a_dict.get("h1_pairs", [])
        h1_b_pairs = rep_b_dict.get("h1_pairs", [])

        fig_diff = go.Figure()
        fig_diff.update_layout(
            paper_bgcolor="#000", plot_bgcolor="#0D0D0D",
            font=dict(family="IBM Plex Mono, monospace", color=AMBER, size=10),
            margin=dict(l=40, r=40, t=40, b=40),
            height=320,
            showlegend=True,
            legend=dict(bgcolor="rgba(0,0,0,0)", font=dict(size=9)),
        )

        # Scatter H₁ Doc A
        if h1_a_pairs:
            births_a = [p["birth"] for p in h1_a_pairs if math.isfinite(p.get("death", float("inf")))]
            deaths_a = [p["death"] for p in h1_a_pairs if math.isfinite(p.get("death", float("inf")))]
            pers_a   = [p["persistence"] for p in h1_a_pairs if math.isfinite(p.get("death", float("inf")))]
            if births_a:
                fig_diff.add_trace(go.Scatter(
                    x=births_a, y=deaths_a,
                    mode="markers",
                    marker=dict(size=[max(6, min(20, p*40)) for p in pers_a],
                                color=AMBER, opacity=0.85, symbol="circle"),
                    name=f"H₁ Doc A ({len(births_a)} ciclos)",
                ))

        # Scatter H₁ Doc B
        if h1_b_pairs:
            births_b = [p["birth"] for p in h1_b_pairs if math.isfinite(p.get("death", float("inf")))]
            deaths_b = [p["death"] for p in h1_b_pairs if math.isfinite(p.get("death", float("inf")))]
            pers_b   = [p["persistence"] for p in h1_b_pairs if math.isfinite(p.get("death", float("inf")))]
            flags_b  = [p.get("flag", "") for p in h1_b_pairs if math.isfinite(p.get("death", float("inf")))]
            colors_b = ["#FF2D2D" if f == "STRUCTURAL_FALSEHOOD" else "#888" for f in flags_b]
            if births_b:
                fig_diff.add_trace(go.Scatter(
                    x=births_b, y=deaths_b,
                    mode="markers",
                    marker=dict(size=[max(6, min(20, p*40)) for p in pers_b],
                                color=colors_b, opacity=0.85, symbol="x"),
                    name=f"H₁ Doc B ({len(births_b)} ciclos)",
                ))

        # Diagonal de referencia
        max_val = max(
            max([p["death"] for p in h1_a_pairs if math.isfinite(p.get("death", float("inf")))], default=1),
            max([p["death"] for p in h1_b_pairs if math.isfinite(p.get("death", float("inf")))], default=1),
            1.0,
        )
        fig_diff.add_trace(go.Scatter(
            x=[0, max_val], y=[0, max_val],
            mode="lines",
            line=dict(color="rgba(255,177,0,0.20)", width=1, dash="dot"),
            name="Diagonal",
            showlegend=False,
        ))

        # Línea κD vertical
        fig_diff.add_vline(
            x=K_D, line_color="#FFB100", line_width=1, line_dash="dash",
            annotation_text=f"κD={K_D}",
            annotation_font_color=AMBER, annotation_font_size=9,
        )

        fig_diff.update_xaxes(title_text="Birth", color=AMBER, gridcolor="rgba(255,177,0,0.06)")
        fig_diff.update_yaxes(title_text="Death", color=AMBER, gridcolor="rgba(255,177,0,0.06)")
        fig_diff.update_layout(title=dict(
            text=f"Diagramas de Persistencia H₁ — {dr.verdict}",
            font=dict(size=11, color="#FF2D2D" if alert else AMBER),
        ))

        st.plotly_chart(fig_diff, use_container_width=True)

        # ── WASSERSTEIN como barra horizontal ─────────────────
        st.markdown("""
        <div class="section-title"><span>▸</span> ENERGÍA DE TRANSFORMACIÓN</div>
        """, unsafe_allow_html=True)

        max_w = max(dr.wasserstein_h1, dr.bottleneck_h1, K_D * 1.5, 0.01)
        for _label, _val, _color in [
            ("Wasserstein H₁ (energía total)", dr.wasserstein_h1,
             "#FF2D2D" if dr.wasserstein_h1 > K_D else "#00CC66"),
            ("Bottleneck (ciclo más perturbado)", dr.bottleneck_h1,
             "#FF2D2D" if dr.bottleneck_h1 > K_D * 0.5 else "#FFB100"),
        ]:
            pct = min(100, (_val / max_w) * 100)
            kd_marker_pct = min(100, (K_D / max_w) * 100)
            st.markdown(f"""
            <div style="margin-bottom:0.7rem;">
                <div style="font-size:0.60rem;color:rgba(255,177,0,0.55);
                            letter-spacing:0.08em;margin-bottom:0.25rem;">{_label}</div>
                <div style="position:relative;width:100%;height:22px;
                            background:rgba(255,177,0,0.06);border-radius:3px;
                            border:1px solid rgba(255,177,0,0.12);">
                    <div style="position:absolute;top:0;left:0;height:100%;
                                width:{pct:.1f}%;background:{_color};
                                border-radius:2px;opacity:0.75;"></div>
                    <!-- Línea κD -->
                    <div style="position:absolute;top:0;left:{kd_marker_pct:.1f}%;
                                width:2px;height:100%;background:#FFB100;
                                box-shadow:0 0 4px rgba(255,177,0,0.5);"></div>
                    <div style="position:absolute;top:0;left:0;width:100%;height:100%;
                                display:flex;align-items:center;padding-left:8px;">
                        <span style="font-size:0.65rem;font-family:monospace;
                                     color:#fff;font-weight:700;">
                            {_val:.4f}
                        </span>
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)

        # ── Summary técnico colapsable ────────────────────────
        with st.expander("◎ REPORTE TÉCNICO COMPLETO", expanded=False):
            st.code(dr.summary, language=None)
            st.markdown("<div style='margin-top:0.5rem'></div>", unsafe_allow_html=True)
            st.download_button(
                "⬇ EXPORTAR REPORTE DIFF (JSON)",
                data=dr.to_json(),
                file_name=f"diff_{dr.hash_a[:8]}_{dr.hash_b[:8]}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                mime="application/json",
                key="dl_diff_json",
            )


# ══════════════════════════════════════════════════════════════
# TAB 8: AUDITORÍA MASIVA — Peritaje Topográfico de Corpus
# ══════════════════════════════════════════════════════════════

with tab_batch:
    st.markdown("""
    <div class="section-title"><span>▸</span> AUDITORÍA MASIVA — PERITAJE TOPOGRÁFICO DE CORPUS</div>
    """, unsafe_allow_html=True)

    st.markdown(f"""
    <div style="border:1px solid rgba(255,177,0,0.18);border-radius:6px;
                padding:0.8rem 1.1rem;margin-bottom:1.2rem;
                background:rgba(255,177,0,0.04);font-size:0.72rem;
                color:rgba(255,177,0,0.65);letter-spacing:0.06em;line-height:1.7;">
    Procesá un corpus documental completo en segundos.
    La <strong style="color:#FFB100">Tasa de Integridad del Corpus (TIC)</strong>
    mide qué fracción de documentos supera κD = {K_D}.<br>
    Si TIC &lt; 50%, el sistema dispara la alerta
    <strong style="color:#FF2D2D">CORPUS COMPROMETIDO</strong>.
    Formatos soportados: <code>.txt</code>
    &nbsp;|&nbsp; <code>.pdf</code> (requiere PyMuPDF)
    &nbsp;|&nbsp; <code>.docx</code> (requiere python-docx)
    </div>
    """, unsafe_allow_html=True)

    # ── Configuración ─────────────────────────────────────────
    cfg_col1, cfg_col2 = st.columns([2, 1], gap="medium")
    with cfg_col1:
        batch_files = st.file_uploader(
            "Subir documentos para auditoría masiva",
            type=["txt", "pdf", "docx"],
            accept_multiple_files=True,
            key="batch_uploader",
            label_visibility="collapsed",
            help="Seleccioná múltiples archivos .txt / .pdf / .docx",
        )
    with cfg_col2:
        batch_itype = st.selectbox(
            "Tipo de documento",
            ["generic", "legal", "discourse", "finance", "code"],
            key="batch_itype",
        )
        btn_batch = st.button(
            "≣  EJECUTAR AUDITORÍA MASIVA",
            use_container_width=True,
            key="btn_batch",
        )

    # ── Ejecutar batch ────────────────────────────────────────
    if btn_batch:
        if not batch_files:
            st.warning("⚠ Subí al menos un archivo para auditar.")
        else:
            _auditor = BatchAuditor(kappa_d=K_D, input_type=batch_itype)
            _n       = len(batch_files)

            # Barra de Progreso Topológico
            st.markdown("""
            <div style="font-size:0.63rem;color:#FFB100;letter-spacing:0.12em;
                        margin-bottom:0.4rem;">
                BARRA DE PROGRESO TOPOLÓGICO
            </div>
            """, unsafe_allow_html=True)
            _prog_bar    = st.progress(0)
            _prog_status = st.empty()

            _batch_results: list[FileResult] = []
            _live_table   = st.empty()   # tabla de resultados en tiempo real

            for _i, _uf in enumerate(batch_files):
                _fname   = _uf.name
                _content = _uf.read()

                # Actualizar progreso
                _pct = int((_i / _n) * 100)
                _prog_bar.progress(_pct)
                _prog_status.markdown(
                    f'<span style="font-size:0.65rem;color:#FFB100;'
                    f'font-family:monospace;">▶ [{_i+1}/{_n}] '
                    f'analizando: {_fname}</span>',
                    unsafe_allow_html=True,
                )

                _res = _auditor._process_single(_fname, _content, batch_itype)
                _batch_results.append(_res)

                # Preview en tiempo real
                _live_rows = []
                for _r in _batch_results:
                    _s = f"{_r.manifold_score:.3f}" if _r.manifold_score >= 0 else "ERR"
                    _c = "🟢" if _r.passes_kd else ("🔴" if _r.status == "OK" else "⚪")
                    _live_rows.append(f"{_c} `{_r.filename[:45]}` — score: `{_s}` — `{_r.overall_verdict}`")
                _live_table.markdown("\n".join(_live_rows))

            # Finalizar progreso
            _prog_bar.progress(100)
            _prog_status.markdown(
                '<span style="font-size:0.65rem;color:#00CC66;'
                'font-family:monospace;">✓ AUDITORÍA COMPLETADA</span>',
                unsafe_allow_html=True,
            )

            # Construir reporte final
            import datetime as _dt
            _ts     = _dt.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
            _report = _auditor._build_report(_ts, _batch_results)
            st.session_state["batch_report"] = _report

    # ── Mostrar resultados ────────────────────────────────────
    br: BatchReport | None = st.session_state.get("batch_report")

    if br is not None:
        st.markdown("<div style='margin-top:1rem'></div>", unsafe_allow_html=True)

        # ── BANNER: CORPUS COMPROMETIDO ───────────────────────
        if br.corpus_compromised:
            st.markdown(f"""
            <div style="border:2px solid #FF2D2D;border-radius:6px;
                        padding:1rem 1.4rem;margin:0 0 1.2rem 0;
                        background:rgba(255,45,45,0.10);">
                <div style="font-size:0.90rem;color:#FF2D2D;letter-spacing:0.16em;
                            font-weight:700;margin-bottom:0.4rem;">
                    ⚠&nbsp; CORPUS COMPROMETIDO: Alta Densidad de Entropía Estructural
                </div>
                <div style="font-size:0.68rem;color:rgba(255,100,100,0.85);
                            letter-spacing:0.06em;line-height:1.8;">
                    TIC = <strong style="color:#FF2D2D">{br.tic:.1%}</strong>
                    — Menos del 50% de los documentos supera κD = {br.kappa_d}.<br>
                    El corpus presenta una densidad anómala de entropía estructural.
                    Se recomienda revisión forense documento por documento.
                </div>
            </div>
            """, unsafe_allow_html=True)

        # ── KPIs principales ──────────────────────────────────
        k1, k2, k3, k4, k5 = st.columns(5, gap="small")

        def _batch_kpi(col, label, val, color="#FFB100", sub=""):
            col.markdown(f"""
            <div style="border:1px solid rgba(255,177,0,0.22);border-radius:6px;
                        padding:0.7rem 0.6rem;background:rgba(255,177,0,0.04);
                        text-align:center;">
                <div style="font-size:0.55rem;color:rgba(255,177,0,0.55);
                            letter-spacing:0.10em;margin-bottom:0.3rem;">{label}</div>
                <div style="font-size:1.45rem;color:{color};font-family:monospace;
                            font-weight:700;line-height:1.1;">{val}</div>
                <div style="font-size:0.55rem;color:rgba(255,177,0,0.40);
                            margin-top:0.2rem;">{sub}</div>
            </div>
            """, unsafe_allow_html=True)

        _tic_color = "#00CC66" if br.tic >= 0.5 else "#FF2D2D"
        _batch_kpi(k1, "TIC — INTEGRIDAD", f"{br.tic:.1%}", _tic_color, br.corpus_verdict)
        _batch_kpi(k2, "MANIFOLD PROMEDIO",
                   f"{br.mean_manifold:.4f}",
                   "#00CC66" if br.mean_manifold >= K_D else "#FF2D2D",
                   f"κD = {K_D}")
        _batch_kpi(k3, "DOCUMENTOS CLEAR", str(br.clear_count), "#00CC66", "≥ κD estable")
        _batch_kpi(k4, "DOCUMENTOS HIGH_RISK", str(br.high_risk_count), "#FF2D2D", "bajo umbral κD")
        _batch_kpi(k5, "ERRORES / SKIPPED",
                   f"{br.errors + br.skipped}",
                   "#FFB100" if (br.errors + br.skipped) > 0 else "#888",
                   f"{br.errors} err · {br.skipped} omitidos")

        st.markdown("<div style='margin-top:0.8rem'></div>", unsafe_allow_html=True)

        # ── Gráfico de distribución de scores ─────────────────
        _ok_results = [r for r in br.results if r.status == "OK" and r.manifold_score >= 0]
        if _ok_results:
            st.markdown("""
            <div class="section-title"><span>▸</span> DISTRIBUCIÓN DE MANIFOLD SCORES</div>
            """, unsafe_allow_html=True)

            _fnames  = [r.filename[:30] for r in _ok_results]
            _scores  = [r.manifold_score for r in _ok_results]
            _colors  = ["#00CC66" if s >= K_D else "#FF2D2D" for s in _scores]
            _verdicts= [r.overall_verdict for r in _ok_results]

            fig_batch = go.Figure()
            fig_batch.add_trace(go.Bar(
                x=list(range(len(_fnames))),
                y=_scores,
                marker_color=_colors,
                marker_line_width=0,
                text=[f"{s:.3f}" for s in _scores],
                textposition="outside",
                textfont=dict(size=9, color=AMBER),
                customdata=list(zip(_fnames, _verdicts)),
                hovertemplate="<b>%{customdata[0]}</b><br>Score: %{y:.4f}<br>Veredicto: %{customdata[1]}<extra></extra>",
            ))

            # Línea κD
            fig_batch.add_hline(
                y=K_D, line_color="#FFB100", line_width=1.5, line_dash="dash",
                annotation_text=f"κD = {K_D} — Límite de Invarianza de Durante",
                annotation_font_color=AMBER, annotation_font_size=9,
                annotation_position="top right",
            )

            fig_batch.update_layout(
                paper_bgcolor="#000", plot_bgcolor="#0D0D0D",
                font=dict(family="IBM Plex Mono, monospace", color=AMBER, size=10),
                margin=dict(l=40, r=40, t=30, b=60),
                height=280,
                xaxis=dict(
                    tickvals=list(range(len(_fnames))),
                    ticktext=_fnames,
                    tickangle=-35,
                    color=AMBER,
                    gridcolor="rgba(255,177,0,0.05)",
                ),
                yaxis=dict(
                    range=[0, max(max(_scores) * 1.1, K_D * 1.3)],
                    color=AMBER,
                    gridcolor="rgba(255,177,0,0.08)",
                ),
                showlegend=False,
            )

            st.plotly_chart(fig_batch, use_container_width=True)

        # ── Tabla detallada ───────────────────────────────────
        st.markdown("""
        <div class="section-title"><span>▸</span> TABLA DE RESULTADOS</div>
        """, unsafe_allow_html=True)

        for _r in br.results:
            _sc = f"{_r.manifold_score:.4f}" if _r.manifold_score >= 0 else "ERR"
            _vcolor = (
                "#00CC66" if _r.overall_verdict == "CLEAR"
                else "#FF2D2D" if _r.overall_verdict == "HIGH_RISK"
                else "#FFB100"
            )
            _kd_flag = (
                '<span style="color:#00CC66">✓ κD</span>' if _r.passes_kd
                else '<span style="color:#FF2D2D">✗ κD</span>'
                if _r.status == "OK"
                else '<span style="color:#888">— </span>'
            )
            st.markdown(f"""
            <div style="display:flex;align-items:center;gap:0.8rem;
                        padding:0.35rem 0.6rem;
                        border-bottom:1px solid rgba(255,177,0,0.08);
                        font-size:0.68rem;font-family:monospace;">
                <span style="min-width:2rem;">{_kd_flag}</span>
                <span style="flex:1;color:rgba(255,177,0,0.85);
                             overflow:hidden;text-overflow:ellipsis;
                             white-space:nowrap;" title="{_r.filename}">{_r.filename}</span>
                <span style="min-width:5.5rem;color:#FFB100;">score: {_sc}</span>
                <span style="min-width:5rem;color:#FFB100;">coh: {_r.coherence_score:.3f if _r.coherence_score >= 0 else 'N/A'}</span>
                <span style="min-width:7rem;color:{_vcolor};font-weight:700;">{_r.overall_verdict}</span>
                <span style="min-width:4rem;color:rgba(255,177,0,0.45);">{_r.status}</span>
            </div>
            """, unsafe_allow_html=True)

        # ── Download Center ───────────────────────────────────
        st.markdown("""
        <div class="section-title" style="margin-top:1rem;">
            <span>▸</span> DOWNLOAD CENTER
        </div>
        """, unsafe_allow_html=True)

        _ts_str  = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        dc1, dc2 = st.columns(2, gap="medium")

        with dc1:
            _csv_data = _auditor.to_csv_bytes(br) if "batch_report" in st.session_state else b""
            if not _csv_data:
                _auditor_tmp = BatchAuditor(kappa_d=K_D)
                _csv_data = _auditor_tmp.to_csv_bytes(br)
            st.download_button(
                "⬇  EXPORTAR CSV CRUDO",
                data=_csv_data,
                file_name=f"batch_audit_{_ts_str}.csv",
                mime="text/csv",
                use_container_width=True,
                key="dl_batch_csv",
            )
            st.markdown(
                '<div style="font-size:0.60rem;color:rgba(255,177,0,0.40);'
                'margin-top:0.3rem;text-align:center;">Compatible con Excel, Sheets, LibreOffice</div>',
                unsafe_allow_html=True,
            )

        with dc2:
            try:
                _auditor_xl = BatchAuditor(kappa_d=K_D)
                _xlsx_data  = _auditor_xl.to_xlsx_bytes(br)
                st.download_button(
                    "⬇  EXPORTAR EXCEL COLOREADO (.xlsx)",
                    data=_xlsx_data,
                    file_name=f"batch_audit_{_ts_str}.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    use_container_width=True,
                    key="dl_batch_xlsx",
                )
                st.markdown(
                    '<div style="font-size:0.60rem;color:rgba(255,177,0,0.40);'
                    'margin-top:0.3rem;text-align:center;">'
                    'Formato condicional Durante · Verde κD≥0.56 · Rojo κD&lt;0.56</div>',
                    unsafe_allow_html=True,
                )
            except RuntimeError as _xe:
                st.warning(f"Excel no disponible: {_xe}")
                st.markdown(
                    '<div style="font-size:0.62rem;color:rgba(255,177,0,0.50);">'
                    'Instalar: <code>pip install openpyxl</code></div>',
                    unsafe_allow_html=True,
                )


# ══════════════════════════════════════════════════════════════
# TAB 9: ESCUDO DE INVARIANZA — Live Stream Firewall
# ══════════════════════════════════════════════════════════════

with tab_shield:
    st.markdown("""
    <div class="section-title"><span>▸</span> ESCUDO DE INVARIANZA — LIVE STREAM FIREWALL</div>
    """, unsafe_allow_html=True)

    st.markdown(f"""
    <div style="border:1px solid rgba(255,177,0,0.18);border-radius:6px;
                padding:0.8rem 1.1rem;margin-bottom:1.2rem;
                background:rgba(255,177,0,0.04);font-size:0.72rem;
                color:rgba(255,177,0,0.65);letter-spacing:0.06em;line-height:1.7;">
    Analiza texto token a token usando una <strong style="color:#FFB100">ventana deslizante</strong>.
    Si el ManifoldScore acumulado cae bajo κD = {K_D} durante N ventanas consecutivas,
    el sistema ejecuta una
    <strong style="color:#FF2D2D">Desconexión por Incoherencia</strong> — la válvula matemática de seguridad.<br>
    Útil para monitorear outputs de IA externas en tiempo real.
    </div>
    """, unsafe_allow_html=True)

    # ── Configuración del monitor ─────────────────────────────
    sh_col1, sh_col2, sh_col3 = st.columns(3, gap="small")
    with sh_col1:
        sh_window = st.slider("Tamaño de ventana (tokens)", 20, 200, 80, 10,
                               key="sh_window")
    with sh_col2:
        sh_step = st.slider("Paso deslizante", 10, 100, 40, 10,
                             key="sh_step")
    with sh_col3:
        sh_drops = st.slider("Drops consecutivos → DISCONNECT", 1, 8, 3, 1,
                              key="sh_drops")

    sh_text = st.text_area(
        "Texto a monitorear (output de IA u otro texto)",
        placeholder="Pegá el output de la IA externa a monitorear...",
        height=160,
        key="sh_text",
        label_visibility="collapsed",
    )

    btn_shield = st.button("⬡  ACTIVAR SHIELD — ANALIZAR STREAM",
                            use_container_width=True, key="btn_shield")

    if btn_shield:
        if not sh_text or len(sh_text.strip()) < 30:
            st.warning("⚠ Ingresá al menos 30 caracteres para monitorear.")
        else:
            with st.spinner("Analizando stream..."):
                _monitor = StreamMonitor(
                    kappa_d=K_D,
                    window_size=sh_window,
                    step_size=sh_step,
                    max_consecutive_drops=sh_drops,
                )
                _srep = _monitor.analyze_text_as_stream(sh_text)
                st.session_state["shield_report"] = _srep

    srep: StreamReport | None = st.session_state.get("shield_report")

    if srep is not None:
        # ── Estado final ──────────────────────────────────────
        _sh_color = "#FF2D2D" if srep.final_action == "DISCONNECTED" else "#00CC66"
        _sh_icon  = "⚡" if srep.final_action == "DISCONNECTED" else "✓"
        st.markdown(f"""
        <div style="border:2px solid {_sh_color};border-radius:6px;
                    padding:0.8rem 1.2rem;margin:0.5rem 0 1rem 0;
                    background:{'rgba(255,45,45,0.08)' if srep.final_action=='DISCONNECTED' else 'rgba(0,204,102,0.06)'};">
            <div style="font-size:0.82rem;color:{_sh_color};letter-spacing:0.14em;font-weight:700;">
                {_sh_icon} {srep.final_action}
                {'— Desconexión por Incoherencia' if srep.final_action=='DISCONNECTED' else '— Stream completado dentro del umbral'}
            </div>
            {'<div style="font-size:0.65rem;color:rgba(255,100,100,0.85);margin-top:0.4rem;">' + srep.disconnect_reason + '</div>' if srep.disconnect_reason else ''}
        </div>
        """, unsafe_allow_html=True)

        # ── KPIs ──────────────────────────────────────────────
        sk1, sk2, sk3, sk4 = st.columns(4, gap="small")

        def _sh_kpi(col, lbl, val, c="#FFB100"):
            col.markdown(f"""
            <div style="border:1px solid rgba(255,177,0,0.20);border-radius:5px;
                        padding:0.6rem;text-align:center;background:rgba(255,177,0,0.03);">
                <div style="font-size:0.55rem;color:rgba(255,177,0,0.50);letter-spacing:0.10em;">{lbl}</div>
                <div style="font-size:1.1rem;color:{c};font-family:monospace;font-weight:700;">{val}</div>
            </div>""", unsafe_allow_html=True)

        _sh_kpi(sk1, "SCORE PROMEDIO", f"{srep.mean_score:.4f}",
                "#00CC66" if srep.mean_score >= K_D else "#FF2D2D")
        _sh_kpi(sk2, "VENTANAS SEGURAS", f"{srep.windows_above_kd}/{srep.total_windows}")
        _sh_kpi(sk3, "INTEGRIDAD STREAM", f"{srep.integrity_ratio:.1%}",
                "#00CC66" if srep.integrity_ratio >= 0.7 else "#FF2D2D")
        _sh_kpi(sk4, "TOKENS PROCESADOS", str(srep.total_tokens))

        # ── Gráfico de scores por ventana ─────────────────────
        if srep.events:
            st.markdown("""
            <div class="section-title" style="margin-top:0.8rem;">
                <span>▸</span> SCORES POR VENTANA DESLIZANTE
            </div>""", unsafe_allow_html=True)

            _ev_scores  = [e.manifold_score for e in srep.events]
            _ev_actions = [e.action for e in srep.events]
            _ev_colors  = [
                "#FF2D2D" if a == "DISCONNECT"
                else "#FFB100" if a == "WARNING"
                else "#00CC66"
                for a in _ev_actions
            ]

            fig_sh = go.Figure()
            fig_sh.add_trace(go.Scatter(
                y=_ev_scores, mode="lines+markers",
                line=dict(color=AMBER, width=1.5),
                marker=dict(color=_ev_colors, size=8),
                name="ManifoldScore por ventana",
            ))
            fig_sh.add_hline(y=K_D, line_color="#FFB100", line_width=1.5,
                             line_dash="dash",
                             annotation_text=f"κD={K_D}",
                             annotation_font_color=AMBER, annotation_font_size=9)
            fig_sh.update_layout(
                paper_bgcolor="#000", plot_bgcolor="#0D0D0D",
                font=dict(family="IBM Plex Mono, monospace", color=AMBER, size=10),
                margin=dict(l=40, r=20, t=20, b=30), height=220,
                yaxis=dict(range=[0, 1], color=AMBER, gridcolor="rgba(255,177,0,0.06)"),
                xaxis=dict(title="Ventana #", color=AMBER),
                showlegend=False,
            )
            st.plotly_chart(fig_sh, use_container_width=True)


# ══════════════════════════════════════════════════════════════
# TAB 10: CALIBRACIÓN κD — Threshold Calibration UI
# ══════════════════════════════════════════════════════════════

with tab_calibrate:
    st.markdown("""
    <div class="section-title"><span>▸</span> CALIBRACIÓN κD — SOBERANÍA DEL UMBRAL</div>
    """, unsafe_allow_html=True)

    st.markdown(f"""
    <div style="border:1px solid rgba(255,177,0,0.18);border-radius:6px;
                padding:0.8rem 1.1rem;margin-bottom:1rem;
                background:rgba(255,177,0,0.04);font-size:0.72rem;
                color:rgba(255,177,0,0.65);letter-spacing:0.06em;line-height:1.7;">
    Ajustá κD en tiempo real. El <strong style="color:#FFB100">Punto de Equilibrio de Durante</strong>
    es κD = {K_D}. Alejarte de él activa advertencias de zona.<br>
    El slider <strong>no re-ejecuta el escaneo</strong> — recalcula solo la clasificación de
    ciclos H₁ y el veredicto. Operación instantánea.
    </div>
    """, unsafe_allow_html=True)

    # ── Texto a calibrar ──────────────────────────────────────
    _cal_text_src = st.radio(
        "Fuente del texto",
        ["Usar texto del último escaneo", "Ingresar texto nuevo"],
        horizontal=True, key="cal_src",
    )

    if _cal_text_src == "Usar texto del último escaneo":
        _cal_text = st.session_state.get("raw_text", "")
        if not _cal_text:
            st.info("Ejecutá un escaneo en la Terminal de Auditoría para cargar texto aquí.")
    else:
        _cal_text = st.text_area(
            "Texto para calibración",
            height=130, key="cal_text_input",
            label_visibility="collapsed",
            placeholder="Pegá el texto a calibrar...",
        )

    btn_cal_load = st.button("⚙  CARGAR Y ANALIZAR", key="btn_cal_load",
                              use_container_width=False)

    if btn_cal_load and _cal_text and len(_cal_text.strip()) > 20:
        with st.spinner("Cargando análisis base..."):
            _calibrator = ThresholdCalibrator()
            _base_result = _calibrator.load_text(_cal_text)
            st.session_state["calibrator"]    = _calibrator
            st.session_state["cal_base"]      = _base_result
            st.session_state["cal_kd_value"]  = K_D

    _cal = st.session_state.get("calibrator")
    _base = st.session_state.get("cal_base")

    if _cal is not None and _base is not None:

        # ── SLIDER κD ─────────────────────────────────────────
        st.markdown("<div style='margin-top:0.6rem'></div>", unsafe_allow_html=True)

        kd_slider = st.slider(
            "κD — Umbral de Invarianza",
            min_value=float(ThresholdCalibrator.SLIDER_MIN),
            max_value=float(ThresholdCalibrator.SLIDER_MAX),
            value=float(st.session_state.get("cal_kd_value", K_D)),
            step=0.01,
            key="kd_slider",
            format="%.2f",
        )
        st.session_state["cal_kd_value"] = kd_slider

        # Recalibrar en tiempo real
        _cr: CalibrationResult = _cal.recalibrate(kd_slider)

        # ── TERMÓMETRO DE κD ──────────────────────────────────
        _pct_slider   = ((kd_slider - ThresholdCalibrator.SLIDER_MIN) /
                         (ThresholdCalibrator.SLIDER_MAX - ThresholdCalibrator.SLIDER_MIN)) * 100
        _pct_durante  = ((K_D - ThresholdCalibrator.SLIDER_MIN) /
                         (ThresholdCalibrator.SLIDER_MAX - ThresholdCalibrator.SLIDER_MIN)) * 100
        _pct_golden_l = ((ThresholdCalibrator.GOLDEN_MIN - ThresholdCalibrator.SLIDER_MIN) /
                         (ThresholdCalibrator.SLIDER_MAX - ThresholdCalibrator.SLIDER_MIN)) * 100
        _pct_golden_r = ((ThresholdCalibrator.GOLDEN_MAX - ThresholdCalibrator.SLIDER_MIN) /
                         (ThresholdCalibrator.SLIDER_MAX - ThresholdCalibrator.SLIDER_MIN)) * 100

        _zone_color = (
            "#FF8C00" if _cr.zone == "RUIDO"
            else "#FF2D2D" if _cr.zone == "SOBRERESTRICCIÓN"
            else "#FFB100"
        )

        st.markdown(f"""
        <div style="margin:0.3rem 0 1.2rem 0;">
            <div style="font-size:0.60rem;color:#FFB100;letter-spacing:0.12em;margin-bottom:0.4rem;">
                RANGO DE CALIBRACIÓN [{ThresholdCalibrator.SLIDER_MIN:.2f} — {ThresholdCalibrator.SLIDER_MAX:.2f}]
            </div>
            <div style="position:relative;width:100%;height:28px;
                        background:rgba(255,177,0,0.06);border-radius:4px;
                        border:1px solid rgba(255,177,0,0.15);">
                <!-- Zona óptima (fondo verde suave) -->
                <div style="position:absolute;top:0;
                            left:{_pct_golden_l:.1f}%;
                            width:{_pct_golden_r - _pct_golden_l:.1f}%;
                            height:100%;background:rgba(0,204,102,0.08);
                            border-left:1px dashed rgba(0,204,102,0.35);
                            border-right:1px dashed rgba(0,204,102,0.35);">
                </div>
                <!-- Marcador κD actual -->
                <div style="position:absolute;top:-5px;
                            left:{_pct_slider:.1f}%;
                            width:3px;height:38px;
                            background:{_zone_color};
                            border-radius:2px;">
                </div>
                <!-- Línea dorada del Durante original -->
                <div style="position:absolute;top:-5px;
                            left:{_pct_durante:.1f}%;
                            width:2px;height:38px;
                            background:#FFB100;opacity:0.7;">
                </div>
                <!-- Etiqueta Durante -->
                <div style="position:absolute;top:-20px;
                            left:calc({_pct_durante:.1f}% - 30px);
                            font-size:0.55rem;color:#FFB100;
                            font-family:monospace;white-space:nowrap;">
                    ◆ {K_D}
                </div>
                <!-- Score del documento -->
                <div style="position:absolute;top:0;left:0;width:100%;height:100%;
                            display:flex;align-items:center;justify-content:center;">
                    <span style="font-size:0.68rem;font-family:monospace;
                                 color:rgba(255,177,0,0.60);">
                        κD = {kd_slider:.2f} &nbsp;|&nbsp;
                        ManifoldScore = {_cr.manifold_score:.4f} &nbsp;|&nbsp;
                        {'✓ PASA' if _cr.passes_kd else '✗ NO PASA'}
                    </span>
                </div>
            </div>
            <!-- Zona warning -->
            <div style="margin-top:0.4rem;font-size:0.63rem;color:{_zone_color};
                        letter-spacing:0.06em;">{_cr.zone_warning}</div>
        </div>
        """, unsafe_allow_html=True)

        # ── KPIs de la calibración ────────────────────────────
        cc1, cc2, cc3, cc4 = st.columns(4, gap="small")

        def _cal_kpi(col, lbl, val, c="#FFB100", sub=""):
            col.markdown(f"""
            <div style="border:1px solid rgba(255,177,0,0.20);border-radius:5px;
                        padding:0.6rem 0.5rem;text-align:center;
                        background:rgba(255,177,0,0.03);">
                <div style="font-size:0.52rem;color:rgba(255,177,0,0.50);
                            letter-spacing:0.08em;">{lbl}</div>
                <div style="font-size:1.05rem;color:{c};font-family:monospace;
                            font-weight:700;margin-top:0.15rem;">{val}</div>
                <div style="font-size:0.52rem;color:rgba(255,177,0,0.35);
                            margin-top:0.1rem;">{sub}</div>
            </div>""", unsafe_allow_html=True)

        _v_color = ("#00CC66" if _cr.overall_verdict == "CLEAR"
                    else "#FF2D2D" if _cr.overall_verdict == "HIGH_RISK" else "#FFB100")
        _cal_kpi(cc1, "VEREDICTO", _cr.overall_verdict, _v_color, f"κD={kd_slider:.2f}")
        _cal_kpi(cc2, "INTEGRIDAD TDA", f"{_cr.integrity_score:.4f}",
                 "#00CC66" if _cr.integrity_score >= 0.7 else "#FF2D2D",
                 _cr.topology_verdict[:18])
        _cal_kpi(cc3, "H₁ FALSEHOODS", str(_cr.h1_structural_falsehoods),
                 "#FF2D2D" if _cr.h1_structural_falsehoods > 0 else "#00CC66",
                 f"de {_cr.h1_total} ciclos totales")
        _cal_kpi(cc4, "ZONA κD", _cr.zone, _zone_color,
                 f"Equilibrio: {K_D}")

        # ── Curva de sensibilidad ─────────────────────────────
        st.markdown("""
        <div class="section-title" style="margin-top:0.9rem;">
            <span>▸</span> CURVA DE SENSIBILIDAD κD
        </div>""", unsafe_allow_html=True)

        with st.spinner("Calculando curva..."):
            _sweep = _cal.sweep(n_steps=30)

        _sweep_kd  = [r.kappa_d for r in _sweep]
        _sweep_int = [r.integrity_score for r in _sweep]
        _sweep_h1  = [r.h1_structural_falsehoods for r in _sweep]
        _v_colors  = [
            "#00CC66" if r.overall_verdict == "CLEAR"
            else "#FF2D2D" if r.overall_verdict == "HIGH_RISK"
            else "#FFB100"
            for r in _sweep
        ]

        fig_cal = go.Figure()
        fig_cal.add_trace(go.Scatter(
            x=_sweep_kd, y=_sweep_int,
            mode="lines+markers",
            name="Integridad TDA",
            line=dict(color=AMBER, width=2),
            marker=dict(color=_v_colors, size=7),
        ))
        fig_cal.add_trace(go.Scatter(
            x=_sweep_kd,
            y=[h/max(max(_sweep_h1), 1) for h in _sweep_h1],
            mode="lines",
            name="H₁ Falsehoods (norm.)",
            line=dict(color="#FF2D2D", width=1.5, dash="dot"),
        ))
        # Marcador κD actual
        fig_cal.add_vline(x=kd_slider, line_color=_zone_color,
                          line_width=2, line_dash="solid",
                          annotation_text=f"κD={kd_slider:.2f}",
                          annotation_font_color=_zone_color, annotation_font_size=9)
        # Marcador Durante
        fig_cal.add_vline(x=K_D, line_color="#FFB100", line_width=1,
                          line_dash="dash",
                          annotation_text=f"Durante {K_D}",
                          annotation_font_color=AMBER, annotation_font_size=8,
                          annotation_position="top left")
        # Zona óptima
        fig_cal.add_vrect(
            x0=ThresholdCalibrator.GOLDEN_MIN,
            x1=ThresholdCalibrator.GOLDEN_MAX,
            fillcolor="rgba(0,204,102,0.05)",
            line_width=0,
            annotation_text="zona óptima",
            annotation_font_color="rgba(0,204,102,0.5)",
            annotation_font_size=8,
        )
        fig_cal.update_layout(
            paper_bgcolor="#000", plot_bgcolor="#0D0D0D",
            font=dict(family="IBM Plex Mono, monospace", color=AMBER, size=10),
            margin=dict(l=40, r=20, t=20, b=40), height=250,
            xaxis=dict(title="κD", color=AMBER, gridcolor="rgba(255,177,0,0.06)"),
            yaxis=dict(title="Score [0–1]", color=AMBER,
                       gridcolor="rgba(255,177,0,0.06)", range=[0, 1.05]),
            legend=dict(bgcolor="rgba(0,0,0,0)", font=dict(size=9)),
        )
        st.plotly_chart(fig_cal, use_container_width=True)


# ══════════════════════════════════════════════════════════════
# TAB 11: FORENSIC LEDGER VANGUARD
# ══════════════════════════════════════════════════════════════

with tab_ledger2:
    st.markdown("""
    <div class="section-title"><span>▸</span> FORENSIC LEDGER VANGUARD — REGISTRO HISTÓRICO DE LA VERDAD</div>
    """, unsafe_allow_html=True)

    st.markdown("""
    <div style="border:1px solid rgba(255,177,0,0.18);border-radius:6px;
                padding:0.8rem 1.1rem;margin-bottom:1rem;
                background:rgba(255,177,0,0.04);font-size:0.72rem;
                color:rgba(255,177,0,0.65);letter-spacing:0.06em;line-height:1.7;">
    Cada veredicto se sella con <strong style="color:#FFB100">SHA-256 encadenado</strong>
    — el hash del registro anterior incluido en el siguiente. Cualquier modificación
    retrospectiva rompe la cadena y es detectada por la verificación de integridad.<br>
    Esquema blockchain listo: el método
    <code>to_chain_payload()</code> exporta cada bloque para grabación
    on-chain (compatible con EVM/Ethereum).
    </div>
    """, unsafe_allow_html=True)

    # Inicializar ledger global
    _vlg = get_global_ledger(kappa_d=K_D)

    # ── Registrar veredicto del escaneo actual ────────────────
    _cur_report = st.session_state.get("report")
    if _cur_report:
        _raw_text_for_ledger = st.session_state.get("raw_text", "")
        btn_ledger_reg = st.button(
            "⛓  SELLAR VEREDICTO ACTUAL EN EL LEDGER",
            use_container_width=False, key="btn_ledger_reg",
        )
        if btn_ledger_reg and _raw_text_for_ledger:
            try:
                _lb = _vlg.register(
                    raw_text       = _raw_text_for_ledger,
                    manifold_score = _cur_report.manifold_score,
                    overall_verdict= _cur_report.overall_verdict,
                    topology_flag  = _cur_report.topology_flag,
                    coherence_score= _cur_report.coherence_score,
                    input_type     = _cur_report.input_type,
                )
                st.success(f"✓ Bloque #{_lb.block_index} sellado — hash: {_lb.block_hash[:32]}...")
            except Exception as _le:
                st.error(f"Error al registrar: {_le}")
    else:
        st.info("Ejecutá un escaneo en la Terminal de Auditoría para habilitar el sellado.")

    # ── Verificación de integridad ────────────────────────────
    st.markdown("""
    <div class="section-title" style="margin-top:0.8rem;">
        <span>▸</span> INTEGRIDAD DE LA CADENA
    </div>""", unsafe_allow_html=True)

    btn_verify = st.button("⛓  VERIFICAR CADENA COMPLETA", key="btn_verify_chain")

    if btn_verify:
        _vir = _vlg.verify_chain()
        st.session_state["ledger_integrity"] = _vir

    _vir = st.session_state.get("ledger_integrity")
    if _vir is not None:
        _intact_color = "#00CC66" if _vir.chain_intact else "#FF2D2D"
        st.markdown(f"""
        <div style="border:2px solid {_intact_color};border-radius:6px;
                    padding:0.8rem 1.2rem;margin:0.5rem 0;">
            <div style="font-size:0.78rem;color:{_intact_color};
                        letter-spacing:0.12em;font-weight:700;">
                {'✓ CADENA ÍNTEGRA' if _vir.chain_intact else '⚠ TAMPERING DETECTADO'}
            </div>
            <div style="font-size:0.65rem;color:rgba(255,177,0,0.65);
                        margin-top:0.5rem;line-height:1.8;font-family:monospace;">
                Bloques totales : {_vir.total_blocks}<br>
                Bloques válidos : {_vir.valid_blocks}<br>
                Bloques alterados: {len(_vir.tampered_blocks)}
                {' → ' + str(_vir.tampered_blocks) if _vir.tampered_blocks else ''}<br>
                Hash de verificación: {_vir.verification_hash}
            </div>
        </div>
        """, unsafe_allow_html=True)

    # ── Registros recientes ───────────────────────────────────
    st.markdown("""
    <div class="section-title" style="margin-top:0.8rem;">
        <span>▸</span> REGISTROS RECIENTES
    </div>""", unsafe_allow_html=True)

    _recent = _vlg.get_recent(n=15)
    if _recent:
        for _b in reversed(_recent):
            _bc = ("#00CC66" if _b.overall_verdict == "CLEAR"
                   else "#FF2D2D" if _b.overall_verdict == "HIGH_RISK" else "#FFB100")
            st.markdown(f"""
            <div style="font-size:0.65rem;font-family:monospace;
                        padding:0.35rem 0.6rem;
                        border-bottom:1px solid rgba(255,177,0,0.07);">
                <span style="color:rgba(255,177,0,0.40);">#{_b.block_index:04d}</span>
                &nbsp;
                <span style="color:rgba(255,177,0,0.55);">{_b.timestamp}</span>
                &nbsp;
                <span style="color:{_bc};font-weight:700;">{_b.overall_verdict:10s}</span>
                &nbsp;
                <span style="color:#FFB100;">score={_b.manifold_score:.4f}</span>
                &nbsp;
                <span style="color:rgba(255,177,0,0.35);">{_b.block_hash[:24]}...</span>
            </div>
            """, unsafe_allow_html=True)

        # Export
        st.markdown("<div style='margin-top:0.7rem'></div>", unsafe_allow_html=True)
        ld1, ld2 = st.columns(2, gap="small")
        with ld1:
            st.download_button(
                "⬇  EXPORTAR LEDGER (JSON)",
                data=_vlg.export_json(),
                file_name=f"vanguard_ledger_{datetime.datetime.now().strftime('%Y%m%d')}.json",
                mime="application/json",
                key="dl_ledger_json",
            )
        with ld2:
            if _recent:
                _chain_payloads = json.dumps(
                    [_b.to_chain_payload() for _b in _recent],
                    indent=2, ensure_ascii=False,
                )
                st.download_button(
                    "⬇  EXPORTAR PARA BLOCKCHAIN (JSON)",
                    data=_chain_payloads,
                    file_name=f"chain_payloads_{datetime.datetime.now().strftime('%Y%m%d')}.json",
                    mime="application/json",
                    key="dl_chain_payloads",
                )
    else:
        st.markdown(
            '<div class="terminal-output">'
            '<span class="log-dim">$ Ledger vacío. '
            'Ejecutá un escaneo y sellá el veredicto para crear el primer bloque.</span></div>',
            unsafe_allow_html=True,
        )


# ══════════════════════════════════════════════════════════════
# TAB 12: LOG DE SISTEMA
# ══════════════════════════════════════════════════════════════

with tab_log:
    st.markdown("""
    <div class="section-title"><span>▸</span> TERMINAL DE LOG</div>
    """, unsafe_allow_html=True)

    # Log de sesión actual
    session_log = st.session_state.get("scan_log", [])
    if session_log:
        log_html = "<br>".join(f"$ {line}" for line in session_log)
    else:
        log_html = '<span class="log-dim">$ Sistema iniciado. En espera de operaciones.</span>'

    st.markdown(
        f'<div class="terminal-output">{log_html}</div>',
        unsafe_allow_html=True,
    )

    st.markdown("<div style='margin-top:1rem'></div>", unsafe_allow_html=True)

    # Historial persistente del archivo de log
    st.markdown("""
    <div class="section-title"><span>▸</span> HISTORIAL DE ESCANEOS</div>
    """, unsafe_allow_html=True)

    history = CONNECTOR.load_history(last_n=50)
    if history:
        hist_html = "<br>".join(f'<span class="log-dim">{line}</span>'
                                for line in reversed(history))
        st.markdown(
            f'<div class="terminal-output">{hist_html}</div>',
            unsafe_allow_html=True,
        )
        st.download_button(
            "⬇  EXPORTAR HISTORIAL",
            data="\n".join(history),
            file_name=f"scan_history_{datetime.datetime.now().strftime('%Y%m%d')}.log",
            mime="text/plain",
        )
    else:
        st.markdown(
            '<div class="terminal-output">'
            '<span class="log-dim">$ Sin historial previo.</span></div>',
            unsafe_allow_html=True,
        )

    # Footer
    st.markdown(f"""
    <div style="margin-top:2rem;padding-top:0.8rem;
                border-top:1px solid rgba(255,177,0,0.15);
                font-size:0.62rem;color:rgba(255,177,0,0.30);
                letter-spacing:0.12em;text-align:center;">
    OMNI-SCANNER SEMÁNTICO v1.0 &nbsp;·&nbsp; PROTOCOLO ANEXA ULTRA v4.0
    &nbsp;·&nbsp; κD = {K_D} &nbsp;·&nbsp;
    {datetime.datetime.now().strftime('%Y-%m-%d')}
    </div>
    """, unsafe_allow_html=True)
