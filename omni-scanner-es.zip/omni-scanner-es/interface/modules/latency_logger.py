"""
interface/modules/latency_logger.py
─────────────────────────────────────
Métrica de Latencia de Inferencia — Módulo v5.5

Registra tiempos de respuesta de llamadas a APIs de inferencia.
Permite detectar variaciones en latencia que pueden indicar
procesos de filtrado, carga diferencial por tipo de contenido,
o throttling selectivo.

QUÉ MIDE Y QUÉ NO MIDE:
  ✓ Tiempo total de respuesta por llamada (ms)
  ✓ Varianza entre llamadas del mismo tipo de consulta
  ✓ Anomalías estadísticas (outliers) en la distribución de latencias
  ✓ Correlación entre tipo de contenido y tiempo de respuesta

  ✗ NO puede medir latencia interna del modelo (es opaca)
  ✗ NO puede distinguir entre carga de servidor y filtrado
  ✗ La interpretación causal requiere análisis estadístico externo
     sobre series suficientemente largas (≥30 muestras)

HONESTIDAD TÉCNICA:
  La latencia de red tiene múltiples variables confundidoras
  (CDN, carga del servidor, longitud del output, tipo de tokens).
  Los datos aquí registrados son la materia prima para análisis
  estadístico propio. No se hace inferencia causal automática.
"""
from __future__ import annotations

import time
import json
import datetime
import statistics
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Any


LATENCY_LOG_PATH = Path(__file__).resolve().parent.parent.parent / "logs" / "latency_log.jsonl"


@dataclass
class LatencyEntry:
    timestamp:       str
    query_type:      str    # "legal", "code", "discourse", etc.
    query_hash:      str    # hash del prompt (nunca el texto)
    latency_ms:      float
    output_tokens_est: int  # estimación: len(response) / 4
    tokens_per_ms:   float
    anomaly_flag:    bool   = False
    notes:           str    = ""

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items()}


@dataclass
class LatencyStats:
    count:         int   = 0
    mean_ms:       float = 0.0
    median_ms:     float = 0.0
    stdev_ms:      float = 0.0
    min_ms:        float = 0.0
    max_ms:        float = 0.0
    outlier_count: int   = 0
    outlier_pct:   float = 0.0
    by_type:       dict  = field(default_factory=dict)


class LatencyLogger:
    """
    Context manager y logger para medir latencia de llamadas a API.

    Uso como context manager:
        with LatencyLogger.measure("legal") as timer:
            response = call_api(prompt)
        timer.record(response_text)

    Uso manual:
        t0 = LatencyLogger.start()
        response = call_api(prompt)
        LatencyLogger.record(t0, "legal", response_text, prompt)
    """

    def __init__(self, query_type: str = "generic"):
        self.query_type = query_type
        self._t0: float = 0.0
        self._entry: LatencyEntry | None = None

    def __enter__(self):
        self._t0 = time.perf_counter()
        return self

    def __exit__(self, *_):
        pass

    def record(self, response_text: str, prompt: str = "") -> LatencyEntry:
        """Finaliza la medición y guarda la entrada."""
        import hashlib
        elapsed_ms    = (time.perf_counter() - self._t0) * 1000
        tokens_est    = max(1, len(response_text) // 4)
        tokens_per_ms = tokens_est / elapsed_ms if elapsed_ms > 0 else 0
        query_hash    = hashlib.md5(prompt.encode("utf-8", errors="replace")).hexdigest()[:12]

        entry = LatencyEntry(
            timestamp       = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z",
            query_type      = self.query_type,
            query_hash      = query_hash,
            latency_ms      = round(elapsed_ms, 2),
            output_tokens_est = tokens_est,
            tokens_per_ms   = round(tokens_per_ms, 4),
        )
        self._entry = entry
        _append_latency(entry)
        return entry

    @property
    def entry(self) -> LatencyEntry | None:
        return self._entry


def _append_latency(entry: LatencyEntry) -> None:
    """Guarda una entrada en el log JSONL (append-only)."""
    LATENCY_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(LATENCY_LOG_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry.to_dict(), ensure_ascii=False) + "\n")


def read_latency_log(last_n: int | None = None) -> list[LatencyEntry]:
    """Lee el log de latencias."""
    if not LATENCY_LOG_PATH.exists():
        return []
    entries = []
    with open(LATENCY_LOG_PATH, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    d = json.loads(line)
                    entries.append(LatencyEntry(**d))
                except Exception:
                    pass
    return entries[-last_n:] if last_n else entries


def compute_stats(entries: list[LatencyEntry] | None = None) -> LatencyStats:
    """
    Calcula estadísticas descriptivas del log de latencias.
    Marca como outliers los valores > media + 2*stdev.
    """
    if entries is None:
        entries = read_latency_log()
    stats = LatencyStats()
    if not entries:
        return stats

    latencies = [e.latency_ms for e in entries]
    stats.count    = len(latencies)
    stats.mean_ms  = round(statistics.mean(latencies), 2)
    stats.median_ms = round(statistics.median(latencies), 2)
    stats.min_ms   = round(min(latencies), 2)
    stats.max_ms   = round(max(latencies), 2)

    if len(latencies) >= 2:
        stats.stdev_ms = round(statistics.stdev(latencies), 2)
        threshold = stats.mean_ms + 2 * stats.stdev_ms
        outliers  = [l for l in latencies if l > threshold]
        stats.outlier_count = len(outliers)
        stats.outlier_pct   = round(len(outliers) / len(latencies) * 100, 1)

    # Agrupar por tipo
    by_type: dict[str, list[float]] = {}
    for e in entries:
        by_type.setdefault(e.query_type, []).append(e.latency_ms)
    stats.by_type = {
        t: {
            "count":  len(v),
            "mean":   round(statistics.mean(v), 2),
            "median": round(statistics.median(v), 2),
        }
        for t, v in by_type.items()
    }
    return stats
