"""
interface/modules/ghost_audit.py
─────────────────────────────────
Ghost Audit — Analizador de Pérdida de Potencial Semántico

Detecta texto "corporativo/vacío": alto en palabras de relleno,
bajo en densidad informacional real. Emite alerta de Degradación
Semántica cuando la entropía léxica cae bajo el umbral.

METODOLOGÍA:
  · Lexical Entropy: entropía de Shannon sobre distribución de palabras
  · Type-Token Ratio (TTR): diversidad léxica = vocab_único / total_tokens
  · Corporate Buzzword Density: frecuencia de términos vacíos conocidos
  · Syntactic Flatness: varianza en longitud de oraciones (baja = monótono)
  · Information Density Score: combinación ponderada de las anteriores

Niveles de alerta:
  DEGRADACIÓN CRÍTICA  → score < 0.25
  RIESGO SEMÁNTICO     → score < 0.45
  POTENCIAL REDUCIDO   → score < 0.60
  SALUDABLE            → score ≥ 0.60
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import List


# ── Diccionario de buzzwords corporativos vacíos ──────────────
# Incluye términos en español e inglés comunes en documentos "vacíos"
CORPORATE_BUZZWORDS: set[str] = {
    # Gestión vacía (ES)
    "sinergia", "sinergias", "alineamiento", "alinear", "robusto", "robusta",
    "escalable", "escalabilidad", "empoderamiento", "empoderar", "paradigma",
    "holístico", "holística", "ecosistema", "proactivo", "proactiva",
    "innovador", "innovadora", "disruptivo", "disruptiva", "transversal",
    "estratégico", "estratégica", "optimizar", "optimización",
    "valor agregado", "core", "mindset", "feedback", "roadmap",
    "stakeholder", "stakeholders", "deliverable", "benchmark",
    "best practice", "best practices", "kpi", "okr",
    # Management empty (EN)
    "leverage", "synergy", "synergies", "paradigm", "holistic",
    "scalable", "scalability", "ecosystem", "proactive", "innovative",
    "disruptive", "streamline", "optimize", "optimization",
    "value-added", "actionable", "impactful", "robust", "seamless",
    "cutting-edge", "state-of-the-art", "world-class", "best-in-class",
    "game-changer", "game-changing", "next-level", "mission-critical",
    "move the needle", "low-hanging fruit", "circle back",
    "bandwidth", "pivot", "agile", "nimble", "thought leader",
    # Jerga legal vacía
    "en virtud de lo anterior", "a los efectos de", "en el marco de",
    "en atención a", "habida cuenta", "no obstante lo anterior",
    "sin perjuicio de", "de conformidad con",
}

# Marcadores de texto generado por templates (repetición estructural)
TEMPLATE_MARKERS = [
    r'\b(la empresa|the company)\b.{0,30}\b(se reserva|reserves)\b',
    r'\b(cualquier|any)\b.{0,20}\b(será considerado|shall be deemed)\b',
    r'\b(el presente|this agreement|this document)\b.{0,20}\b(rige|governs)\b',
    r'\bnull and void\b',
    r'\bnulo de pleno derecho\b',
    r'\birrevocablemente\b.{0,30}\brenuncia\b',
]


@dataclass
class GhostAuditReport:
    """Resultado del análisis de degradación semántica."""
    overall_score:       float = 1.0     # 0=vacío, 1=rico
    alert_level:         str   = "SALUDABLE"
    lexical_entropy:     float = 0.0
    type_token_ratio:    float = 0.0
    buzzword_density:    float = 0.0
    syntactic_flatness:  float = 0.0
    template_hits:       list  = field(default_factory=list)
    buzzwords_found:     list  = field(default_factory=list)
    token_count:         int   = 0
    unique_tokens:       int   = 0
    summary:             str   = ""
    recommendation:      str   = ""


class GhostAuditor:
    """
    Analiza texto buscando señales de vacío semántico:
    lenguaje corporativo repetitivo, baja densidad informacional,
    estructuras de template.
    """

    def __init__(
        self,
        entropy_floor: float   = 0.60,   # umbral mínimo de entropía normalizada
        ttr_floor:     float   = 0.30,   # TTR mínimo aceptable
        buzzword_ceil: float   = 0.08,   # máximo 8% de buzzwords antes de alertar
    ):
        self.entropy_floor  = entropy_floor
        self.ttr_floor      = ttr_floor
        self.buzzword_ceil  = buzzword_ceil

    # ── Tokenización ──────────────────────────────────────────

    @staticmethod
    def _tokenize(text: str) -> list[str]:
        """Tokens de palabras, lowercased, sin puntuación."""
        return re.findall(r'\b[a-záéíóúñüA-ZÁÉÍÓÚÑÜ]{3,}\b', text.lower())

    @staticmethod
    def _sentences(text: str) -> list[str]:
        """Divide en oraciones por puntuación."""
        parts = re.split(r'[.!?;]+', text)
        return [p.strip() for p in parts if len(p.strip()) > 10]

    # ── Métricas individuales ─────────────────────────────────

    def _lexical_entropy(self, tokens: list[str]) -> float:
        """
        Entropía de Shannon sobre distribución de palabras.
        Normalizada por log2(N) para que 1.0 = distribución perfectamente uniforme.
        """
        if len(tokens) < 5:
            return 0.0
        freq: dict[str, int] = {}
        for t in tokens:
            freq[t] = freq.get(t, 0) + 1
        n = len(tokens)
        h = -sum((c / n) * math.log2(c / n) for c in freq.values())
        max_h = math.log2(n) if n > 1 else 1.0
        return h / max_h

    def _type_token_ratio(self, tokens: list[str]) -> float:
        """TTR = tokens únicos / total tokens. Corregido para textos largos."""
        if not tokens:
            return 0.0
        # RTTR (Root TTR) — más estable para textos de distinta longitud
        return len(set(tokens)) / math.sqrt(len(tokens))

    def _buzzword_density(self, tokens: list[str], text_lower: str) -> tuple[float, list[str]]:
        """Proporción de buzzwords sobre total de tokens."""
        if not tokens:
            return 0.0, []
        found = []
        # Palabras sueltas
        token_set = set(tokens)
        for bw in CORPORATE_BUZZWORDS:
            if " " in bw:
                if bw in text_lower:
                    found.append(bw)
            elif bw in token_set:
                found.append(bw)
        density = len([t for t in tokens if t in CORPORATE_BUZZWORDS]) / len(tokens)
        return density, list(set(found))

    def _syntactic_flatness(self, sentences: list[str]) -> float:
        """
        Varianza en longitud de oraciones.
        Textos monótonos (misma longitud siempre) tienen baja varianza → alta flatness.
        Retorna flatness ∈ [0,1]: 1 = completamente plano.
        """
        if len(sentences) < 3:
            return 0.5  # insuficiente para medir
        lens = [len(s.split()) for s in sentences]
        mean = sum(lens) / len(lens)
        var  = sum((l - mean) ** 2 for l in lens) / len(lens)
        # Normalizar: varianza alta (>50) = dinámico = baja flatness
        flatness = 1.0 - min(var / 50.0, 1.0)
        return flatness

    def _template_hits(self, text: str) -> list[str]:
        """Busca marcadores de texto generado por templates."""
        hits = []
        text_lower = text.lower()
        for pattern in TEMPLATE_MARKERS:
            if re.search(pattern, text_lower):
                hits.append(pattern.replace(r'\b', '').replace('(', '').split('.')[0][:50])
        return hits

    # ── Análisis principal ────────────────────────────────────

    def analyze(self, text: str) -> GhostAuditReport:
        """
        Analiza el texto y retorna un GhostAuditReport.
        """
        report = GhostAuditReport()

        if not text or len(text.strip()) < 20:
            report.alert_level  = "INSUFICIENTE"
            report.summary      = "Texto demasiado corto para análisis."
            return report

        tokens      = self._tokenize(text)
        sentences   = self._sentences(text)
        text_lower  = text.lower()

        if len(tokens) < 5:
            report.alert_level = "INSUFICIENTE"
            report.summary     = "Vocabulario insuficiente."
            return report

        # Calcular métricas
        lex_h       = self._lexical_entropy(tokens)
        ttr         = self._type_token_ratio(tokens)
        bwd, bwords = self._buzzword_density(tokens, text_lower)
        flatness    = self._syntactic_flatness(sentences)
        tmpl_hits   = self._template_hits(text)

        # Normalizar TTR a [0,1]  (RTTR típico: 2–8 para textos naturales)
        ttr_norm = min(ttr / 6.0, 1.0)

        # Score compuesto (mayor = más rico semánticamente)
        # buzzword y flatness son penalizaciones (invertidas)
        bwd_penalty      = min(bwd / self.buzzword_ceil, 1.0)
        flatness_penalty = flatness
        tmpl_penalty     = min(len(tmpl_hits) * 0.15, 0.45)

        overall = (
            lex_h    * 0.35
            + ttr_norm * 0.30
            + (1.0 - bwd_penalty)      * 0.20
            + (1.0 - flatness_penalty) * 0.10
            + (1.0 - tmpl_penalty)     * 0.05
        )
        overall = max(0.0, min(1.0, overall))

        # Nivel de alerta
        if overall < 0.25:
            level = "DEGRADACIÓN CRÍTICA"
            rec   = ("El texto presenta señales severas de vaciamiento semántico. "
                     "Alta probabilidad de lenguaje generado por template o IA sin revisión crítica.")
        elif overall < 0.45:
            level = "RIESGO SEMÁNTICO"
            rec   = ("Densidad informacional baja. Exceso de términos de relleno. "
                     "Revisar y enriquecer con argumentos específicos y datos concretos.")
        elif overall < 0.60:
            level = "POTENCIAL REDUCIDO"
            rec   = ("El texto es funcional pero tiene margen de mejora en originalidad léxica. "
                     "Reducir repetición y aumentar especificidad técnica.")
        else:
            level = "SALUDABLE"
            rec   = "Densidad semántica adecuada. Sin señales de degradación."

        report.overall_score      = round(overall, 4)
        report.alert_level        = level
        report.lexical_entropy    = round(lex_h, 4)
        report.type_token_ratio   = round(ttr_norm, 4)
        report.buzzword_density   = round(bwd, 4)
        report.syntactic_flatness = round(flatness, 4)
        report.template_hits      = tmpl_hits
        report.buzzwords_found    = bwords[:15]
        report.token_count        = len(tokens)
        report.unique_tokens      = len(set(tokens))
        report.recommendation     = rec
        report.summary = (
            f"Entropía léxica: {lex_h:.3f} | TTR: {ttr:.3f} | "
            f"Buzzwords: {bwd:.1%} ({len(bwords)}) | "
            f"Templates: {len(tmpl_hits)} | Score: {overall:.4f}"
        )
        return report
