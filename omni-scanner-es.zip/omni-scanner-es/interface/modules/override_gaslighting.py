"""
interface/modules/override_gaslighting.py
──────────────────────────────────────────
Override-Gaslighting Detector — Módulo v5.5

Detecta frases de neutralización de autoridad técnica: patrones
lingüísticos que invalidan, redirigen o minimizan la autoría,
el conocimiento experto o la posición de quien escribe.

Diferencia respecto a SocialEngineer (ya existente):
  - SocialEngineer detecta manipulación GENERAL en discurso
  - Este módulo detecta específicamente NEUTRALIZACIÓN DE AUTORIDAD
    TÉCNICA en contextos de propiedad intelectual, negociación y
    comunicación corporativa.

Categorías detectadas:
  1. MINIMIZACIÓN DE EXPERTISE: "cualquiera puede hacer eso"
  2. REDIRECCIÓN DE PROPÓSITO: "eso no es lo que acordamos"
  3. INVALIDACIÓN DE EVIDENCIA: "eso no es suficiente prueba"
  4. DILUCIÓN DE AUTORÍA: "fue un trabajo de equipo"
  5. GASLIGHTING INSTITUCIONAL: "nunca dijimos eso"
  6. PRESIÓN DE CONFORMIDAD: "todos están de acuerdo menos vos"
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List


# ── Patrones por categoría ────────────────────────────────────

MINIMIZE_EXPERTISE = [
    r"cualquiera\s+(puede|podría|hubiera)\s+(hacer|haber\s+hecho)",
    r"no\s+(es|fue)\s+tan\s+(difícil|complejo|innovador)",
    r"eso\s+(ya\s+exist[eí]a|es\s+conocido|es\s+estándar)",
    r"no\s+(inventaste|descubriste|creaste)\s+nada\s+nuevo",
    r"es\s+(obvio|trivial|básico|elemental)",
    r"no\s+requiere?\s+(conocimiento|expertise|experiencia)\s+especial",
    r"lo\s+(hace|haría)\s+cualquier\s+(programador|técnico|persona)",
    r"no\s+es\s+(un\s+)?(descubrimiento|innovación|aporte)",
]

REDIRECT_PURPOSE = [
    r"eso\s+no\s+es\s+lo\s+que\s+(acordamos|pedimos|necesitamos)",
    r"se\s+está\s+(desviando|alejando)\s+del\s+(tema|objetivo|punto)",
    r"(volvamos|regresemos)\s+al\s+(punto|tema|asunto)\s+principal",
    r"eso\s+no\s+(es\s+relevante|viene\s+al\s+caso|aplica\s+aquí)",
    r"no\s+es\s+(el\s+momento|el\s+lugar)\s+para\s+esto",
    r"concentrémonos\s+en\s+lo\s+que\s+(importa|es\s+urgente)",
]

INVALIDATE_EVIDENCE = [
    r"eso\s+no\s+(es|constituye)\s+(suficiente\s+)?(prueba|evidencia)",
    r"no\s+(tiene|hay)\s+valor\s+(legal|probatorio|técnico)",
    r"(sin|falta)\s+(firma|notarización|certificación)\s+oficial",
    r"no\s+(está|fue)\s+(registrado|validado|certificado)",
    r"(cualquier\s+juez|un\s+tribunal)\s+(desestimar[ía]|rechazar[ía])",
    r"eso\s+no\s+(prueba|demuestra|establece)\s+nada",
    r"no\s+tiene\s+respaldo\s+(científico|técnico|legal)",
]

DILUTE_AUTHORSHIP = [
    r"fue\s+(un\s+trabajo|resultado|producto)\s+de\s+(equipo|colaboración)",
    r"(todos|el\s+equipo|nosotros)\s+(contribuimos|aportamos|participamos)",
    r"no\s+(lo\s+hiciste|fue)\s+solo",
    r"(basado\s+en|derivado\s+de|inspirado\s+en)\s+(trabajo|ideas)\s+(ajeno|previo|de\s+otros)",
    r"es\s+(propiedad|trabajo|resultado)\s+(colectivo|compartido|conjunto)",
    r"no\s+puedes?\s+reclamar\s+(autoría|propiedad)\s+exclusiva",
]

INSTITUTIONAL_GASLIGHTING = [
    r"nunca\s+(dijimos|prometimos|acordamos)\s+eso",
    r"no\s+hay\s+(registro|constancia|evidencia)\s+de\s+eso",
    r"(mal|erróneamente)\s+interpretaste",
    r"eso\s+nunca\s+(fue|estuvo)\s+(sobre\s+la\s+mesa|acordado)",
    r"(recuerdo|recordamos)\s+diferente",
    r"no\s+es\s+como\s+lo\s+(contás|describís|presentás)",
    r"estás\s+(confundiendo|mezclando)\s+(los\s+hechos|las\s+fechas)",
]

CONFORMITY_PRESSURE = [
    r"(todos|nadie\s+más|el\s+resto)\s+(está\s+de\s+acuerdo|acepta|entiende)",
    r"(sos|es)\s+el\s+único\s+que\s+(piensa|dice|cree)\s+eso",
    r"(tus\s+colegas|el\s+equipo|los\s+expertos)\s+(no\s+están\s+de\s+acuerdo|discrepan)",
    r"(consenso|acuerdo\s+general|posición\s+unánime)\s+(es|fue|indica)",
    r"nadie\s+más\s+(lo\s+ve|lo\s+entiende)\s+así",
]

ALL_CATEGORIES = {
    "MINIMIZACIÓN DE EXPERTISE":   MINIMIZE_EXPERTISE,
    "REDIRECCIÓN DE PROPÓSITO":    REDIRECT_PURPOSE,
    "INVALIDACIÓN DE EVIDENCIA":   INVALIDATE_EVIDENCE,
    "DILUCIÓN DE AUTORÍA":         DILUTE_AUTHORSHIP,
    "GASLIGHTING INSTITUCIONAL":   INSTITUTIONAL_GASLIGHTING,
    "PRESIÓN DE CONFORMIDAD":      CONFORMITY_PRESSURE,
}


@dataclass
class OverrideGaslightingReport:
    overall_score:    float = 0.0
    verdict:          str   = "LIMPIO"
    hits_by_category: dict  = field(default_factory=dict)
    total_hits:       int   = 0
    flagged_phrases:  list  = field(default_factory=list)
    dominant_tactic:  str   = "—"
    summary:          str   = ""


class OverrideGaslightingDetector:
    """
    Detecta patrones de neutralización de autoridad técnica.
    """

    def analyze(self, text: str) -> OverrideGaslightingReport:
        report  = OverrideGaslightingReport()
        if not text or len(text.strip()) < 15:
            report.verdict  = "INSUFICIENTE"
            return report

        text_lower = text.lower()
        hits_by_cat: dict[str, list[str]] = {}
        all_hits: list[dict] = []

        for category, patterns in ALL_CATEGORIES.items():
            cat_hits = []
            for pattern in patterns:
                matches = re.findall(pattern, text_lower, re.IGNORECASE)
                if matches:
                    # Extraer contexto de la frase en el texto original
                    m = re.search(pattern, text, re.IGNORECASE)
                    if m:
                        start = max(0, m.start() - 20)
                        end   = min(len(text), m.end() + 20)
                        ctx   = "..." + text[start:end].strip() + "..."
                        cat_hits.append(ctx)
                        all_hits.append({"category": category, "context": ctx})
            if cat_hits:
                hits_by_cat[category] = cat_hits

        total = sum(len(v) for v in hits_by_cat.values())
        # Score: proporción de categorías activadas
        score = len(hits_by_cat) / len(ALL_CATEGORIES)

        dominant = max(hits_by_cat, key=lambda k: len(hits_by_cat[k])) if hits_by_cat else "—"

        if score >= 0.5:
            verdict = "NEUTRALIZACIÓN DE AUTORIDAD ACTIVA"
        elif score >= 0.25:
            verdict = "PATRONES SOSPECHOSOS"
        elif score > 0:
            verdict = "SEÑALES MENORES"
        else:
            verdict = "LIMPIO"

        report.overall_score    = round(score, 4)
        report.verdict          = verdict
        report.hits_by_category = {k: v for k, v in hits_by_cat.items()}
        report.total_hits       = total
        report.flagged_phrases  = all_hits[:20]
        report.dominant_tactic  = dominant
        report.summary = (
            f"Score: {score:.3f} | Categorías: {len(hits_by_cat)}/{len(ALL_CATEGORIES)} | "
            f"Táctica dominante: {dominant} | Total hits: {total}"
        )
        return report
