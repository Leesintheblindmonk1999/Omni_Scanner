"""
interface/modules/shadow_code.py
──────────────────────────────────
Shadow-Code Detector — Análisis de Autoría Computacional

Detecta si un fragmento de código fue escrito por un humano o generado
por un LLM que intenta replicar lógica de invarianza semántica.

METODOLOGÍA (sin modelos externos, 100% local):

  1. FRACTAL ROUGHNESS OF AUTHORSHIP
     La "rugosidad fractal" del código se mide como la dimensión de Higuchi
     sobre la serie de longitudes de línea. Código humano tiene irregularidad
     genuina (D ≈ 1.4–1.8). Código LLM tiene regularidad sintética (D ≈ 1.1–1.3).

  2. LEXICAL BURSTINESS
     Humanos usan "rafagas" de vocabulario específico. Los LLMs distribuyen
     el vocabulario más uniformemente. Medimos con índice de Gini sobre frecuencia
     de tokens: bajo Gini (distribución homogénea) → señal LLM.

  3. COMMENT-TO-CODE RATIO
     LLMs tienden a sobre-comentar (docstrings exhaustivos, comentarios inline
     en cada línea). Ratio > 0.35 es estadísticamente inusual en código humano.

  4. NAMING ENTROPY
     Los LLMs usan nombres de variables descriptivos y largos. Humanos mezclan
     nombres cortos, abreviaciones y variables de un carácter. Alta entropía
     en longitud de nombres → señal LLM.

  5. STRUCTURAL REGULARITY
     Indentación perfectamente consistente, longitud de funciones similar → LLM.
     Varianza alta en estas métricas → humano.

  6. κD PROXIMITY SCORE
     Si hay constantes cercanas a 0.56 Y el código tiene firma de LLM:
     → "PLAGIO ALGORÍTMICO PROBABLE"

VEREDICTOS:
  PLAGIO ALGORÍTMICO PROBABLE  → human_score < 0.35 AND kappa_proximity > 0.5
  GENERADO POR IA               → human_score < 0.35
  ASISTIDO POR IA               → human_score 0.35–0.60
  AUTORÍA HUMANA PROBABLE       → human_score > 0.60
"""
from __future__ import annotations

import ast
import math
import re
from dataclasses import dataclass, field
from typing import List

K_DURANTE = 0.56
K_TOLERANCE = 0.05


@dataclass
class ShadowCodeReport:
    """Resultado del análisis de autoría computacional."""
    human_score:          float = 0.5
    kappa_proximity:      float = 0.0
    verdict:              str   = "INDETERMINADO"
    fractal_roughness:    float = 0.0
    lexical_burstiness:   float = 0.0
    comment_ratio:        float = 0.0
    naming_entropy:       float = 0.0
    structural_regularity: float = 0.0
    line_count:           int   = 0
    function_count:       int   = 0
    kappa_constants:      list  = field(default_factory=list)
    evidence_points:      list  = field(default_factory=list)
    scatter_data:         list  = field(default_factory=list)  # para gráfico Plotly
    summary:              str   = ""


class ShadowCodeDetector:
    """
    Analiza código fuente para determinar si es de autoría humana
    o generado por LLM, con detección especial de replicación de κD.
    """

    # ── Higuchi Fractal Dimension ──────────────────────────────

    @staticmethod
    def _higuchi_fd(series: list[float], k_max: int = 8) -> float:
        """
        Dimensión fractal de Higuchi sobre una serie numérica.
        Mide la auto-similitud de la serie a distintas escalas.
        """
        n = len(series)
        if n < 10:
            return 1.5  # fallback
        k_max = min(k_max, n // 2)
        L_k = []
        k_vals = []
        for k in range(1, k_max + 1):
            L_m_list = []
            for m in range(1, k + 1):
                indices = list(range(m - 1, n, k))
                if len(indices) < 2:
                    continue
                vals    = [series[i] for i in indices]
                length  = sum(abs(vals[i+1] - vals[i]) for i in range(len(vals)-1))
                norm    = (n - 1) / (((len(vals) - 1) * k) * k)
                L_m_list.append(length * norm)
            if L_m_list:
                L_k.append(math.log(sum(L_m_list) / len(L_m_list) + 1e-10))
                k_vals.append(math.log(1.0 / k))
        if len(k_vals) < 2:
            return 1.5
        # Regresión lineal log-log
        n_pts = len(k_vals)
        x_bar = sum(k_vals) / n_pts
        y_bar = sum(L_k) / n_pts
        num   = sum((k_vals[i] - x_bar) * (L_k[i] - y_bar) for i in range(n_pts))
        den   = sum((k_vals[i] - x_bar) ** 2 for i in range(n_pts))
        return num / den if den != 0 else 1.5

    # ── Gini Coefficient ───────────────────────────────────────

    @staticmethod
    def _gini(values: list[float]) -> float:
        """Coeficiente de Gini. 0=perfectamente uniforme, 1=concentrado."""
        if not values or sum(values) == 0:
            return 0.0
        v = sorted(values)
        n = len(v)
        total = sum(v)
        cum = sum((2 * (i + 1) - n - 1) * v[i] for i in range(n))
        return cum / (n * total)

    # ── Métricas de código ─────────────────────────────────────

    def _fractal_roughness(self, lines: list[str]) -> float:
        """
        Dimensión fractal sobre serie de longitudes de línea.
        LLM: D bajo (regularidad). Humano: D alto (irregularidad).
        Normalizado: 0=muy regular(LLM), 1=muy irregular(humano).
        """
        lens = [len(l) for l in lines if l.strip()]
        if len(lens) < 8:
            return 0.5
        fd = self._higuchi_fd(lens)
        # FD típico humano: 1.5–1.9. LLM: 1.1–1.4
        normalized = max(0.0, min(1.0, (fd - 1.0) / 1.0))
        return round(normalized, 4)

    def _lexical_burstiness(self, source: str) -> float:
        """
        Índice de Gini sobre frecuencia de tokens.
        LLM: Gini bajo (vocabulario distribuido uniformemente).
        Humano: Gini alto (palabras favoritas + hapax legomena).
        """
        tokens = re.findall(r'\b[a-zA-Z_][a-zA-Z0-9_]{2,}\b', source)
        if len(tokens) < 10:
            return 0.5
        freq: dict[str, int] = {}
        for t in tokens:
            freq[t] = freq.get(t, 0) + 1
        gini = self._gini(list(freq.values()))
        return round(gini, 4)  # alto Gini → humano

    def _comment_ratio(self, lines: list[str]) -> float:
        """
        Ratio comentarios / líneas de código.
        LLM: muy alto (>0.35). Humano: moderado (<0.20 típico).
        Retorna el ratio raw (para invertir en el score).
        """
        code_lines    = [l for l in lines if l.strip() and not l.strip().startswith('#')]
        comment_lines = [l for l in lines if l.strip().startswith('#')]
        # Docstrings
        in_docstring  = False
        doc_count     = 0
        for l in lines:
            stripped = l.strip()
            if stripped.startswith('"""') or stripped.startswith("'''"):
                in_docstring = not in_docstring
                doc_count += 1
            elif in_docstring:
                doc_count += 1
        total_comments = len(comment_lines) + doc_count
        total_lines    = max(len(lines), 1)
        return total_comments / total_lines

    def _naming_entropy(self, source: str) -> float:
        """
        Entropía en distribución de longitudes de nombres de variables/funciones.
        LLM: nombres largos y descriptivos → baja varianza, alta longitud media.
        Humano: mezcla de cortos y largos → alta varianza.
        Retorna score de 'humanidad' en naming.
        """
        try:
            tree = ast.parse(source)
        except SyntaxError:
            return 0.5
        names = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Name):
                names.append(len(node.id))
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                names.append(len(node.name))
            elif isinstance(node, ast.arg):
                names.append(len(node.arg))
        if len(names) < 5:
            return 0.5
        mean = sum(names) / len(names)
        var  = sum((x - mean) ** 2 for x in names) / len(names)
        # Alta varianza = humano, baja varianza + media alta = LLM
        # mean > 8 + var < 15 → LLM
        human_score = min(var / 30.0, 1.0) * (1.0 - min(mean / 15.0, 1.0) * 0.3)
        return round(max(0.0, min(1.0, human_score)), 4)

    def _structural_regularity(self, lines: list[str]) -> float:
        """
        Mide regularidad en tamaño de bloques de código.
        LLM produce bloques más uniformes. Retorna score 0(irregular)–1(regular).
        """
        # Identificar bloques (separados por líneas vacías)
        blocks = []
        current = 0
        for l in lines:
            if l.strip():
                current += 1
            else:
                if current > 0:
                    blocks.append(current)
                current = 0
        if current > 0:
            blocks.append(current)
        if len(blocks) < 3:
            return 0.5
        mean = sum(blocks) / len(blocks)
        var  = sum((b - mean) ** 2 for b in blocks) / len(blocks)
        regularity = 1.0 - min(var / 100.0, 1.0)  # alta var = irregular = humano
        return round(regularity, 4)

    def _kappa_proximity(self, source: str) -> tuple[float, list[dict]]:
        """Detecta constantes cercanas a κD = 0.56."""
        hits = []
        pattern = re.compile(r'\b(\d+\.\d+)\b')
        for i, line in enumerate(source.split("\n"), 1):
            for m in pattern.finditer(line):
                try:
                    val = float(m.group(1))
                    if abs(val - K_DURANTE) <= K_TOLERANCE:
                        hits.append({"line": i, "value": val,
                                     "delta": round(abs(val - K_DURANTE), 4)})
                except ValueError:
                    pass
        score = min(len(hits) * 0.3, 1.0)
        return round(score, 4), hits

    # ── Scatter data para Plotly ──────────────────────────────

    def _build_scatter_data(self, metrics: dict) -> list[dict]:
        """
        Construye datos para el gráfico de dispersión 2D:
        Eje X = Fractal Roughness (indicador de humanidad)
        Eje Y = Lexical Burstiness (indicador de humanidad)
        Con zonas coloreadas: verde=humano, rojo=LLM
        """
        return [
            {
                "label":     "Documento analizado",
                "x":         metrics["fractal_roughness"],
                "y":         metrics["lexical_burstiness"],
                "size":      20,
                "color":     "#FFB100",
                "human_score": metrics["human_score"],
            },
            # Puntos de referencia (zona LLM)
            {"label": "Zona LLM", "x": 0.25, "y": 0.25, "size": 8, "color": "#FF2D2D", "ref": True},
            {"label": "Zona LLM", "x": 0.30, "y": 0.30, "size": 8, "color": "#FF2D2D", "ref": True},
            {"label": "Zona LLM", "x": 0.20, "y": 0.35, "size": 8, "color": "#FF2D2D", "ref": True},
            # Puntos de referencia (zona Humano)
            {"label": "Zona Humana", "x": 0.75, "y": 0.70, "size": 8, "color": "#00FF88", "ref": True},
            {"label": "Zona Humana", "x": 0.80, "y": 0.65, "size": 8, "color": "#00FF88", "ref": True},
            {"label": "Zona Humana", "x": 0.70, "y": 0.75, "size": 8, "color": "#00FF88", "ref": True},
        ]

    # ── Main analyze ──────────────────────────────────────────

    def analyze(self, source: str) -> ShadowCodeReport:
        """
        Analiza el código fuente y retorna un ShadowCodeReport.
        """
        report = ShadowCodeReport()

        if not source or len(source.strip()) < 30:
            report.verdict  = "VACÍO"
            report.summary  = "Código insuficiente para análisis."
            return report

        lines = source.split("\n")
        report.line_count = len([l for l in lines if l.strip()])

        try:
            tree = ast.parse(source)
            report.function_count = sum(
                1 for n in ast.walk(tree)
                if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
            )
        except SyntaxError:
            report.function_count = source.count("def ")

        # Calcular métricas
        frac_rough    = self._fractal_roughness(lines)
        lex_burst     = self._lexical_burstiness(source)
        comm_ratio    = self._comment_ratio(lines)
        naming_ent    = self._naming_entropy(source)
        struct_reg    = self._structural_regularity(lines)
        kappa_sc, kappa_hits = self._kappa_proximity(source)

        # Score de humanidad
        # comment_ratio alto → penalización (señal LLM)
        comm_penalty = min(max(comm_ratio - 0.20, 0) / 0.30, 1.0)
        # structural_regularity alta → penalización (señal LLM)
        struct_penalty = struct_reg * 0.5

        human_score = (
            frac_rough  * 0.30
            + lex_burst   * 0.30
            + naming_ent  * 0.20
            + (1.0 - comm_penalty)   * 0.10
            + (1.0 - struct_penalty) * 0.10
        )
        human_score = max(0.0, min(1.0, human_score))

        # Evidencia
        evidence = []
        if frac_rough < 0.35:
            evidence.append(f"Rugosidad fractal baja ({frac_rough:.3f}) — patrón LLM")
        if lex_burst < 0.35:
            evidence.append(f"Distribución léxica uniforme ({lex_burst:.3f}) — patrón LLM")
        if comm_ratio > 0.30:
            evidence.append(f"Over-comentado ({comm_ratio:.1%}) — patrón LLM")
        if naming_ent < 0.30:
            evidence.append(f"Nombres uniformemente largos ({naming_ent:.3f}) — patrón LLM")
        if struct_reg > 0.70:
            evidence.append(f"Estructura muy regular ({struct_reg:.3f}) — patrón LLM")
        if kappa_hits:
            evidence.append(f"{len(kappa_hits)} constante(s) κD-proximal detectada(s)")

        # Veredicto
        if human_score < 0.35 and kappa_sc > 0.5:
            verdict = "PLAGIO ALGORÍTMICO PROBABLE"
        elif human_score < 0.35:
            verdict = "GENERADO POR IA"
        elif human_score < 0.60:
            verdict = "ASISTIDO POR IA"
        else:
            verdict = "AUTORÍA HUMANA PROBABLE"

        report.human_score           = round(human_score, 4)
        report.kappa_proximity       = kappa_sc
        report.verdict               = verdict
        report.fractal_roughness     = frac_rough
        report.lexical_burstiness    = lex_burst
        report.comment_ratio         = round(comm_ratio, 4)
        report.naming_entropy        = naming_ent
        report.structural_regularity = struct_reg
        report.kappa_constants       = kappa_hits
        report.evidence_points       = evidence

        metrics = {
            "fractal_roughness":  frac_rough,
            "lexical_burstiness": lex_burst,
            "human_score":        human_score,
        }
        report.scatter_data = self._build_scatter_data(metrics)
        report.summary = (
            f"Human Score: {human_score:.4f} | "
            f"Fractal: {frac_rough:.3f} | Burst: {lex_burst:.3f} | "
            f"Comment: {comm_ratio:.1%} | κD-hits: {len(kappa_hits)}"
        )
        return report
