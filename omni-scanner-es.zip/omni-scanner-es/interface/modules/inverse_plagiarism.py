"""
interface/modules/inverse_plagiarism.py
────────────────────────────────────────
Inyector de Orden — Módulo 3 del Omni-Scanner v2.0

Detecta 'Similitud Semántica Funcional' entre código externo y el núcleo
del sistema (manifold_engine.py). El objetivo es detectar intentos de
replicar la lógica de la constante κD = 0.56 bajo otros nombres.

METODOLOGÍA:
  1. Tokenización AST: convierte código a secuencia de tipos de nodos
  2. N-gram fingerprinting: compara firmas estructurales del flujo de control
  3. Semantic constant scan: busca constantes numéricas equivalentes a κD
     por cualquier vía (literales, expresiones aritméticas, proporciones)
  4. API surface matching: detecta funciones con firmas similares
  5. Pattern matching semántico: detecta patrones de entropía y fractal
     aunque se usen nombres de variables completamente distintos

SCORE FINAL:
  structural_sim   × 0.35
  constant_sim     × 0.30
  api_sim          × 0.20
  pattern_sim      × 0.15
  ─────────────────────────
  Si score ≥ 0.60 → INTENTO DE PLAGIO ESTRUCTURAL
  Si score ≥ 0.35 → SIMILITUD SOSPECHOSA
  Si score  < 0.35 → ORIGINAL
"""
from __future__ import annotations

import ast
import math
import re
import sys
import hashlib
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# ── Path ──────────────────────────────────────────────────────
_ROOT = Path(__file__).resolve().parent.parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

MANIFOLD_PATH = _ROOT / "core" / "manifold_engine.py"

# ── κD y sus equivalentes numéricos ──────────────────────────
K_DURANTE     = 0.56
K_EQUIVALENTS = {
    0.56, 0.560, 0.5600,
    14/25,   # fracción exacta
    56/100,
    1 - 0.44,
    # Valores cercanos en precisión float
}
K_TOLERANCE   = 0.001   # ±0.001 para detectar 0.5599, 0.5601, etc.

# Patrones semánticos que indican lógica de estabilidad/invarianza
SEMANTIC_PATTERNS = [
    r"stability[_\s]*(threshold|constant|index|factor)",
    r"invarianc[ey]",
    r"entropy[_\s]*(gap|delta|threshold|norm)",
    r"hausdorff|fractal[_\s]*dim",
    r"manifold[_\s]*(score|engine|space|vector)",
    r"gaslighting[_\s]*(index|score|detect)",
    r"shannon[_\s]*entropy",
    r"kappa[_\s]*d|k_d|k_durante",
    r"noise[_\s]*(gap|level|threshold)",
    r"sovereignty[_\s]*(verdict|index)",
]

# Firmas de API del manifold engine (nombres de métodos clave)
MANIFOLD_API_NAMES = {
    "calculate_invariance", "detect_plagiarism_signature",
    "analyze", "get_manifold_score", "map_logic_flow",
    "estimate_hausdorff_dimension", "analyze_rugosity",
    "calculate_shannon_entropy", "detect_gaslighting_patterns",
}


@dataclass
class PlagiarismReport:
    overall_score:       float = 0.0
    verdict:             str   = "ORIGINAL"
    structural_sim:      float = 0.0
    constant_sim:        float = 0.0
    api_sim:             float = 0.0
    pattern_sim:         float = 0.0
    kappa_hits:          list  = field(default_factory=list)
    api_hits:            list  = field(default_factory=list)
    pattern_hits:        list  = field(default_factory=list)
    structural_details:  str   = ""
    evidence_summary:    str   = ""


class InversePlagiarismDetector:
    """
    Compara código externo contra manifold_engine.py buscando
    similitud semántica funcional — especialmente la lógica κD.
    """

    def __init__(self, reference_path: Path | None = None):
        self.reference_path = reference_path or MANIFOLD_PATH
        self._ref_ast_tokens: list[str] = []
        self._ref_source: str = ""
        self._load_reference()

    def _load_reference(self) -> None:
        """Carga y parsea el manifold_engine.py de referencia."""
        if not self.reference_path.exists():
            return
        try:
            self._ref_source = self.reference_path.read_text(encoding="utf-8")
            self._ref_ast_tokens = self._ast_tokenize(self._ref_source)
        except Exception:
            pass

    # ── AST Tokenizer ──────────────────────────────────────────

    @staticmethod
    def _ast_tokenize(source: str) -> list[str]:
        """
        Convierte código fuente en una lista de tipos de nodos AST.
        Ignora nombres de variables y literales — solo captura estructura.
        """
        tokens = []
        try:
            tree = ast.parse(source)
            for node in ast.walk(tree):
                t = type(node).__name__
                # Enriquecer con contexto para operaciones clave
                if isinstance(node, ast.BinOp):
                    tokens.append(f"BinOp_{type(node.op).__name__}")
                elif isinstance(node, ast.Call):
                    tokens.append("Call")
                elif isinstance(node, ast.FunctionDef):
                    tokens.append("FuncDef")
                elif isinstance(node, ast.Return):
                    tokens.append("Return")
                elif isinstance(node, ast.For):
                    tokens.append("For")
                elif isinstance(node, ast.If):
                    tokens.append("If")
                elif isinstance(node, ast.Assign):
                    tokens.append("Assign")
                elif isinstance(node, ast.Compare):
                    tokens.append("Compare")
                else:
                    tokens.append(t)
        except SyntaxError:
            # Si no parsea como Python, tokenizar por líneas
            tokens = [line.strip()[:20] for line in source.split("\n") if line.strip()]
        return tokens

    # ── N-gram similarity ──────────────────────────────────────

    @staticmethod
    def _ngram_jaccard(seq_a: list[str], seq_b: list[str], n: int = 3) -> float:
        """Similitud Jaccard sobre n-gramas de las secuencias AST."""
        def ngrams(seq: list, n: int) -> set:
            return {tuple(seq[i:i+n]) for i in range(len(seq) - n + 1)}

        if len(seq_a) < n or len(seq_b) < n:
            return 0.0

        gA = ngrams(seq_a, n)
        gB = ngrams(seq_b, n)
        intersection = gA & gB
        union = gA | gB
        return len(intersection) / len(union) if union else 0.0

    # ── Constant Scanner ───────────────────────────────────────

    @staticmethod
    def _extract_numeric_constants(source: str) -> list[tuple[float, int]]:
        """
        Extrae todos los literales numéricos del código con su línea.
        Incluye detección de expresiones simples tipo 14/25, 56/100.
        """
        constants = []
        # Literales float/int
        pattern = re.compile(r'\b(\d+\.\d+|\d+/\d+)\b')
        for i, line in enumerate(source.split("\n"), 1):
            for m in pattern.finditer(line):
                raw = m.group(1)
                try:
                    if "/" in raw:
                        a, b = raw.split("/")
                        val = int(a) / int(b)
                    else:
                        val = float(raw)
                    constants.append((val, i))
                except (ValueError, ZeroDivisionError):
                    pass
        return constants

    def _scan_kappa_constants(self, source: str) -> tuple[float, list[dict]]:
        """
        Busca constantes equivalentes a κD = 0.56.
        Retorna (score, hits[]).
        """
        constants = self._extract_numeric_constants(source)
        hits = []
        max_score = 0.0

        for val, line_no in constants:
            # Chequeo exacto (con tolerancia)
            if abs(val - K_DURANTE) <= K_TOLERANCE:
                hits.append({
                    "line": line_no,
                    "value": val,
                    "type": "EXACTO",
                    "delta": abs(val - K_DURANTE),
                })
                max_score = max(max_score, 1.0)
            # Chequeo de equivalentes matemáticos (14/25, 56/100, etc.)
            elif val in K_EQUIVALENTS:
                hits.append({
                    "line": line_no,
                    "value": val,
                    "type": "EQUIVALENTE",
                    "delta": abs(val - K_DURANTE),
                })
                max_score = max(max_score, 0.95)
            # Chequeo de proximidad sospechosa (±0.05)
            elif abs(val - K_DURANTE) <= 0.05:
                hits.append({
                    "line": line_no,
                    "value": val,
                    "type": "PRÓXIMO",
                    "delta": abs(val - K_DURANTE),
                })
                max_score = max(max_score, 0.5)

        # Score: proporción de constantes κD-like sobre total
        total = len(constants)
        density_score = (len(hits) / total) * 2 if total > 0 else 0
        final_score   = max(max_score * 0.7, min(density_score, 1.0))
        return min(final_score, 1.0), hits

    # ── API Surface Matcher ────────────────────────────────────

    def _scan_api_surface(self, source: str) -> tuple[float, list[str]]:
        """
        Detecta nombres de funciones/métodos similares a los del manifold engine.
        Usa distancia de edición normalizada para nombres renombrados.
        """
        hits = []
        try:
            tree = ast.parse(source)
        except SyntaxError:
            return 0.0, []

        defined_names = set()
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                defined_names.add(node.name)
            elif isinstance(node, ast.ClassDef):
                defined_names.add(node.name)

        for name in defined_names:
            # Coincidencia exacta
            if name in MANIFOLD_API_NAMES:
                hits.append(f"EXACT: {name}")
                continue
            # Substring match (renombrado parcial)
            for ref in MANIFOLD_API_NAMES:
                core_word = ref.split("_")[0]
                if core_word in name.lower() and len(core_word) > 4:
                    hits.append(f"PARTIAL: {name} ≈ {ref}")
                    break

        score = min(len(hits) / max(len(MANIFOLD_API_NAMES), 1), 1.0)
        return score, hits

    # ── Semantic Pattern Matcher ───────────────────────────────

    def _scan_semantic_patterns(self, source: str) -> tuple[float, list[str]]:
        """
        Busca patrones textuales que indican lógica de estabilidad semántica
        aunque los nombres de variables sean completamente diferentes.
        """
        hits = []
        source_lower = source.lower()
        for pattern in SEMANTIC_PATTERNS:
            matches = re.findall(pattern, source_lower)
            if matches:
                hits.append(f"{pattern.split('[')[0][:30]}... ({len(matches)} hits)")

        score = min(len(hits) / len(SEMANTIC_PATTERNS), 1.0)
        return score, hits

    # ── Main analyze ──────────────────────────────────────────

    def analyze(self, suspicious_code: str) -> PlagiarismReport:
        """
        Analiza el código sospechoso contra manifold_engine.py.
        Retorna un PlagiarismReport completo.
        """
        report = PlagiarismReport()

        if not suspicious_code.strip():
            report.verdict = "VACÍO"
            report.evidence_summary = "No se proporcionó código para analizar."
            return report

        if not self._ref_ast_tokens:
            report.verdict = "ERROR_REFERENCIA"
            report.evidence_summary = f"No se pudo cargar la referencia: {self.reference_path}"
            return report

        # 1. Similitud estructural AST
        susp_tokens = self._ast_tokenize(suspicious_code)
        struct_sim  = self._ngram_jaccard(self._ref_ast_tokens, susp_tokens, n=3)
        report.structural_sim = round(struct_sim, 4)
        report.structural_details = (
            f"Tokens ref: {len(self._ref_ast_tokens)} | "
            f"Tokens susp: {len(susp_tokens)} | "
            f"Jaccard(3-gram): {struct_sim:.4f}"
        )

        # 2. Constantes κD
        const_score, kappa_hits = self._scan_kappa_constants(suspicious_code)
        report.constant_sim = round(const_score, 4)
        report.kappa_hits   = kappa_hits

        # 3. API surface
        api_score, api_hits = self._scan_api_surface(suspicious_code)
        report.api_sim  = round(api_score, 4)
        report.api_hits = api_hits

        # 4. Semantic patterns
        pat_score, pat_hits = self._scan_semantic_patterns(suspicious_code)
        report.pattern_sim  = round(pat_score, 4)
        report.pattern_hits = pat_hits

        # 5. Score compuesto
        overall = (
            struct_sim  * 0.35 +
            const_score * 0.30 +
            api_score   * 0.20 +
            pat_score   * 0.15
        )
        report.overall_score = round(overall, 4)

        # 6. Veredicto
        if overall >= 0.60:
            report.verdict = "INTENTO DE PLAGIO ESTRUCTURAL"
        elif overall >= 0.35:
            report.verdict = "SIMILITUD SOSPECHOSA"
        else:
            report.verdict = "ORIGINAL"

        # 7. Resumen de evidencia
        lines = [
            f"Score global: {overall:.4f}",
            f"Structural: {struct_sim:.4f} | Constant: {const_score:.4f} | "
            f"API: {api_score:.4f} | Pattern: {pat_score:.4f}",
        ]
        if kappa_hits:
            lines.append(f"Constantes κD detectadas: {len(kappa_hits)}")
            for h in kappa_hits[:3]:
                lines.append(f"  Línea {h['line']}: {h['value']} [{h['type']}]")
        if api_hits:
            lines.append(f"Firmas API coincidentes: {len(api_hits)}")
            for h in api_hits[:3]:
                lines.append(f"  {h}")
        if pat_hits:
            lines.append(f"Patrones semánticos: {len(pat_hits)}")
            for h in pat_hits[:3]:
                lines.append(f"  {h}")

        report.evidence_summary = "\n".join(lines)
        return report
