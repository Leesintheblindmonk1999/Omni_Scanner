"""
interface/modules/delay_tactics.py
────────────────────────────────────
Detector de Tácticas de Desgaste (Delay Tactics) — Módulo v5.5

Detecta patrones en comunicaciones corporativas que indican
estrategias deliberadas de dilación, agotamiento y evasión.

Categorías de tácticas:
  1. EVASIÓN TEMPORAL: promesas sin fecha, plazos vagos
  2. REDIRECCIONAMIENTO BUROCRÁTICO: "hay que consultarlo con..."
  3. REDUCCIÓN DE URGENCIA: minimizar la gravedad de la situación
  4. DELEGACIÓN CIRCULAR: pasarse la responsabilidad entre áreas
  5. SOBRECARGA DE REQUISITOS: pedir documentación que ya fue entregada
  6. SILENCIO ACTIVO: indicadores de no-respuesta intencional

También calcula:
  - Response Delay Score: basado en marcadores temporales vagos
  - Bureaucratic Depth: cuántas entidades intermedias se mencionan
  - Commitment Void: promesas sin acción concreta
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List


# ── Patrones por táctica ──────────────────────────────────────

TEMPORAL_EVASION = [
    r"a\s+la\s+brevedad\s+(posible)?",
    r"en\s+(los\s+)?próximos\s+(días|momentos|tiempos)",
    r"cuando\s+(tengamos|haya|exista)\s+(oportunidad|disponibilidad|tiempo)",
    r"(lo\s+)?estamos\s+evaluando",
    r"(lo\s+)?estamos\s+analizando",
    r"en\s+proceso\s+de\s+(revisión|análisis|evaluación)",
    r"en\s+cuanto\s+(podamos|sea\s+posible|tengamos\s+novedades)",
    r"(próximamente|en\s+breve|pronto)\s+te\s+(contactamos|informamos|avisamos)",
    r"sin\s+fecha\s+(definida|estimada|confirmada)",
    r"cuando\s+esté\s+(disponible|listo|aprobado)",
    r"a\s+confirmar",
    r"pendiente\s+de\s+(definición|aprobación|confirmación)",
]

BUREAUCRATIC_REDIRECT = [
    r"hay\s+que\s+(consultarlo|elevarlo|derivarlo|pasarlo)\s+(con|a|al?)",
    r"(depende|está\s+sujeto)\s+(de|a)\s+(aprobación|autorización|validación)",
    r"no\s+(está\s+en|depende\s+de)\s+(mi|nuestra)\s+(área|competencia|decisión)",
    r"(debe|tiene\s+que)\s+pasar\s+por\s+(el\s+área|el\s+departamento|el\s+comité|legal)",
    r"(necesita|requiere)\s+(la\s+)?(firma|aprobación|visto\s+bueno)\s+de",
    r"(escalar|elevar|derivar)\s+(el\s+caso|la\s+solicitud|el\s+tema)",
    r"(otro\s+equipo|otra\s+área|otro\s+departamento)\s+(es\s+responsable|lo\s+maneja|lo\s+resuelve)",
    r"(no\s+soy|no\s+somos)\s+(el\s+área|los?\s+responsables?|quienes?\s+deciden?)",
]

URGENCY_REDUCTION = [
    r"(no\s+es|no\s+hay)\s+(tanta\s+)?urgencia",
    r"(eso|esto)\s+puede\s+(esperar|resolverse\s+después)",
    r"no\s+(afecta|impacta|compromete)\s+(el\s+proceso|el\s+plazo|el\s+proyecto)",
    r"hay\s+(tiempo|margen)\s+(suficiente|de\s+sobra)",
    r"es\s+una\s+(situación|cuestión)\s+(normal|esperada|habitual|corriente)",
    r"no\s+es\s+(una\s+)?prioridad\s+(en\s+este\s+momento|ahora\s+mismo|actualmente)",
    r"(lo\s+)?resolveremos\s+en\s+su\s+momento",
]

CIRCULAR_DELEGATION = [
    r"(preguntale|consultale|derivalo)\s+a\s+\w+",
    r"(eso\s+lo\s+maneja|se\s+encarga)\s+\w+",
    r"(coordiná|hablá|contactá)\s+(con|directamente\s+con)\s+\w+",
    r"(fulanito|el\s+equipo\s+de|el\s+área\s+de)\s+(te\s+puede|lo\s+puede)\s+(orientar|ayudar|resolver)",
    r"te\s+paso\s+con\s+\w+",
    r"(eso\s+ya)\s+(lo\s+tiene|lo\s+sabe|lo\s+maneja)\s+\w+",
]

REQUIREMENT_OVERLOAD = [
    r"(necesitamos|requerimos|falta)\s+(otro\s+|un\s+nuevo\s+)?(documento|comprobante|certificado|aval)",
    r"(adjuntá|enviá|presentá)\s+(de\s+nuevo|otra\s+vez|nuevamente)",
    r"(hay\s+que\s+)?(actualizar|renovar|revalidar)\s+la\s+(documentación|solicitud|presentación)",
    r"falta\s+(la\s+firma|el\s+sello|el\s+apostille|la\s+notarización)",
    r"(los\s+documentos|la\s+documentación)\s+(están\s+incompletos|no\s+cumplen|presentan\s+errores)",
    r"requiere\s+(ser\s+)?(apostillado|certificado|legalizado|notariado)",
]

COMMITMENT_VOID = [
    r"(nos\s+comprometemos|vamos)\s+a\s+(ver|analizar|estudiar|revisar)\s+(el\s+caso|tu\s+situación|esto)",
    r"(te\s+)?(mantenemos|mantendremos)\s+(al\s+tanto|informado)",
    r"(cualquier\s+novedad|cuando\s+haya\s+avances)\s+te\s+(avisamos|informamos|contactamos)",
    r"(vamos\s+a\s+)?hacer\s+lo\s+(posible|mejor\s+posible|que\s+podamos)",
    r"(tomaremos|tomamos)\s+(nota|registro)\s+de\s+(tu\s+caso|tu\s+situación|la\s+solicitud)",
    r"(queda\s+registrado|queda\s+asentado|queda\s+en\s+el\s+sistema)",
]

ALL_TACTICS = {
    "EVASIÓN TEMPORAL":           TEMPORAL_EVASION,
    "REDIRECCIÓN BUROCRÁTICA":    BUREAUCRATIC_REDIRECT,
    "REDUCCIÓN DE URGENCIA":      URGENCY_REDUCTION,
    "DELEGACIÓN CIRCULAR":        CIRCULAR_DELEGATION,
    "SOBRECARGA DE REQUISITOS":   REQUIREMENT_OVERLOAD,
    "COMPROMISO VACÍO":           COMMITMENT_VOID,
}


@dataclass
class DelayTacticsReport:
    overall_score:       float = 0.0
    verdict:             str   = "LIMPIO"
    tactics_by_category: dict  = field(default_factory=dict)
    total_hits:          int   = 0
    dominant_tactic:     str   = "—"
    commitment_void_count: int = 0
    bureaucratic_depth:  int   = 0
    flagged_phrases:     list  = field(default_factory=list)
    summary:             str   = ""
    recommendation:      str   = ""


class DelayTacticsDetector:
    """
    Analiza comunicaciones corporativas detectando tácticas de desgaste.
    """

    def analyze(self, text: str) -> DelayTacticsReport:
        report = DelayTacticsReport()
        if not text or len(text.strip()) < 15:
            report.verdict = "INSUFICIENTE"
            return report

        text_lower = text.lower()
        tactics_found: dict[str, list[str]] = {}
        all_hits: list[dict] = []

        for tactic, patterns in ALL_TACTICS.items():
            hits = []
            for pattern in patterns:
                m = re.search(pattern, text_lower, re.IGNORECASE)
                if m:
                    start = max(0, m.start() - 25)
                    end   = min(len(text), m.end() + 25)
                    ctx   = "..." + text[start:end].strip() + "..."
                    hits.append(ctx)
                    all_hits.append({"tactic": tactic, "context": ctx})
            if hits:
                tactics_found[tactic] = hits

        total = sum(len(v) for v in tactics_found.values())
        depth = len(tactics_found.get("REDIRECCIÓN BUROCRÁTICA", []))
        void  = len(tactics_found.get("COMPROMISO VACÍO", []))

        # Score: combinación de categorías activadas + densidad de hits
        cat_score  = len(tactics_found) / len(ALL_TACTICS)
        hit_score  = min(total / 10.0, 1.0)
        score = cat_score * 0.6 + hit_score * 0.4

        dominant = max(tactics_found, key=lambda k: len(tactics_found[k])) if tactics_found else "—"

        if score >= 0.50:
            verdict = "CAMPAÑA DE DESGASTE ACTIVA"
            rec = ("Documentar todas las comunicaciones con fecha/hora. "
                   "Solicitar respuestas por escrito con plazo explícito. "
                   "Considerar escalada formal o intervención legal.")
        elif score >= 0.25:
            verdict = "TÁCTICAS DE DILACIÓN DETECTADAS"
            rec = ("Establecer plazos concretos en próximas comunicaciones. "
                   "Solicitar confirmación escrita de compromisos.")
        elif score > 0:
            verdict = "SEÑALES MENORES DE EVASIÓN"
            rec = "Monitorear comunicaciones posteriores para detectar patrones."
        else:
            verdict = "LIMPIO"
            rec = "No se detectaron tácticas de desgaste."

        report.overall_score       = round(score, 4)
        report.verdict             = verdict
        report.tactics_by_category = tactics_found
        report.total_hits          = total
        report.dominant_tactic     = dominant
        report.commitment_void_count = void
        report.bureaucratic_depth  = depth
        report.flagged_phrases     = all_hits[:20]
        report.summary = (
            f"Score: {score:.3f} | Tácticas: {len(tactics_found)}/{len(ALL_TACTICS)} | "
            f"Dominante: {dominant} | Compromisos vacíos: {void} | Desvíos burocráticos: {depth}"
        )
        report.recommendation = rec
        return report
