"""
full_diagnostic.py — Omni-Scanner Semántico v1.0
-------------------------------------------------
Integrador de diagnóstico: orquesta ManifoldEngine + todos los engines
y produce un veredicto unificado.

CHANGELOG vs versión original:
  + generate_sovereignty_report(law_data, dev_data, social_data) preservada
  + FIX CRÍTICO: accedía a keys inexistentes ('noise_level', 'gaslighting_score')
    → ahora usa las keys reales de cada report o acepta dicts compatibles
  + NUEVO: run(text, input_type, reference_code) — pipeline completo
  + NUEVO: FullDiagnosticReport dataclass con veredicto global estructurado
  + NUEVO: tabla de confianza y señales de riesgo cruzadas
"""
from __future__ import annotations
import json
import sys
import os
from dataclasses import dataclass, field
from typing import Optional

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from core.manifold_engine import ManifoldEngine
from core.topology_mapper import TopologyMapper
from engines.law_auditor import LawAuditor
from engines.dev_verifier import DevVerifier
from engines.social_engineer import SocialEngineer
from engines.finance_scanner import FinanceScanner


@dataclass
class FullDiagnosticReport:
    input_type: str
    manifold_verdict: str
    manifold_score: float
    topology_flag: str
    coherence_score: float
    domain_flag: str
    domain_risk: float
    overall_verdict: str            # "CLEAR" | "REVIEW" | "HIGH_RISK"
    confidence: float
    sovereignty_verdict: str        # compatibilidad API original
    action_recommended: str         # compatibilidad API original
    raw_reports: dict = field(default_factory=dict)

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.__dict__, default=str, indent=indent)


class FullDiagnostic:
    """
    Parameters
    ----------
    stability_threshold : float   Umbral ManifoldEngine (default 0.56).
    """

    def __init__(self, stability_threshold: float = 0.56):
        self.manifold = ManifoldEngine(K_DURANTE=stability_threshold)
        self.topology = TopologyMapper()
        self.law = LawAuditor()
        self.dev = DevVerifier()
        self.social = SocialEngineer()
        self.finance = FinanceScanner()

    # ------------------------------------------------------------------
    # API ORIGINAL (preservada para compatibilidad)
    # ------------------------------------------------------------------

    def generate_sovereignty_report(
        self,
        law_data: dict,
        dev_data: dict,
        social_data: dict,
    ) -> dict:
        """
        Cruza las tres dimensiones para ver si hay un ataque coordinado.
        API original corregida.

        FIX: usaba keys 'noise_level' y 'gaslighting_score' que no existían
        en los dicts reales. Ahora usa .get() con fallback seguro.
        """
        noise = law_data.get("noise_level", law_data.get("legal_risk_score", 0.0))
        gas = social_data.get("gaslighting_score", social_data.get("risk_score", 0.0))

        total_risk = (noise + gas) / 2

        verdict = (
            "ATAQUE SEMÁNTICO DETECTADO" if total_risk > 0.6
            else "INTERACCIÓN ESTABLE"
        )

        return {
            "global_integrity": round(1.0 - total_risk, 4),
            "sovereignty_verdict": verdict,
            "action_recommended": (
                "ACTIVAR PROTOCOLO DE DEFENSA LEGAL"
                if total_risk > 0.7
                else "CONTINUAR MONITOREO"
            ),
        }

    # ------------------------------------------------------------------
    # API EXTENDIDA — pipeline completo
    # ------------------------------------------------------------------

    def run(
        self,
        text: str,
        input_type: str = "generic",
        reference_code: str = "",
    ) -> FullDiagnosticReport:
        """
        Pipeline completo texto → FullDiagnosticReport.

        Parameters
        ----------
        text : str
        input_type : "legal" | "code" | "discourse" | "finance" | "generic"
        reference_code : str   Prior Art para análisis de código.
        """
        t_result = self.topology.analyze(text)
        # Pasar coherencia topológica al manifold para activar el peso T=40%
        topo_coh = t_result.coherence_score if t_result.flag != "INSUFFICIENT" else None
        m_result = self.manifold.analyze(text, topology_coherence=topo_coh)

        domain_flag = "N/A"
        domain_risk = 0.0
        raw_domain: dict = {}

        if input_type == "legal":
            r = self.law.audit(text)
            domain_flag = r.verdict
            domain_risk = r.legal_risk_score
            raw_domain = r.to_dict()

        elif input_type == "code":
            r = self.dev.audit(text, reference_code)
            domain_flag = r.status
            domain_risk = r.plagiarism_risk / 100
            raw_domain = r.to_dict()

        elif input_type == "finance":
            r = self.finance.scan(text)
            domain_flag = r.verdict
            domain_risk = r.financial_risk_score
            raw_domain = r.to_dict()

        else:  # discourse | generic
            r = self.social.audit(text)
            domain_flag = r.overall_risk
            domain_risk = r.gaslighting_score
            raw_domain = r.to_dict()

        # --- Veredicto global cruzado ---
        # Umbral de coherencia ajustado por tipo de documento.
        # Texto legal: cláusulas intencionalmente aisladas → coherencia baja es normal.
        # Código: bloques independientes → similar al legal.
        # Discurso/paper: se espera conectividad narrativa.
        coherence_floor = {
            "legal":    0.10,   # contratos: fragmentación estructural esperada
            "code":     0.12,   # código: bloques independientes
            "finance":  0.15,
            "discourse":0.30,
            "generic":  0.20,
        }.get(input_type, 0.20)

        manifold_signal = (
            1.0 if m_result.verdict == "ANOMALY" else
            0.5 if m_result.verdict == "TENSION" else
            0.0
        )
        topo_signal = 1.0 if (t_result.flag == "FRAGMENTED" and
                              t_result.coherence_score < coherence_floor) else 0.0

        risk_signals = sum([
            manifold_signal,
            topo_signal,
            1.0 if domain_risk >= 0.20 else 0.0,
        ])

        overall = (
            "HIGH_RISK" if risk_signals >= 2.0
            else "REVIEW"  if risk_signals >= 0.5
            else "CLEAR"
        )

        # Compatibilidad con generate_sovereignty_report
        sov = self.generate_sovereignty_report(
            {"noise_level": domain_risk},
            {},
            {"gaslighting_score": m_result.gap if m_result.gap == m_result.gap else 0.0},
        )

        ms = m_result.manifold_score
        safe_score = ms if ms == ms else -1.0  # NaN → -1

        return FullDiagnosticReport(
            input_type=input_type,
            manifold_verdict=m_result.verdict,
            manifold_score=safe_score,
            topology_flag=t_result.flag,
            coherence_score=t_result.coherence_score,
            domain_flag=domain_flag,
            domain_risk=round(domain_risk, 6),
            overall_verdict=overall,
            confidence=m_result.confidence,
            sovereignty_verdict=sov["sovereignty_verdict"],
            action_recommended=sov["action_recommended"],
            raw_reports={
                "manifold_summary": m_result.summary,
                "topology": t_result.to_dict(),
                "domain": raw_domain,
            },
        )
