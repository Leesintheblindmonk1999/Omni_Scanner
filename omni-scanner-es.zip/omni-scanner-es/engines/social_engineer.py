"""
social_engineer.py — Omni-Scanner Semántico v1.0
-------------------------------------------------
Detector de manipulación discursiva: gaslighting, presión, sesgos cognitivos.
Integra TopologyMapper del core para análisis de estructura lógica real.

CHANGELOG vs versión original:
  + analyze_discourse(message) preservada con firma original
  + FIX CRÍTICO: map_logic_flow([(0,1,1)]) era un grafo hardcodeado de 1 arista
    → ahora usa topology_mapper.analyze(text) sobre el texto real
  + FIX: gaslighting_index = hits/10 (divisor fijo) → ahora hits/total_keywords
  + NUEVO: manipulation_keywords expandido con categorías semánticas
  + NUEVO: SocialEngineerReport dataclass para integración con FullDiagnostic
  + NUEVO: detect_pressure_tactics(), detect_minimization(), detect_deflection()
"""
from __future__ import annotations
import re
import sys
import os
from dataclasses import dataclass, field
from typing import List

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from core.topology_mapper import TopologyMapper


# ------------------------------------------------------------------
# Diccionarios por categoría táctica
# ------------------------------------------------------------------

PRESSURE_KEYWORDS = [
    "urgente", "inmediatamente", "ahora mismo", "sin demora",
    "última oportunidad", "plazo vence", "no hay tiempo",
]

MINIMIZATION_KEYWORDS = [
    "exagerado", "exageras", "no es para tanto", "estás siendo dramático",
    "todos lo hacen", "es lo normal", "es estándar", "es el procedimiento",
    "es política de empresa", "común", "siempre fue así",
]

DEFLECTION_KEYWORDS = [
    "confía en nosotros", "no te preocupes", "ya lo resolveremos",
    "ese no es el punto", "no viene al caso", "eso es otro tema",
    "limitación técnica", "política interna", "no depende de mí",
]

CREDIBILITY_ATTACK = [
    "no tienes experiencia", "no entiendes cómo funciona",
    "eso no tiene base", "nadie más lo ve así", "estás equivocado",
    "no es científico", "no está probado",
]

# Todos los keywords para compatibilidad con API original
ALL_MANIPULATION_KEYWORDS = (
    PRESSURE_KEYWORDS + MINIMIZATION_KEYWORDS +
    DEFLECTION_KEYWORDS + CREDIBILITY_ATTACK
)


@dataclass
class SocialEngineerReport:
    gaslighting_score: float        # [0, 1] (API original)
    manipulation_triggers: List[str]
    logical_traps: str              # "DETECTADAS" | "LIMPIO" (API original)
    tone_diagnostic: str            # "SUPRESIVO" | "NEUTRAL" (API original)
    pressure_hits: List[str]
    minimization_hits: List[str]
    deflection_hits: List[str]
    credibility_attack_hits: List[str]
    topology_coherence: float
    overall_risk: str               # "CLEAN" | "SUSPICIOUS" | "HIGH_RISK"

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items()}


class SocialEngineer:
    """
    Parameters
    ----------
    risk_threshold_suspicious : float
    risk_threshold_high : float
    """

    def __init__(
        self,
        risk_threshold_suspicious: float = 0.08,
        risk_threshold_high: float = 0.25,
    ):
        self.mapper = TopologyMapper()
        self.risk_threshold_suspicious = risk_threshold_suspicious
        self.risk_threshold_high = risk_threshold_high
        # Preservado para compatibilidad con API original
        self.manipulation_keywords = [
            "urgente", "estándar", "confía", "procedimiento",
            "común", "exagerado", "limitación", "política",
        ]

    # ------------------------------------------------------------------
    # API ORIGINAL (preservada para compatibilidad)
    # ------------------------------------------------------------------

    def analyze_discourse(self, message: str) -> dict:
        """
        Mapea la intención real detrás de las palabras.
        API original corregida y extendida.

        FIX 1: Usa topology_mapper.analyze(message) sobre el texto real
                en lugar de un grafo hardcodeado.
        FIX 2: gaslighting_index = hits / total_keywords (no / 10 fijo).
        """
        t = message.lower()
        pressure_points = [k for k in self.manipulation_keywords if k in t]

        # FIX CRÍTICO: análisis topológico real del texto
        topology = self.mapper.analyze(message)
        circular = topology.circular_logic_detected

        total = len(self.manipulation_keywords)
        gaslighting_index = len(pressure_points) / max(total, 1)

        return {
            "gaslighting_score": round(gaslighting_index, 4),
            "manipulation_triggers": pressure_points,
            "logical_traps": "DETECTADAS" if circular else "LIMPIO",
            "tone_diagnostic": "SUPRESIVO" if gaslighting_index > 0.5 else "NEUTRAL",
        }

    # ------------------------------------------------------------------
    # API EXTENDIDA
    # ------------------------------------------------------------------

    def audit(self, text: str) -> SocialEngineerReport:
        """Pipeline completo → SocialEngineerReport estructurado."""
        t = text.lower()

        pressure = [k for k in PRESSURE_KEYWORDS if k in t]
        minimization = [k for k in MINIMIZATION_KEYWORDS if k in t]
        deflection = [k for k in DEFLECTION_KEYWORDS if k in t]
        credibility = [k for k in CREDIBILITY_ATTACK if k in t]

        all_hits = pressure + minimization + deflection + credibility
        total = len(ALL_MANIPULATION_KEYWORDS)
        score = len(all_hits) / max(total, 1)

        topology = self.mapper.analyze(text)

        overall = (
            "HIGH_RISK" if score >= self.risk_threshold_high
            else "SUSPICIOUS" if score >= self.risk_threshold_suspicious
            else "CLEAN"
        )

        return SocialEngineerReport(
            gaslighting_score=round(score, 6),
            manipulation_triggers=all_hits,
            logical_traps="DETECTADAS" if topology.circular_logic_detected else "LIMPIO",
            tone_diagnostic="SUPRESIVO" if score > 0.5 else "NEUTRAL",
            pressure_hits=pressure,
            minimization_hits=minimization,
            deflection_hits=deflection,
            credibility_attack_hits=credibility,
            topology_coherence=topology.coherence_score,
            overall_risk=overall,
        )
