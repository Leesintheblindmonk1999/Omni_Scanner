"""
law_auditor.py — Omni-Scanner Semántico v1.0
---------------------------------------------
Auditoría de contratos: detecta cláusulas abusivas, renuncias de derechos
y lenguaje de alta vaguedad. Integra EntropyAnalyzer del core.

CHANGELOG vs versión original:
  + scan_contract(text) preservada con firma original
  + FIX: noise_level ahora combina entropía de palabras + gap, no solo chars
  + FIX: origin_recognition eliminado como marcador personal hardcodeado.
         Reemplazado por detección de cláusulas de atribución/autoría reales.
  + NUEVO: red_flags expandido con regex para español con acentos
  + NUEVO: detect_trap_clauses() — asimetrías de poder contractuales
  + NUEVO: LawAuditorReport dataclass para integración con FullDiagnostic
"""
from __future__ import annotations
import re
import sys
import os
from dataclasses import dataclass, field
from typing import List

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from core.entropy_analyzer import EntropyAnalyzer


# ------------------------------------------------------------------
# Diccionarios de riesgo legal (regex, español)
# ------------------------------------------------------------------

RED_FLAGS = [
    # API original (convertidas a regex robustas)
    r"propiedad\s+exclusiva",
    r"renuncia\s+irrevocable",
    r"derechos\s+de\s+autor\s+del\s+empleador",
    r"confidencialidad\s+perpetua",
    r"licencia\s+gratuita",
    r"usuario\s+final",
    # Nuevas
    r"cede?\s+(todos\s+los\s+derechos|la\s+totalidad)",
    r"sin\s+derecho\s+a\s+compensaci[oó]n",
    r"de\s+forma\s+exclusiva\s+y\s+(permanente|perpetua)",
    r"propiedad\s+intelectual.{0,50}cede?",
]

TRAP_CLAUSES = [
    r"terminaci[oó]n\s+unilateral",
    r"modificar\s+unilateralmente",
    r"sin\s+previo\s+aviso",
    r"a\s+criterio\s+(exclusivo\s+)?de\s+la\s+(empresa|parte)",
    r"renunci[ao]\s+expresamente\s+a",
    r"no\s+hay\s+derecho\s+a\s+apelar",
]

AUTHORSHIP_CLAUSES = [
    # Cláusulas que reconocen autoría previa / prior art
    r"el\s+(autor|creador|inventor)\s+retiene",
    r"prior\s+art\s+(reconocido|declarado)",
    r"propiedad\s+intelectual\s+preexistente",
    r"derechos\s+morales\s+(del\s+autor|inalienables)",
    r"autoría\s+original\s+reconocida",
]

COERCION_PATTERNS = [
    r"no\s+(tienes?|tiene)\s+opci[oó]n",
    r"nos\s+veremos\s+obligados",
    r"o\s+acepta\s+o",
    r"con\s+consecuencias\s+legales",
    r"sin\s+alternativa",
]


@dataclass
class LawAuditorReport:
    critical_findings: List[str]
    trap_clause_hits: List[str]
    coercion_hits: List[str]
    authorship_clauses_present: bool
    noise_level: float              # entropía de palabras (API original)
    entropy_flag: str               # OK | NOISE | INSUFFICIENT_DATA
    legal_risk_score: float         # [0, 1]
    verdict: str                    # "ESTABLE" | "REVISIÓN URGENTE" | "ALTO RIESGO"

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items()}


class LawAuditor:
    """
    Parameters
    ----------
    risk_threshold : float   Umbral para escalar de REVISIÓN a ALTO RIESGO.
    """

    def __init__(self, risk_threshold: float = 0.15):
        self.entropy = EntropyAnalyzer()
        self.risk_threshold = risk_threshold
        # Preservado para compatibilidad con API original
        self.red_flags = [
            "propiedad exclusiva", "renuncia irrevocable",
            "derechos de autor del empleador", "confidencialidad perpetua",
            "90 días", "usuario final", "licencia gratuita",
        ]

    # ------------------------------------------------------------------
    # API ORIGINAL (preservada para compatibilidad)
    # ------------------------------------------------------------------

    def scan_contract(self, text: str) -> dict:
        """
        Busca vulnerabilidades en el tejido legal.
        API original extendida: más detección, mejor noise_level, sin marcadores personales.
        """
        findings = []
        for flag in RED_FLAGS:
            try:
                if re.search(flag, text, re.IGNORECASE):
                    findings.append(f"ALERTA ROJA: Cláusula de riesgo detectada → '{flag}'")
            except re.error:
                if flag.lower() in text.lower():
                    findings.append(f"ALERTA ROJA: '{flag}'")

        # Entropía de palabras (más significativa que entropía de caracteres para contratos)
        e_report = self.entropy.analyze(text)
        noise_level = e_report.word_entropy

        # Atribución/autoría: busca cláusulas que reconocen prior art
        authorship_present = any(
            re.search(p, text, re.IGNORECASE) for p in AUTHORSHIP_CLAUSES
        )
        origin_status = "RECONOCIDO" if authorship_present else "NO ESPECIFICADO"

        verdict = (
            "REVISIÓN URGENTE"
            if len(findings) > 0 or origin_status == "NO ESPECIFICADO"
            else "ESTABLE"
        )

        return {
            "critical_findings": findings,
            "noise_level": round(noise_level, 4),
            "origin_recognition": origin_status,
            "verdict": verdict,
        }

    # ------------------------------------------------------------------
    # API EXTENDIDA
    # ------------------------------------------------------------------

    def audit(self, text: str) -> LawAuditorReport:
        """Pipeline completo → LawAuditorReport estructurado."""
        base = self.scan_contract(text)
        t = text.lower()

        trap_hits = [p for p in TRAP_CLAUSES if re.search(p, t)]
        coercion_hits = [p for p in COERCION_PATTERNS if re.search(p, t)]
        authorship = any(re.search(p, t, re.IGNORECASE) for p in AUTHORSHIP_CLAUSES)

        e_report = self.entropy.analyze(text)
        total_checks = len(RED_FLAGS) + len(TRAP_CLAUSES) + len(COERCION_PATTERNS)
        hits = len(base["critical_findings"]) + len(trap_hits) + len(coercion_hits)
        risk = hits / max(total_checks, 1)

        if risk >= self.risk_threshold * 2:
            verdict = "ALTO RIESGO"
        elif risk >= self.risk_threshold or len(base["critical_findings"]) > 0:
            verdict = "REVISIÓN URGENTE"
        else:
            verdict = "ESTABLE"

        return LawAuditorReport(
            critical_findings=base["critical_findings"],
            trap_clause_hits=trap_hits,
            coercion_hits=coercion_hits,
            authorship_clauses_present=authorship,
            noise_level=base["noise_level"],
            entropy_flag=e_report.flag,
            legal_risk_score=round(risk, 6),
            verdict=verdict,
        )
