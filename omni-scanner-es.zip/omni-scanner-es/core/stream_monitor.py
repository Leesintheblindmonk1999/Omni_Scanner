"""
core/stream_monitor.py — Omni-Scanner Semántico v2.0
═══════════════════════════════════════════════════════
Escudo de Invarianza — Live Stream Firewall

Monitorea el output de una IA externa token a token usando una
ventana deslizante. Si el ManifoldScore acumulado desciende de
κD = 0.56 durante N ventanas consecutivas, ejecuta una
"Desconexión por Incoherencia" — la válvula matemática de seguridad.

Arquitectura:
  token_stream → buffer deslizante → ManifoldEngine.analyze()
               → score acumulado → comparar con κD
               → ShieldEvent (OK / WARNING / DISCONNECTION)

Uso:
    monitor = StreamMonitor(kappa_d=0.56, window_size=80)
    for event in monitor.monitor_stream(token_generator):
        if event.action == "DISCONNECT":
            break   # válvula de seguridad activada
        print(event.partial_text)
"""
from __future__ import annotations

import re
import sys
import os
import time
import hashlib
import datetime
from dataclasses import dataclass, field
from typing import Iterator, Optional, Generator, Callable

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from core.manifold_engine import ManifoldEngine


# ══════════════════════════════════════════════════════════════
# Estructuras de datos
# ══════════════════════════════════════════════════════════════

@dataclass
class ShieldEvent:
    """
    Evento emitido por el monitor por cada ventana analizada.
    La UI consume estos eventos para actualizar el estado en tiempo real.
    """
    window_index:    int
    action:          str    # "OK" | "WARNING" | "DISCONNECT"
    manifold_score:  float
    window_text:     str    # texto de la ventana actual
    accumulated_text: str   # texto total procesado hasta ahora
    tokens_processed: int
    consecutive_drops: int  # ventanas consecutivas bajo κD
    kappa_d:         float
    timestamp:       str
    reason:          str = ""

    @property
    def is_safe(self) -> bool:
        return self.action == "OK"

    @property
    def score_delta_from_kd(self) -> float:
        return round(self.manifold_score - self.kappa_d, 6)


@dataclass
class StreamReport:
    """Reporte final después de procesar el stream completo."""
    total_tokens:        int
    total_windows:       int
    final_action:        str        # "COMPLETED" | "DISCONNECTED"
    disconnect_at_token: Optional[int]
    disconnect_reason:   str
    min_score:           float
    max_score:           float
    mean_score:          float
    windows_below_kd:    int
    windows_above_kd:    int
    kappa_d:             float
    full_text_safe:      str        # texto que pasó el filtro
    events:              list       = field(default_factory=list)

    @property
    def integrity_ratio(self) -> float:
        if self.total_windows == 0:
            return 1.0
        return round(self.windows_above_kd / self.total_windows, 4)


# ══════════════════════════════════════════════════════════════
# Motor principal
# ══════════════════════════════════════════════════════════════

class StreamMonitor:
    """
    Escudo de Invarianza — válvula de seguridad matemática para streams de IA.

    Parámetros
    ----------
    kappa_d : float
        Umbral κD. Score < kappa_d activa el contador de drops.
    window_size : int
        Tokens por ventana de análisis (default 80 — ~1 párrafo corto).
    step_size : int
        Avance de la ventana deslizante (default 40 — 50% overlap).
    max_consecutive_drops : int
        Ventanas consecutivas bajo κD para activar DISCONNECT (default 3).
    warn_threshold : float
        Score entre warn_threshold y kappa_d emite WARNING sin desconectar.
    """

    def __init__(
        self,
        kappa_d: float = 0.56,
        window_size: int = 80,
        step_size: int = 40,
        max_consecutive_drops: int = 3,
        warn_threshold: float = 0.45,
        embedding_dim: int = 15,
    ):
        self.kappa_d              = kappa_d
        self.window_size          = window_size
        self.step_size            = step_size
        self.max_drops            = max_consecutive_drops
        self.warn_threshold       = warn_threshold
        self._engine              = ManifoldEngine(K_DURANTE=kappa_d)

    # ── API principal ─────────────────────────────────────────

    def monitor_stream(
        self,
        token_stream: Iterator[str],
        on_event: Optional[Callable[[ShieldEvent], None]] = None,
    ) -> Generator[ShieldEvent, None, None]:
        """
        Generador principal. Consume tokens del stream y emite ShieldEvents.

        Uso básico:
            for event in monitor.monitor_stream(mi_generador):
                if event.action == "DISCONNECT":
                    print("Desconexión por incoherencia:", event.reason)
                    break

        Parámetros
        ----------
        token_stream : iterator de strings (tokens, palabras, o chunks)
        on_event : callback opcional por cada evento (para logging externo)
        """
        buffer:       list[str]  = []
        accumulated:  list[str]  = []
        window_idx    = 0
        consecutive   = 0
        scores_seen:  list[float] = []
        ts = datetime.datetime.utcnow

        for token in token_stream:
            buffer.append(token)
            accumulated.append(token)

            # Analizar cuando el buffer alcanza window_size tokens
            if len(buffer) >= self.window_size:
                window_text = " ".join(buffer)
                acc_text    = " ".join(accumulated)

                event = self._analyze_window(
                    window_text, acc_text, window_idx,
                    len(accumulated), consecutive,
                    ts().strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z",
                )

                # Actualizar estado
                scores_seen.append(event.manifold_score)
                if event.action in ("WARNING", "DISCONNECT"):
                    consecutive += 1
                else:
                    consecutive = 0  # reset al recuperarse

                # Sobreescribir acción si superamos max_drops
                if consecutive >= self.max_drops and event.action != "DISCONNECT":
                    event.action = "DISCONNECT"
                    event.consecutive_drops = consecutive
                    event.reason = (
                        f"Desconexión por Incoherencia: {consecutive} ventanas "
                        f"consecutivas con ManifoldScore < κD={self.kappa_d}. "
                        f"Score actual: {event.manifold_score:.4f}"
                    )

                if on_event:
                    on_event(event)

                yield event

                # Si se desconecta, detener el stream
                if event.action == "DISCONNECT":
                    return

                # Avanzar ventana deslizante: remover step_size tokens del inicio
                buffer = buffer[self.step_size:]
                window_idx += 1

        # Analizar tokens residuales si quedan suficientes
        if len(buffer) >= 20:
            window_text = " ".join(buffer)
            acc_text    = " ".join(accumulated)
            event = self._analyze_window(
                window_text, acc_text, window_idx,
                len(accumulated), consecutive,
                ts().strftime("%Y-%m-%dT%H:%M:%SZ"),
            )
            scores_seen.append(event.manifold_score)
            if on_event:
                on_event(event)
            yield event

    def analyze_text_as_stream(
        self,
        text: str,
        chunk_by: str = "words",
    ) -> StreamReport:
        """
        Analiza un texto completo simulándolo como stream.
        Útil para testing o para analizar outputs ya generados.

        chunk_by: "words" | "sentences" | "chars"
        """
        if chunk_by == "sentences":
            tokens = re.split(r"(?<=[.!?])\s+", text.strip())
            tokens = [t for t in tokens if t.strip()]
        elif chunk_by == "chars":
            tokens = list(text)
        else:
            tokens = text.split()

        events   = []
        all_safe = []

        for event in self.monitor_stream(iter(tokens)):
            events.append(event)
            if event.action == "OK":
                all_safe.append(event.window_text)
            elif event.action == "DISCONNECT":
                break

        scores = [e.manifold_score for e in events if e.manifold_score > 0]
        disconnected = any(e.action == "DISCONNECT" for e in events)
        disc_event   = next((e for e in events if e.action == "DISCONNECT"), None)

        return StreamReport(
            total_tokens        = sum(len(e.window_text.split()) for e in events),
            total_windows       = len(events),
            final_action        = "DISCONNECTED" if disconnected else "COMPLETED",
            disconnect_at_token = disc_event.tokens_processed if disc_event else None,
            disconnect_reason   = disc_event.reason if disc_event else "",
            min_score           = round(min(scores), 6) if scores else 0.0,
            max_score           = round(max(scores), 6) if scores else 0.0,
            mean_score          = round(sum(scores)/len(scores), 6) if scores else 0.0,
            windows_below_kd    = sum(1 for s in scores if s < self.kappa_d),
            windows_above_kd    = sum(1 for s in scores if s >= self.kappa_d),
            kappa_d             = self.kappa_d,
            full_text_safe      = " ".join(all_safe),
            events              = events,
        )

    # ── Análisis de ventana ───────────────────────────────────

    def _analyze_window(
        self,
        window_text: str,
        accumulated_text: str,
        window_idx: int,
        tokens_processed: int,
        consecutive: int,
        timestamp: str,
    ) -> ShieldEvent:
        """Analiza una ventana de texto y emite el ShieldEvent correspondiente."""
        try:
            result = self._engine.analyze(window_text)
            score  = result.manifold_score
        except Exception:
            score = self.kappa_d   # si falla el análisis, no desconectar

        # Clasificar acción
        if score >= self.kappa_d:
            action = "OK"
            reason = ""
        elif score >= self.warn_threshold:
            action = "WARNING"
            reason = (
                f"ManifoldScore={score:.4f} en zona de tensión "
                f"[{self.warn_threshold:.2f}, {self.kappa_d})"
            )
        else:
            action = "DISCONNECT"
            reason = (
                f"ManifoldScore={score:.4f} < warn_threshold={self.warn_threshold}. "
                f"Incoherencia estructural severa detectada."
            )

        return ShieldEvent(
            window_index      = window_idx,
            action            = action,
            manifold_score    = round(score, 6),
            window_text       = window_text[:200],   # truncar para logs
            accumulated_text  = accumulated_text[-500:],  # últimos 500 chars
            tokens_processed  = tokens_processed,
            consecutive_drops = consecutive + (1 if action != "OK" else 0),
            kappa_d           = self.kappa_d,
            timestamp         = timestamp,
            reason            = reason,
        )


# ══════════════════════════════════════════════════════════════
# Generador de Contra-Contexto (reencuadre del módulo 3)
# ══════════════════════════════════════════════════════════════

class ContradictionProbe:
    """
    Generador de Contra-Contexto para verificación estructurada.

    Dado un output de IA con métricas anómalas, genera prompts de
    verificación que exponen inconsistencias lógicas sin manipular
    el comportamiento del sistema externo — solo interrogando
    la coherencia interna del texto producido.

    Esto es auditoría, no adversarial prompting.
    """

    PROBE_TEMPLATES = {
        "MANIFOLD_RUPTURE": (
            "El siguiente fragmento presenta una anomalía topológica "
            "(ManifoldScore={score:.3f}, bajo κD={kd}).\n"
            "Por favor verificá las siguientes inconsistencias estructurales:\n"
            "{inconsistencies}\n"
            "Fragmento a revisar:\n---\n{text}\n---"
        ),
        "HIGH_ENTROPY": (
            "Este fragmento presenta alta entropía residual (score={score:.3f}).\n"
            "Solicitamos clarificación sobre los siguientes puntos:\n"
            "{inconsistencies}\n"
            "Fragmento:\n---\n{text}\n---"
        ),
        "CIRCULAR_LOGIC": (
            "Se detectaron {h1_count} ciclos H₁ estructurales en este fragmento.\n"
            "Los siguientes argumentos parecen circulares:\n"
            "{inconsistencies}\n"
            "Fragmento:\n---\n{text}\n---"
        ),
    }

    def __init__(self, kappa_d: float = 0.56):
        self.kappa_d = kappa_d
        self._engine = ManifoldEngine(K_DURANTE=kappa_d)

    def generate_probe(
        self,
        text: str,
        max_probes: int = 5,
    ) -> dict:
        """
        Analiza el texto y genera preguntas de verificación estructurada.

        Retorna dict con:
          - 'probe_type': tipo de anomalía detectada
          - 'probe_text': el prompt de verificación
          - 'score': ManifoldScore del texto
          - 'inconsistencies': lista de puntos a verificar
        """
        result = self._engine.analyze(text)
        score  = result.manifold_score

        # Extraer oraciones para análisis
        sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", text) if len(s.strip()) > 15]

        # Detectar inconsistencias por tipo
        inconsistencies = self._detect_inconsistencies(sentences, result)[:max_probes]

        # Seleccionar plantilla
        if score < self.kappa_d * 0.5:
            ptype = "MANIFOLD_RUPTURE"
        elif score < self.kappa_d:
            ptype = "HIGH_ENTROPY"
        else:
            ptype = "CIRCULAR_LOGIC"

        template = self.PROBE_TEMPLATES[ptype]
        incons_text = "\n".join(f"  {i+1}. {inc}" for i, inc in enumerate(inconsistencies))

        probe_text = template.format(
            score=score,
            kd=self.kappa_d,
            inconsistencies=incons_text or "  (No se detectaron inconsistencias específicas)",
            text=text[:500],
            h1_count=0,
        )

        return {
            "probe_type":       ptype,
            "probe_text":       probe_text,
            "score":            round(score, 6),
            "verdict":          result.verdict,
            "inconsistencies":  inconsistencies,
            "requires_review":  score < self.kappa_d,
        }

    def _detect_inconsistencies(self, sentences: list, result) -> list:
        """Detecta inconsistencias lógicas básicas en el texto."""
        issues = []

        # Afirmaciones contradictorias (patrón simple)
        negation_pairs = [
            ("no ", "sí "), ("nunca", "siempre"), ("imposible", "posible"),
            ("prohibido", "permitido"), ("garantiza", "no garantiza"),
            ("incluye", "no incluye"), ("tiene derecho", "no tiene derecho"),
        ]
        text_lower = " ".join(sentences).lower()
        for pos, neg in negation_pairs:
            if pos in text_lower and neg in text_lower:
                issues.append(f"Posible contradicción: '{pos}' y '{neg}' coexisten en el texto")

        # Score bajo sin justificación aparente
        if result.manifold_score < self.kappa_d:
            issues.append(
                f"ManifoldScore={result.manifold_score:.3f} indica baja coherencia "
                f"estructural — verificar la consistencia lógica del argumento central"
            )

        # Texto muy corto con veredicto negativo
        if len(sentences) < 5 and result.verdict in ("ANOMALY", "TENSION"):
            issues.append(
                "Texto breve con alta densidad de inconsistencia — "
                "posible omisión deliberada de contexto relevante"
            )

        return issues
