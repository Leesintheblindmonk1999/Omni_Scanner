"""
core/ledger_vanguard.py — Omni-Scanner Semántico v2.0
═══════════════════════════════════════════════════════
Forensic Ledger — Registro Inmutable de Veredictos

Genera hashes SHA-256 que vinculan documento + ManifoldScore +
timestamp. El hash es determinístico: los mismos inputs siempre
producen el mismo hash, lo que permite verificación independiente.

Esquema de anclaje blockchain (Blockchain Readiness):
  - Compatible con OpenTimestamps (OTS) — ancla en Bitcoin via merkle
  - Compatible con Ethereum calldata — hash embebible en tx.data
  - Genera el payload listo para firmar; el broadcast es responsabilidad
    del operador (requiere wallet/nodo externo)
"""
from __future__ import annotations
import hashlib
import json
import datetime
import struct
from dataclasses import dataclass
from typing import Optional


@dataclass
class LedgerEntry:
    """Entrada inmutable del Forensic Ledger."""
    entry_hash:     str     # SHA-256 del payload canónico
    doc_hash:       str     # SHA-256 del texto original
    manifold_score: float
    verdict:        str
    timestamp_utc:  str
    kappa_d:        float
    ots_payload:    str     # hex del payload para OpenTimestamps
    eth_calldata:   str     # hex del calldata para Ethereum
    canonical_json: str     # JSON reproducible para verificación

    def verify(self, text: str, score: float) -> bool:
        """Verifica que este entry corresponde al texto y score dados."""
        expected = LedgerVanguard().sign(text, score, self.verdict, self.kappa_d)
        return expected.entry_hash == self.entry_hash


class LedgerVanguard:
    """
    Motor de firma forense para veredictos del Omni-Scanner.

    El hash combina:
      SHA-256( doc_hash || manifold_score_bytes || timestamp || verdict || kappa_d )

    La concatenación es determinística via JSON canónico (keys ordenadas).
    """

    def sign(
        self,
        text: str,
        manifold_score: float,
        verdict: str,
        kappa_d: float = 0.56,
        timestamp_utc: Optional[str] = None,
    ) -> LedgerEntry:
        ts = timestamp_utc or datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"

        # Hash del documento original
        doc_hash = hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()

        # Payload canónico — JSON con keys ordenadas para reproducibilidad
        payload = {
            "doc_hash":      doc_hash,
            "kappa_d":       kappa_d,
            "manifold_score": round(manifold_score, 8),
            "timestamp_utc": ts,
            "verdict":       verdict,
            "version":       "omni-scanner-v2.0",
        }
        canonical = json.dumps(payload, sort_keys=True, ensure_ascii=True)
        entry_hash = hashlib.sha256(canonical.encode("ascii")).hexdigest()

        # Payload OTS: prefijo estándar + hash (listo para ots-client stamp)
        ots_payload = "4f54530001" + entry_hash  # OTS magic + hash

        # Ethereum calldata: 0x + método ficticio + hash
        # En producción: abi.encode(bytes32(hash)) en contrato de registro
        eth_calldata = "0x" + "a0b1c2d3" + entry_hash  # selector + hash

        return LedgerEntry(
            entry_hash      = entry_hash,
            doc_hash        = doc_hash,
            manifold_score  = manifold_score,
            verdict         = verdict,
            timestamp_utc   = ts,
            kappa_d         = kappa_d,
            ots_payload     = ots_payload,
            eth_calldata    = eth_calldata,
            canonical_json  = canonical,
        )

    def verify_entry(self, entry: LedgerEntry, text: str) -> dict:
        """Verifica la integridad de una entrada del ledger."""
        recomputed_doc = hashlib.sha256(
            text.encode("utf-8", errors="replace")
        ).hexdigest()

        payload = json.loads(entry.canonical_json)
        recomputed_entry = hashlib.sha256(
            entry.canonical_json.encode("ascii")
        ).hexdigest()

        return {
            "doc_hash_match":   recomputed_doc == entry.doc_hash,
            "entry_hash_match": recomputed_entry == entry.entry_hash,
            "tampered":         recomputed_entry != entry.entry_hash,
            "recomputed_entry": recomputed_entry,
            "stored_entry":     entry.entry_hash,
        }
