"""
protocols/__init__.py
---------------------
Loader y validador de los archivos de configuración del protocolo.
Expone los parámetros como objetos Python validados para uso en el pipeline.
"""
from __future__ import annotations
import json
from pathlib import Path
from typing import Any


_PROTOCOLS_DIR = Path(__file__).parent


def _load_json(filename: str) -> dict:
    path = _PROTOCOLS_DIR / filename
    if not path.exists():
        raise FileNotFoundError(f"Archivo de protocolo no encontrado: {path}")
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _validate_weights(weights: dict, name: str) -> None:
    """Verifica que los pesos sumen 1.0 (tolerancia ±0.01)."""
    total = sum(weights.values())
    if not (0.99 <= total <= 1.01):
        raise ValueError(
            f"[{name}] Los pesos de riesgo deben sumar 1.0, encontrado: {total:.4f}"
        )


def _validate_thresholds(metrics: dict, name: str) -> None:
    """Verifica que los umbrales numéricos sean positivos y finitos."""
    for key, val in metrics.items():
        if isinstance(val, (int, float)):
            if not (0.0 <= val <= 10_000):
                raise ValueError(
                    f"[{name}] Umbral fuera de rango: {key} = {val}"
                )


class ProtocolConfig:
    """
    Interfaz unificada a los archivos de protocolo.
    Carga, valida y expone universal_stability.json y anexa_ultra_v4.json.
    """

    def __init__(self):
        self._stability = _load_json("universal_stability.json")
        self._anexa = _load_json("anexa_ultra_v4.json")
        self._validate()

    def _validate(self) -> None:
        _validate_weights(self._anexa["risk_weighting"], "anexa_ultra_v4")
        _validate_weights(self._stability["analysis_weights"], "universal_stability")
        _validate_thresholds(self._anexa["stability_metrics"], "anexa_ultra_v4")
        _validate_thresholds(self._stability["thresholds"], "universal_stability")

    # --- Accesores directos para el pipeline ---

    @property
    def stability_constant(self) -> float:
        return self._stability["universal_axioms"]["semantic_invariance_constant"]

    @property
    def noise_gap_threshold(self) -> float:
        return self._stability["thresholds"]["noise_gap_max"]

    @property
    def plagiarism_threshold(self) -> float:
        return self._stability["thresholds"]["plagiarism_cosine_min"]

    @property
    def coherence_min(self) -> float:
        return self._stability["thresholds"]["coherence_score_min"]

    @property
    def risk_weights(self) -> dict:
        return self._anexa["risk_weighting"]

    @property
    def verdict_thresholds(self) -> dict:
        return self._anexa["verdict_thresholds"]

    @property
    def operational_mode(self) -> dict:
        return self._stability["operational_modes"]

    def get(self, *keys: str, default: Any = None) -> Any:
        """Acceso genérico por claves anidadas: config.get('thresholds', 'noise_gap_max')"""
        obj = self._stability
        for k in keys:
            if isinstance(obj, dict) and k in obj:
                obj = obj[k]
            else:
                # Intenta en anexa
                obj2 = self._anexa
                for k2 in keys:
                    if isinstance(obj2, dict) and k2 in obj2:
                        obj2 = obj2[k2]
                    else:
                        return default
                return obj2
        return obj

    def to_dict(self) -> dict:
        return {"universal_stability": self._stability, "anexa_ultra_v4": self._anexa}


# Instancia global (singleton ligero — se carga una sola vez)
try:
    CONFIG = ProtocolConfig()
except Exception as e:
    import warnings
    warnings.warn(f"[protocols] No se pudo cargar la configuración: {e}")
    CONFIG = None

from .metadata_origin import MetadataOrigin, Signature

__all__ = ["ProtocolConfig", "CONFIG", "MetadataOrigin", "Signature"]
