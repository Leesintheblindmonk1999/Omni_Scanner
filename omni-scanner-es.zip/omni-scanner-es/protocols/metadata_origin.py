"""
metadata_origin.py — Omni-Scanner Semántico v1.0
-------------------------------------------------
Sello de autoría y registro de génesis. Genera firmas SHA-256 que vinculan
reportes al autor del sistema y al protocolo operativo.

CHANGELOG vs versión original:
  + generate_signature(report_content) preservada con firma original
  + NUEVO: verify_signature(report_content, stored_signature) — verifica integridad
  + NUEVO: sign_report(report_dict) — firma un dict completo y lo retorna enriquecido
  + NUEVO: generate_chain_hash(signatures) — encadena firmas para historial inmutable
  + NUEVO: to_manifest() — exporta metadatos de autoría como dict serializable
"""
from __future__ import annotations
import hashlib
import datetime
import json
from dataclasses import dataclass
from typing import Optional


@dataclass
class Signature:
    signed_by: str
    protocol: str
    hash_genesis: str
    timestamp: str
    content_hash: str       # hash solo del contenido (sin timestamp, verificable)

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items()}

    def is_valid_for(self, report_content: str) -> bool:
        """Verifica que el content_hash corresponde al contenido dado."""
        expected = hashlib.sha256(report_content.encode("utf-8")).hexdigest()
        return self.content_hash == expected


class MetadataOrigin:
    """
    Parameters
    ----------
    creator : str       Nombre del autor/nodo de origen.
    protocol : str      Nombre del protocolo operativo.
    genesis_date : str  Fecha de creación del sistema (ISO 8601).
    """

    def __init__(
        self,
        creator: str = "Gonzalo Emir Durante",
        protocol: str = "ANEXA Ultra v4.0",
        genesis_date: str = "2025-07-17",
    ):
        self.creator = creator
        self.protocol = protocol
        self.genesis_date = genesis_date

    # ------------------------------------------------------------------
    # API ORIGINAL (preservada para compatibilidad)
    # ------------------------------------------------------------------

    def generate_signature(self, report_content: str) -> dict:
        """
        Crea un hash único que vincula el reporte al Creador.
        API original preservada.
        """
        timestamp = datetime.datetime.now().isoformat()
        raw_data = f"{self.creator}|{self.protocol}|{timestamp}|{report_content}"
        signature = hashlib.sha256(raw_data.encode("utf-8")).hexdigest()

        return {
            "signed_by": self.creator,
            "protocol": self.protocol,
            "hash_genesis": signature,
            "timestamp": timestamp,
        }

    # ------------------------------------------------------------------
    # API EXTENDIDA
    # ------------------------------------------------------------------

    def sign(self, report_content: str) -> Signature:
        """
        Genera una Signature con hash de contenido separado del hash de sesión.
        El content_hash es determinista (mismo contenido → mismo hash),
        lo que permite verificación posterior independiente del timestamp.
        """
        timestamp = datetime.datetime.now().isoformat()
        content_hash = hashlib.sha256(report_content.encode("utf-8")).hexdigest()
        session_raw = f"{self.creator}|{self.protocol}|{timestamp}|{content_hash}"
        hash_genesis = hashlib.sha256(session_raw.encode("utf-8")).hexdigest()

        return Signature(
            signed_by=self.creator,
            protocol=self.protocol,
            hash_genesis=hash_genesis,
            timestamp=timestamp,
            content_hash=content_hash,
        )

    def sign_report(self, report_dict: dict) -> dict:
        """
        Firma un reporte dict completo y retorna el dict enriquecido
        con el bloque 'authorship' al final.
        """
        content_str = json.dumps(report_dict, default=str, sort_keys=True)
        sig = self.sign(content_str)
        enriched = dict(report_dict)
        enriched["authorship"] = sig.to_dict()
        return enriched

    def verify_signature(self, report_content: str, stored: dict) -> bool:
        """
        Verifica que un reporte no fue alterado desde su firma.

        Parameters
        ----------
        report_content : str    Contenido actual del reporte (como string).
        stored : dict           Dict de firma almacenada (output de generate_signature
                                o sign().to_dict()).
        """
        # Verificación por content_hash (API extendida)
        if "content_hash" in stored:
            expected = hashlib.sha256(report_content.encode("utf-8")).hexdigest()
            return stored["content_hash"] == expected

        # Fallback: no podemos reverificar hash_genesis sin el timestamp exacto
        # (hash_genesis incluye timestamp que no es reproducible)
        # Retornamos None para indicar "no verificable" sin lanzar excepción
        return None

    def generate_chain_hash(self, signatures: list[dict]) -> str:
        """
        Encadena múltiples firmas en un hash acumulativo.
        Permite construir un historial inmutable de auditorías:
        cada escaneo incluye el hash del anterior.
        """
        chain = ""
        for sig in signatures:
            chain += sig.get("hash_genesis", "")
        return hashlib.sha256(chain.encode("utf-8")).hexdigest()

    def to_manifest(self) -> dict:
        """Exporta metadatos de autoría como dict serializable."""
        return {
            "creator": self.creator,
            "protocol": self.protocol,
            "genesis_date": self.genesis_date,
            "system": "Omni-Scanner Semántico v1.0",
            "generated_at": datetime.datetime.now().isoformat(),
        }

    # ------------------------------------------------------------------
    # v3.0: ANCLA DE IDENTIDAD — PDF Steganographic Anchor
    # ------------------------------------------------------------------

    def embed_identity_anchor(self, pdf_path: "Path | str", cert_id: str = "") -> dict:
        """
        Inserta una firma criptográfica invisible en un PDF existente via
        metadatos XMP/Info estándar. No altera el contenido visual del PDF.

        El 'ancla' contiene:
          - Hash del Nodo de Origen (SHA-256 del creador + protocolo + genesis_date)
          - Timestamp TAD (fecha de registro del sistema)
          - Cert-ID del reporte
          - Checksum del propio PDF (para detectar alteraciones posteriores)

        Compatible con cualquier visor PDF — los metadatos son legibles
        por herramientas forenses estándar (exiftool, pdfinfo, etc.).

        Parámetros
        ----------
        pdf_path : Path | str    Ruta al PDF ya generado.
        cert_id  : str           Identificador del certificado (opcional).

        Retorna
        -------
        dict con los metadatos del ancla insertada.
        """
        from pathlib import Path as _Path
        import struct, zlib

        pdf_path = _Path(pdf_path)
        if not pdf_path.exists():
            raise FileNotFoundError(f"PDF no encontrado: {pdf_path}")

        # ── Calcular hashes ────────────────────────────────────────
        pdf_bytes    = pdf_path.read_bytes()
        pdf_sha256   = hashlib.sha256(pdf_bytes).hexdigest()
        origin_raw   = f"{self.creator}|{self.protocol}|{self.genesis_date}"
        origin_hash  = hashlib.sha256(origin_raw.encode("utf-8")).hexdigest()
        tad_ts       = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")

        anchor_payload = {
            "anchor_version":  "v3.0",
            "origin_hash":     origin_hash,
            "creator":         self.creator,
            "protocol":        self.protocol,
            "genesis_date":    self.genesis_date,
            "tad_timestamp":   tad_ts,
            "cert_id":         cert_id,
            "pdf_sha256":      pdf_sha256,
            "kappa_d":         "0.56",
            "nist_node":       f"OMNI-SCANNER · κD=0.56 · {self.protocol}",
        }

        # ── Serializar payload como JSON compacto ──────────────────
        anchor_json = json.dumps(anchor_payload, separators=(",", ":"))
        anchor_b64  = __import__("base64").b64encode(
            anchor_json.encode("utf-8")
        ).decode("ascii")

        # ── Inyectar en metadatos PDF /Info dictionary ─────────────
        # Estrategia: insertar antes del %%EOF un comentario PDF estándar
        # con prefijo "% OMNI-ANCHOR:" que las herramientas forenses pueden leer.
        # También modificar el trailer /Info si existe, o añadir bloque nuevo.
        anchor_comment = (
            f"\n% OMNI-ANCHOR-v3.0: {anchor_b64}\n"
            f"% ORIGIN: {origin_hash[:32]}\n"
            f"% TAD: {tad_ts}\n"
            f"% PDF-SHA256: {pdf_sha256[:32]}\n"
        ).encode("latin-1")

        # Insertar justo antes del último %%EOF
        eof_marker = b"%%EOF"
        last_eof   = pdf_bytes.rfind(eof_marker)
        if last_eof != -1:
            new_bytes = pdf_bytes[:last_eof] + anchor_comment + pdf_bytes[last_eof:]
        else:
            new_bytes = pdf_bytes + anchor_comment + eof_marker

        pdf_path.write_bytes(new_bytes)

        # Hash final del PDF anclado (incluye el ancla misma)
        anchored_sha256 = hashlib.sha256(new_bytes).hexdigest()
        anchor_payload["anchored_pdf_sha256"] = anchored_sha256

        return anchor_payload

    def verify_anchor(self, pdf_path: "Path | str") -> dict:
        """
        Lee y verifica el ancla de identidad de un PDF.
        Retorna el payload del ancla o un dict con 'valid': False si no existe.
        """
        from pathlib import Path as _Path
        import base64 as _b64

        pdf_path = _Path(pdf_path)
        if not pdf_path.exists():
            return {"valid": False, "error": "Archivo no encontrado"}

        content = pdf_path.read_bytes().decode("latin-1", errors="replace")
        marker  = "% OMNI-ANCHOR-v3.0: "
        idx     = content.find(marker)
        if idx == -1:
            return {"valid": False, "error": "Sin ancla de identidad"}

        try:
            b64_start = idx + len(marker)
            b64_end   = content.find("\n", b64_start)
            b64_data  = content[b64_start:b64_end].strip()
            decoded   = _b64.b64decode(b64_data).decode("utf-8")
            payload   = json.loads(decoded)
            payload["valid"] = True
            return payload
        except Exception as e:
            return {"valid": False, "error": str(e)}
