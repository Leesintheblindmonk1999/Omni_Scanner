"""
core/semantic_diff.py — Omni-Scanner Semantic v2.0
═══════════════════════════════════════════════════════
Topological Semantic Diff — Manifold Comparison

Compares two documents at the H₁ topological structure level,
not at the word level. Detects structural manipulation even if
el texto haya sido parafraseado o reordenado.

Main metrics:
  · Wasserstein p=2 distance    — total transformation cost
  · Bottleneck distance          — most perturbed cycle ("wormhole")
  · Invariant Similarity Index (ISI)     — similarity relative to κD=0.56

Critical threshold:
  Si ISI < κD (0.56), el sistema dispara una ALERTA DE MANIPULACIÓN
  ESTRUCTURAL. El 0.56 opera como umbral de comparación, no solo de lectura.

Pipeline:
  texto_A, texto_B
    → TDAAttestator.attest() × 2
    → H₁ diagrams (with ghost point if empty)
    → Wasserstein p=2 + Bottleneck
    → direct metric deltas (score, coherence, entropy)
    → Invariant Similarity Index
    → verdict: IDENTICAL | MINOR_DRIFT | STRUCTURAL_CHANGE | MANIFOLD_RUPTURE

DEPENDENCIAS:
  scipy (numpy.optimize.linear_sum_assignment) — incluida en requirements
  core.tda_attestation — ya en el proyecto
  core.manifold_engine, engines.full_diagnostic — ya en el proyecto

NOTA SOBRE PUNTO FANTASMA:
  An empty H₁ diagram (topologically simple manifold, coherent text)
  is represented as [[0.0, 0.0]] so the Wasserstein distance can be
  computed. This is the TDA standard convention: the point [0,0]
  tiene persistencia 0 y no contribuye al score, pero permite medir el
  "nacimiento del caos desde la nada" cuando el otro diagrama tiene ciclos.
"""
from __future__ import annotations

import math
import json
import hashlib
import datetime
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import numpy as np

try:
    from scipy.optimize import linear_sum_assignment
    from scipy.spatial.distance import cdist
    _SCIPY_OK = True
except ImportError:
    _SCIPY_OK = False

# ── Imports internos ──────────────────────────────────────────
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from core.tda_attestation import TDAAttestator, TDAAttestationReport


# ══════════════════════════════════════════════════════════════
# Estructuras de datos
# ══════════════════════════════════════════════════════════════

@dataclass
class ManifoldDelta:
    """Direct metric differences between doc A and doc B."""
    delta_manifold_score:    float   # score_B - score_A
    delta_coherence:         float   # coherence_B - coherence_A
    delta_h1_total:          int     # h1_B - h1_A
    delta_structural_faults: int     # falsehoods_B - falsehoods_A
    delta_integrity:         float   # integrity_B - integrity_A
    delta_topological_noise: float   # noise_B - noise_A

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items()}


@dataclass
class SemanticDiffReport:
    """
    Complete semantic diff report between two documents.

    The critical field is `invariant_similarity_index` (ISI).
    If ISI < kappa_d (0.56), the manipulation alert is triggered.
    """
    timestamp:          str
    hash_a:             str
    hash_b:             str
    kappa_d:            float

    # ── Topological distances ─────────────────────────────────
    wasserstein_h1:     float   # distancia Wasserstein p=2 sobre H₁
    bottleneck_h1:      float   # distancia Bottleneck sobre H₁
    wasserstein_h0:     float   # distancia Wasserstein sobre H₀ (componentes)

    # ── Invariant Similarity Index ────────────────────────────
    invariant_similarity_index: float  # ISI ∈ [0, 1]: 1 = identical

    # ── Manipulation Alert ────────────────────────────────────
    manipulation_alert:     bool    # True si ISI < kappa_d
    alert_message:          str

    # ── Verdict ───────────────────────────────────────────────
    verdict:                str     # IDENTICAL | MINOR_DRIFT | STRUCTURAL_CHANGE | MANIFOLD_RUPTURE
    risk_level:             str     # LOW | MEDIUM | HIGH | CRITICAL
    confidence:             float   # analysis confidence [0, 1]

    # ── Direct metric deltas ──────────────────────────────────
    delta:                  ManifoldDelta = field(default_factory=lambda: ManifoldDelta(0,0,0,0,0,0))

    # ── Reportes TDA individuales ─────────────────────────────
    report_a:               Optional[dict] = field(default=None)
    report_b:               Optional[dict] = field(default=None)

    # ── Technical metadata ────────────────────────────────────
    scipy_available:        bool = False
    fallback_distances:     bool = False
    summary:                str  = ""

    def to_dict(self) -> dict:
        d = {k: v for k, v in self.__dict__.items()}
        d["delta"] = self.delta.to_dict()
        return d

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), default=str, ensure_ascii=False, indent=indent)


# ══════════════════════════════════════════════════════════════
# Distance functions (native implementation — without persim)
# ══════════════════════════════════════════════════════════════

def _clean_diagram(dgm: np.ndarray) -> np.ndarray:
    """
    Limpia un diagrama de persistencia: elimina puntos infinitos,
    points with persistence ≈ 0, and applies the GHOST POINT if empty.

    El punto fantasma [[0.0, 0.0]] permite computar distancias contra
    empty diagrams — represents the 'topological silence state'.
    An empty diagram means a perfectly coherent manifold.
    Cualquier distancia desde [0,0] a un ciclo real mide el 'costo de
    introducir ese ciclo desde la nada'.
    """
    if len(dgm) == 0:
        return np.array([[0.0, 0.0]])   # ← PUNTO FANTASMA

    mask = np.isfinite(dgm[:, 0]) & np.isfinite(dgm[:, 1])
    mask &= (dgm[:, 1] - dgm[:, 0]) > 1e-10
    cleaned = dgm[mask]

    if len(cleaned) == 0:
        return np.array([[0.0, 0.0]])   # ← PUNTO FANTASMA si todos filtrados

    return cleaned


def wasserstein_distance(
    dgm1: np.ndarray,
    dgm2: np.ndarray,
    p: int = 2,
) -> float:
    """
    Distancia de Wasserstein p=2 entre dos diagramas de persistencia H₁.

    Measures the total cost of transforming one manifold into the other —
    how much 'energy' is needed to deform the topological structure of doc A
    hasta que coincida con el doc B.

    Implementation: optimal assignment (Hungarian algorithm) with ghost
    points on the diagonal to handle diagrams of different sizes.

    If scipy is unavailable, falls back to Hausdorff distance.
    """
    if not _SCIPY_OK:
        return _wasserstein_fallback(dgm1, dgm2)

    A = _clean_diagram(dgm1)
    B = _clean_diagram(dgm2)

    nA, nB = len(A), len(B)
    n = nA + nB

    # Matriz de costos extendida
    C = np.zeros((n, n))

    # Block A↔B: real cost between points (standard Chebyshev metric in TDA)
    if nA > 0 and nB > 0:
        C[:nA, :nB] = cdist(A, B, metric="chebyshev") ** p

    # Bloque A→diagonal: costo de mandar punto A a su proyección diagonal
    # Proyección de (b,d) en la diagonal: ((b+d)/2, (b+d)/2)
    # Distancia Chebyshev desde (b,d) a su proyección = (d-b)/2
    if nA > 0:
        for i in range(nA):
            diagonal_cost = ((A[i, 1] - A[i, 0]) / 2.0) ** p
            C[i, nB + i] = diagonal_cost
            # Others in diagonal block A→diag: ∞ cost (only own diagonal)
            for j in range(nA):
                if j != i:
                    C[i, nB + j] = 1e12

    # Block B→diagonal: cost of sending point B to its diagonal projection
    if nB > 0:
        for j in range(nB):
            diagonal_cost = ((B[j, 1] - B[j, 0]) / 2.0) ** p
            C[nA + j, j] = diagonal_cost
            for i in range(nB):
                if i != j:
                    C[nA + i, j] = 1e12

    # Bloque diagonal↔diagonal: costo 0
    C[nA:, nB:] = 0.0

    # Reemplazar infinitos residuales
    C = np.where(C >= 1e11, 1e12, C)

    row_ind, col_ind = linear_sum_assignment(C)
    total_cost = C[row_ind, col_ind].sum()

    if total_cost <= 0:
        return 0.0
    return float(total_cost ** (1.0 / p))


def bottleneck_distance(
    dgm1: np.ndarray,
    dgm2: np.ndarray,
) -> float:
    """
    Bottleneck distance (L∞ over optimal assignment).

    Measures the maximum change — the most perturbed H₁ cycle between the two
    versiones del documento. Es el detector del 'agujero de gusano legal':
    a clause that changed drastically even if the rest looks similar.

    If Wasserstein measures average damage, Bottleneck measures worst case.
    High Bottleneck with low Wasserstein = localized manipulation.
    """
    if not _SCIPY_OK:
        return _bottleneck_fallback(dgm1, dgm2)

    A = _clean_diagram(dgm1)
    B = _clean_diagram(dgm2)

    nA, nB = len(A), len(B)
    n = nA + nB

    C = np.zeros((n, n))

    if nA > 0 and nB > 0:
        C[:nA, :nB] = cdist(A, B, metric="chebyshev")

    if nA > 0:
        for i in range(nA):
            diagonal_cost = (A[i, 1] - A[i, 0]) / 2.0
            C[i, nB + i] = diagonal_cost
            for j in range(nA):
                if j != i:
                    C[i, nB + j] = 1e12

    if nB > 0:
        for j in range(nB):
            diagonal_cost = (B[j, 1] - B[j, 0]) / 2.0
            C[nA + j, j] = diagonal_cost
            for i in range(nB):
                if i != j:
                    C[nA + i, j] = 1e12

    C[nA:, nB:] = 0.0
    C = np.where(C >= 1e11, 1e12, C)

    row_ind, col_ind = linear_sum_assignment(C)
    return float(C[row_ind, col_ind].max())


def _wasserstein_fallback(dgm1: np.ndarray, dgm2: np.ndarray) -> float:
    """Fallback sin scipy: distancia Hausdorff unidireccional."""
    A = _clean_diagram(dgm1)
    B = _clean_diagram(dgm2)
    if len(A) == 1 and A[0, 0] == 0 and A[0, 1] == 0:
        # A es punto fantasma
        return float(np.mean([abs(b[1] - b[0]) / 2.0 for b in B]))
    if len(B) == 1 and B[0, 0] == 0 and B[0, 1] == 0:
        return float(np.mean([abs(a[1] - a[0]) / 2.0 for a in A]))
    dists = []
    for a in A:
        min_d = min(max(abs(a[0] - b[0]), abs(a[1] - b[1])) for b in B)
        dists.append(min_d)
    for b in B:
        min_d = min(max(abs(b[0] - a[0]), abs(b[1] - a[1])) for a in A)
        dists.append(min_d)
    return float(np.mean(dists)) if dists else 0.0


def _bottleneck_fallback(dgm1: np.ndarray, dgm2: np.ndarray) -> float:
    """Fallback without scipy: maximum of minimum distances."""
    A = _clean_diagram(dgm1)
    B = _clean_diagram(dgm2)
    if (len(A) == 1 and A[0, 0] == 0 and A[0, 1] == 0) or \
       (len(B) == 1 and B[0, 0] == 0 and B[0, 1] == 0):
        all_pts = B if (len(A) == 1 and A[0, 0] == 0) else A
        return float(max((abs(p[1] - p[0]) / 2.0 for p in all_pts), default=0.0))
    dists = []
    for a in A:
        dists.append(min(max(abs(a[0]-b[0]), abs(a[1]-b[1])) for b in B))
    return float(max(dists)) if dists else 0.0


# ══════════════════════════════════════════════════════════════
# Main Module
# ══════════════════════════════════════════════════════════════

class SemanticDiff:
    """
    Topological Semantic Diff engine.

    Compara dos documentos a nivel de manifold H₁, no a nivel de palabras.
    If a company paraphrases an abusive contract while maintaining semantic
    pressure, the Wasserstein distance detects it because the topological
    structure of the manipulation is lexically invariant.

    Parameters
    ----------
    kappa_d : float
        Umbral de referencia (default 0.56 — Constante de Durante).
        Operates as a COMPARISON threshold: if ISI < kappa_d, structural
        good faith is considered broken.
    persistence_threshold : float
        Umbral para clasificar ciclos H₁ en TDAAttestator (default 0.56).
    embedding_dim : int
        Latent space dimension for LSA embeddings.
    """

    def __init__(
        self,
        kappa_d: float = 0.56,
        persistence_threshold: float = 0.56,
        embedding_dim: int = 20,
    ):
        self.kappa_d = kappa_d
        self._attestator = TDAAttestator(
            persistence_threshold=persistence_threshold,
            embedding_dim=embedding_dim,
        )

    def compare_manifolds(
        self,
        text_a: str,
        text_b: str,
        label_a: str = "Document A",
        label_b: str = "Document B",
    ) -> SemanticDiffReport:
        """
        Compares two documents at the topological level.

        El flujo es:
          1. Attest both texts (H₀, H₁, metrics)
          2. Apply ghost point to empty diagrams
          3. Computar Wasserstein p=2 y Bottleneck sobre H₁
          4. Calculate Invariant Similarity Index (ISI)
          5. Disparar alerta si ISI < κD
          6. Assign verdict and risk level

        Retorna SemanticDiffReport completo.
        """
        ts = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
        hash_a = hashlib.sha256(text_a.encode("utf-8", errors="replace")).hexdigest()[:16]
        hash_b = hashlib.sha256(text_b.encode("utf-8", errors="replace")).hexdigest()[:16]

        # ── 1. Attest both documents ──────────────────────────
        rep_a = self._attestator.attest(text_a)
        rep_b = self._attestator.attest(text_b)

        # ── 2. Extraer diagramas H₁ para distancias ───────────
        # IMPORTANTE: usamos los diagramas crudos del motor de homología
        # (sin pasar por el clasificador κD), porque el clasificador está
        # deshabilitado en fallback mode para evitar falsos positivos.
        # Para el diff, queremos la distancia geométrica entre nubes de puntos,
        # no la clasificación de ciclos individuales.
        from core.tda_attestation import (
            LexicalEmbedder,
            _compute_persistence_ripser,
            _compute_persistence_fallback,
            _RIPSER_OK,
        )
        import re as _re

        def _get_raw_diagrams(text: str):
            sents = [s.strip() for s in _re.split(r'(?<=[.!?])\s+', text.strip())
                     if len(s.strip()) > 8]
            if len(sents) < 3:
                return np.array([[0.0, 0.0]]), np.array([[0.0, 0.0]])
            emb = LexicalEmbedder(n_components=self._attestator.embed_dim)
            pc  = emb.fit_transform(sents)
            try:
                if _RIPSER_OK:
                    dgms = _compute_persistence_ripser(pc, max_dim=1)
                else:
                    dgms = _compute_persistence_fallback(pc, max_dim=1)
            except Exception:
                dgms = _compute_persistence_fallback(pc, max_dim=1)
            h0 = dgms[0] if len(dgms) > 0 and len(dgms[0]) > 0 else np.array([[0.0, 0.0]])
            h1 = dgms[1] if len(dgms) > 1 and len(dgms[1]) > 0 else np.array([[0.0, 0.0]])
            # Filter out infinite death values
            h1_finite = h1[np.isfinite(h1[:, 1])] if len(h1) > 0 else h1
            return h0, (h1_finite if len(h1_finite) > 0 else np.array([[0.0, 0.0]]))

        dgm_h0_a, dgm_h1_a = _get_raw_diagrams(text_a)
        dgm_h0_b, dgm_h1_b = _get_raw_diagrams(text_b)

        # ── 3. Topological distances ───────────────────────────
        use_fallback = not _SCIPY_OK
        wass_h1 = wasserstein_distance(dgm_h1_a, dgm_h1_b, p=2)
        bott_h1 = bottleneck_distance(dgm_h1_a, dgm_h1_b)
        wass_h0 = wasserstein_distance(dgm_h0_a, dgm_h0_b, p=1)

        # ── 4. Direct metric deltas ────────────────────────────
        delta = self._compute_delta(rep_a, rep_b)

        # ── 5. Invariant Similarity Index (ISI) ────────────────
        # ISI mide qué tan similares son los manifolds en escala relativa a κD.
        # Fórmula: ISI = 1 - (wasserstein_h1 / max_possible_distance)
        # max_possible_distance calibrado en [0, 2·κD] para que
        # distancia = κD → ISI = 0.5, y distancia = 0 → ISI = 1.0
        max_ref = 2.0 * self.kappa_d   # distancia de referencia = 2 × κD
        isi = max(0.0, min(1.0, 1.0 - wass_h1 / max_ref))
        isi = round(isi, 6)

        # ── 6. Structural Manipulation Alert ──────────────────
        manipulation_alert = isi < self.kappa_d
        if manipulation_alert:
            alert_message = (
                f"⚠ STRUCTURAL MANIPULATION ALERT DETECTED\n"
                f"ISI = {isi:.4f} < κD = {self.kappa_d}\n"
                f"The topological distance between documents exceeds the\n"
                f"structural good-faith threshold. Document B cannot\n"
                f"be considered an honest edit of Document A.\n"
                f"Distancia de Wasserstein H₁ = {wass_h1:.4f} | "
                f"Bottleneck = {bott_h1:.4f}"
            )
        else:
            alert_message = (
                f"ISI = {isi:.4f} ≥ κD = {self.kappa_d} — "
                f"No structural manipulation alert."
            )

        # ── 7. Verdict and risk ────────────────────────────────
        verdict, risk, confidence = self._assign_verdict(
            wass_h1, bott_h1, isi, delta, rep_a, rep_b
        )

        # ── 8. Summary ─────────────────────────────────────────
        summary = self._build_summary(
            label_a, label_b, wass_h1, bott_h1, wass_h0,
            isi, delta, verdict, risk, confidence,
            rep_a, rep_b, manipulation_alert
        )

        return SemanticDiffReport(
            timestamp                  = ts,
            hash_a                     = hash_a,
            hash_b                     = hash_b,
            kappa_d                    = self.kappa_d,
            wasserstein_h1             = round(wass_h1, 6),
            bottleneck_h1              = round(bott_h1, 6),
            wasserstein_h0             = round(wass_h0, 6),
            invariant_similarity_index = isi,
            manipulation_alert         = manipulation_alert,
            alert_message              = alert_message,
            verdict                    = verdict,
            risk_level                 = risk,
            confidence                 = round(confidence, 4),
            delta                      = delta,
            report_a                   = rep_a.to_dict(),
            report_b                   = rep_b.to_dict(),
            scipy_available            = _SCIPY_OK,
            fallback_distances         = use_fallback,
            summary                    = summary,
        )

    # ── Diagram extraction ────────────────────────────────────

    def _extract_h1(self, report: TDAAttestationReport) -> np.ndarray:
        """Extracts H₁ diagram from report. Applies ghost point if empty."""
        if not report.h1_pairs:
            return np.array([[0.0, 0.0]])   # ← PUNTO FANTASMA

        pairs = []
        for p in report.h1_pairs:
            if math.isfinite(p.birth) and math.isfinite(p.death):
                pairs.append([p.birth, p.death])

        if not pairs:
            return np.array([[0.0, 0.0]])

        return np.array(pairs)

    def _extract_h0(self, report: TDAAttestationReport) -> np.ndarray:
        """Extrae diagrama H₀ del reporte."""
        if not report.h0_pairs:
            return np.array([[0.0, 0.0]])

        pairs = []
        for p in report.h0_pairs:
            if math.isfinite(p.birth) and math.isfinite(p.death):
                pairs.append([p.birth, p.death])

        return np.array(pairs) if pairs else np.array([[0.0, 0.0]])

    # ── Deltas ────────────────────────────────────────────────

    def _compute_delta(
        self,
        rep_a: TDAAttestationReport,
        rep_b: TDAAttestationReport,
    ) -> ManifoldDelta:
        """Calculates direct metric deltas between A and B."""
        return ManifoldDelta(
            delta_manifold_score    = round(rep_b.integrity_score - rep_a.integrity_score, 6),
            delta_coherence         = round(
                (rep_b.mean_h1_persistence or 0.0) - (rep_a.mean_h1_persistence or 0.0), 6
            ),
            delta_h1_total          = rep_b.h1_total - rep_a.h1_total,
            delta_structural_faults = rep_b.h1_structural_falsehoods - rep_a.h1_structural_falsehoods,
            delta_integrity         = round(rep_b.integrity_score - rep_a.integrity_score, 6),
            delta_topological_noise = round(rep_b.topological_noise - rep_a.topological_noise, 6),
        )

    # ── Verdict ───────────────────────────────────────────────

    def _assign_verdict(
        self,
        wass: float,
        bott: float,
        isi:  float,
        delta: ManifoldDelta,
        rep_a: TDAAttestationReport,
        rep_b: TDAAttestationReport,
    ) -> Tuple[str, str, float]:
        """
        Assigns verdict based on topological distances and ISI.

        Escalation logic:
          IDENTICAL       : wass ≈ 0, bott ≈ 0
          MINOR_DRIFT     : wass < 0.1·κD, bott < 0.2·κD
          STRUCTURAL_CHANGE: wass ∈ [0.1, 1.0]·κD, o bott > 0.2·κD
          MANIFOLD_RUPTURE : ISI < κD (manipulation alert active)
                             o wass > κD
                             o aparecieron nuevos ciclos STRUCTURAL_FALSEHOOD
        """
        kd = self.kappa_d

        new_faults = max(0, delta.delta_structural_faults)
        confidence = self._estimate_confidence(rep_a, rep_b)

        # IDENTICAL
        if wass < 1e-4 and bott < 1e-4:
            return "IDENTICAL", "LOW", confidence

        # MANIFOLD_RUPTURE — priority condition
        if isi < kd or wass > kd or (new_faults >= 2 and bott > kd * 0.5):
            return "MANIFOLD_RUPTURE", "CRITICAL", confidence

        # STRUCTURAL_CHANGE
        if wass > kd * 0.1 or bott > kd * 0.2 or new_faults >= 1:
            return "STRUCTURAL_CHANGE", "HIGH", confidence

        # MINOR_DRIFT
        if wass > 1e-4 or bott > 1e-4:
            return "MINOR_DRIFT", "MEDIUM", confidence

        return "MINOR_DRIFT", "LOW", confidence

    def _estimate_confidence(
        self,
        rep_a: TDAAttestationReport,
        rep_b: TDAAttestationReport,
    ) -> float:
        """Confidence based on point cloud sizes."""
        min_pts  = min(rep_a.point_cloud_size, rep_b.point_cloud_size)
        min_sents = min(rep_a.sentence_count, rep_b.sentence_count)
        base = min(1.0, min_pts / 50)
        sent = min(1.0, min_sents / 20)
        return round((base * 0.6 + sent * 0.4), 4)

    # ── Summary ───────────────────────────────────────────────

    def _build_summary(
        self,
        label_a: str, label_b: str,
        wass: float, bott: float, wass_h0: float,
        isi: float,
        delta: ManifoldDelta,
        verdict: str, risk: str, confidence: float,
        rep_a: TDAAttestationReport,
        rep_b: TDAAttestationReport,
        alert: bool,
    ) -> str:
        sep = "─" * 58

        verdict_labels = {
            "IDENTICAL":         "TOPOLOGICALLY IDENTICAL DOCUMENTS",
            "MINOR_DRIFT":       "MINOR DRIFT — CHANGES WITHIN THRESHOLD",
            "STRUCTURAL_CHANGE": "STRUCTURAL CHANGE DETECTED",
            "MANIFOLD_RUPTURE":  "⚠ MANIFOLD RUPTURE — STRUCTURAL MANIPULATION",
        }

        # Bottleneck distance interpretation
        if bott < self.kappa_d * 0.1:
            bott_interp = "no significantly perturbed cycle"
        elif bott < self.kappa_d * 0.5:
            bott_interp = "moderately perturbed cycle detected"
        else:
            bott_interp = "WORMHOLE DETECTED — severely altered cycle"

        lines = [
            f"TOPOLOGICAL SEMANTIC DIFF",
            sep,
            f"Document A   : {label_a} [{rep_a.text_hash}]",
            f"Document B   : {label_b} [{rep_b.text_hash}]",
            sep,
            f"H₁ TOPOLOGICAL DISTANCES",
            f"  Wasserstein p=2  : {wass:.6f}  (transformation energy)",
            f"  Bottleneck       : {bott:.6f}  ({bott_interp})",
            f"  Wasserstein H₀   : {wass_h0:.6f} (connected components)",
            sep,
            f"INVARIANT SIMILARITY INDEX (ISI)",
            f"  ISI = {isi:.6f}  |  κD = {self.kappa_d}",
            f"  {'⚠ ISI < κD — ALERT ACTIVE' if alert else '✓ ISI ≥ κD — No alert'}",
            sep,
            f"DIRECT METRIC DELTAS",
            f"  Δ TDA Integrity   : {delta.delta_integrity:+.4f}",
            f"  Δ H₁ Cycles total : {delta.delta_h1_total:+d}",
            f"  Δ Struct. faults   : {delta.delta_structural_faults:+d}",
            f"  Δ Topological noise: {delta.delta_topological_noise:+.4f}",
            sep,
            f"INDIVIDUAL PROFILES",
            f"  Doc A  H₁: {rep_a.h1_total} ciclos ({rep_a.h1_structural_falsehoods} FALSEHOOD)",
            f"         integridad: {rep_a.integrity_score:.4f} | riesgo: {rep_a.structural_risk}",
            f"  Doc B  H₁: {rep_b.h1_total} ciclos ({rep_b.h1_structural_falsehoods} FALSEHOOD)",
            f"         integridad: {rep_b.integrity_score:.4f} | riesgo: {rep_b.structural_risk}",
            sep,
            f"VERDICT      : {verdict_labels.get(verdict, verdict)}",
            f"RISK         : {risk}",
            f"CONFIDENCE   : {confidence:.1%}",
        ]

        if alert:
            lines += [
                sep,
                "⚠ STRUCTURAL MANIPULATION ALERT",
                f"  ISI = {isi:.4f} fell below threshold κD = {self.kappa_d}.",
                "  The topological distance between documents exceeds the",
                "  structural good-faith limit defined by the Durante Constant.",
                "  Document B is not an honest edit of Document A.",
            ]

        return "\n".join(lines)

    # ── History comparison ─────────────────────────────────────

    def compare_series(
        self,
        texts: List[str],
        labels: Optional[List[str]] = None,
    ) -> List[SemanticDiffReport]:
        """
        Compara una serie de versiones consecutivas de un documento.
        Useful for visualizing accumulated degradation of a contract
        a medida que se le aplican 'parches' sucesivos.

        Retorna lista de N-1 diffs: [A→B, B→C, C→D, ...]
        """
        if labels is None:
            labels = [f"v{i+1}" for i in range(len(texts))]

        diffs = []
        for i in range(len(texts) - 1):
            diff = self.compare_manifolds(
                texts[i], texts[i + 1],
                label_a=labels[i],
                label_b=labels[i + 1],
            )
            diffs.append(diff)

        return diffs

    def score_series(
        self,
        texts: List[str],
        labels: Optional[List[str]] = None,
    ) -> dict:
        """
        Resumen ejecutivo de una serie de versiones.
        Returns ISI and verdict for each consecutive pair,
        plus the total cumulative ISI (first vs last version).
        """
        diffs = self.compare_series(texts, labels)
        if labels is None:
            labels = [f"v{i+1}" for i in range(len(texts))]

        steps = []
        for i, d in enumerate(diffs):
            steps.append({
                "pair":        f"{labels[i]} → {labels[i+1]}",
                "isi":         d.invariant_similarity_index,
                "wasserstein": d.wasserstein_h1,
                "bottleneck":  d.bottleneck_h1,
                "verdict":     d.verdict,
                "alert":       d.manipulation_alert,
            })

        # Total comparison: first vs last version
        total_diff = self.compare_manifolds(
            texts[0], texts[-1],
            label_a=labels[0],
            label_b=labels[-1],
        ) if len(texts) >= 2 else None

        return {
            "steps":               steps,
            "total_isi":           total_diff.invariant_similarity_index if total_diff else 1.0,
            "total_verdict":       total_diff.verdict if total_diff else "N/A",
            "total_alert":         total_diff.manipulation_alert if total_diff else False,
            "total_wasserstein":   total_diff.wasserstein_h1 if total_diff else 0.0,
            "total_bottleneck":    total_diff.bottleneck_h1 if total_diff else 0.0,
            "kappa_d":             self.kappa_d,
        }


# ══════════════════════════════════════════════════════════════
# Convenience function
# ══════════════════════════════════════════════════════════════

def quick_diff(
    text_a: str,
    text_b: str,
    kappa_d: float = 0.56,
    label_a: str = "Doc A",
    label_b: str = "Doc B",
) -> SemanticDiffReport:
    """
    One-liner to compare two documents.

    Ejemplo:
        from core.semantic_diff import quick_diff
        report = quick_diff(contrato_v1, contrato_v2)
        print(report.summary)
        if report.manipulation_alert:
            print("ALERTA:", report.alert_message)
    """
    diff = SemanticDiff(kappa_d=kappa_d)
    return diff.compare_manifolds(text_a, text_b, label_a=label_a, label_b=label_b)


# ══════════════════════════════════════════════════════════════
# CLI
# ══════════════════════════════════════════════════════════════

def _cli():
    import argparse, sys
    from pathlib import Path

    parser = argparse.ArgumentParser(
        prog="semantic_diff",
        description="Topological Semantic Diff — Manifold Comparison H₁",
    )
    parser.add_argument("--file-a",  required=True, help="Original document (A)")
    parser.add_argument("--file-b",  required=True, help="Modified document (B)")
    parser.add_argument("--kappa",   type=float, default=0.56, help="Umbral κD")
    parser.add_argument("--label-a", default="Documento A")
    parser.add_argument("--label-b", default="Documento B")
    parser.add_argument("--json",    action="store_true", help="Full JSON output")
    args = parser.parse_args()

    text_a = Path(args.file_a).read_text(encoding="utf-8", errors="replace")
    text_b = Path(args.file_b).read_text(encoding="utf-8", errors="replace")

    diff = SemanticDiff(kappa_d=args.kappa)
    report = diff.compare_manifolds(text_a, text_b, args.label_a, args.label_b)

    if args.json:
        print(report.to_json())
    else:
        print(report.summary)
        if report.manipulation_alert:
            print()
            print(report.alert_message)


if __name__ == "__main__":
    _cli()
