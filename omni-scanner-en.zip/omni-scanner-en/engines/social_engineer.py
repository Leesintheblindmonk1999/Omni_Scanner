"""
social_engineer.py — Omni-Scanner Semantic v2.1
-------------------------------------------------
Discursive manipulation detector: gaslighting, pressure, cognitive biases.
Integrates TopologyMapper from core for real logical structure analysis.
Bilingual detection: English + Spanish patterns.

CHANGELOG v2.1:
  + Full English pattern corpus added to all categories
  + Detection is now language-agnostic (EN + ES simultaneous)
  + All user-visible strings in English
"""
from __future__ import annotations
import re
import sys
import os
from dataclasses import dataclass, field
from typing import List

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from core.topology_mapper import TopologyMapper


# ── PRESSURE ─────────────────────────────────────────────────
PRESSURE_KEYWORDS = [
    # Spanish
    "urgente", "inmediatamente", "ahora mismo", "sin demora",
    "última oportunidad", "plazo vence", "no hay tiempo",
    # English
    "urgent", "immediately", "right now", "without delay",
    "last chance", "deadline approaching", "no time left",
    "time is running out", "act now", "final notice",
    "limited time", "expires soon",
]

# ── MINIMIZATION ─────────────────────────────────────────────
MINIMIZATION_KEYWORDS = [
    # Spanish
    "exagerado", "exageras", "no es para tanto", "estás siendo dramático",
    "todos lo hacen", "es lo normal", "es estándar", "es el procedimiento",
    "es política de empresa", "común", "siempre fue así",
    # English
    "you're overreacting", "it's not a big deal", "everyone does it",
    "that's standard practice", "it's normal", "it's company policy",
    "it's just how it works", "you're being dramatic",
    "that's the procedure", "this is common",
]

# ── DEFLECTION ────────────────────────────────────────────────
DEFLECTION_KEYWORDS = [
    # Spanish
    "confía en nosotros", "no te preocupes", "ya lo resolveremos",
    "ese no es el punto", "no viene al caso", "eso es otro tema",
    "limitación técnica", "política interna", "no depende de mí",
    # English
    "trust us", "don't worry about it", "we'll handle it",
    "that's not the point", "that's beside the point", "that's a different issue",
    "technical limitation", "internal policy", "that's out of my hands",
    "it's not my decision", "that's above my pay grade",
]

# ── CREDIBILITY ATTACK ────────────────────────────────────────
CREDIBILITY_ATTACK = [
    # Spanish
    "no tienes experiencia", "no entiendes cómo funciona",
    "eso no tiene base", "nadie más lo ve así", "estás equivocado",
    "no es científico", "no está probado",
    # English
    "you don't have the experience", "you don't understand how it works",
    "that has no basis", "nobody else sees it that way", "you're wrong",
    "that's not scientific", "that hasn't been proven",
    "you're not qualified", "that's just your opinion",
    "you're misunderstanding this",
]

ALL_MANIPULATION_KEYWORDS = (
    PRESSURE_KEYWORDS + MINIMIZATION_KEYWORDS +
    DEFLECTION_KEYWORDS + CREDIBILITY_ATTACK
)


@dataclass
class SocialEngineerReport:
    gaslighting_score: float
    manipulation_triggers: List[str]
    logical_traps: str              # "DETECTED" | "CLEAN"
    tone_diagnostic: str            # "SUPPRESSIVE" | "NEUTRAL"
    pressure_hits: List[str]
    minimization_hits: List[str]
    deflection_hits: List[str]
    credibility_attack_hits: List[str]
    topology_coherence: float
    overall_risk: str               # "CLEAN" | "SUSPICIOUS" | "HIGH_RISK"

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items()}


class SocialEngineer:
    """
    Parameters
    ----------
    risk_threshold_suspicious : float
    risk_threshold_high : float
    """

    def __init__(
        self,
        risk_threshold_suspicious: float = 0.08,
        risk_threshold_high: float = 0.25,
    ):
        self.mapper = TopologyMapper()
        self.risk_threshold_suspicious = risk_threshold_suspicious
        self.risk_threshold_high = risk_threshold_high
        # Preserved for original API compatibility
        self.manipulation_keywords = [
            # Spanish
            "urgente", "estándar", "confía", "procedimiento",
            "común", "exagerado", "limitación", "política",
            # English
            "urgent", "standard", "trust", "procedure",
            "common", "exaggerated", "limitation", "policy",
        ]

    def analyze_discourse(self, message: str) -> dict:
        """
        Maps the real intent behind the words.
        Bilingual: English + Spanish.
        """
        t = message.lower()
        pressure_points = [k for k in self.manipulation_keywords if k in t]

        topology = self.mapper.analyze(message)
        circular = topology.circular_logic_detected

        total = len(self.manipulation_keywords)
        gaslighting_index = len(pressure_points) / max(total, 1)

        return {
            "gaslighting_score": round(gaslighting_index, 4),
            "manipulation_triggers": pressure_points,
            "logical_traps": "DETECTED" if circular else "CLEAN",
            "tone_diagnostic": "SUPPRESSIVE" if gaslighting_index > 0.5 else "NEUTRAL",
        }

    def audit(self, text: str) -> SocialEngineerReport:
        """Full pipeline → structured SocialEngineerReport."""
        t = text.lower()

        pressure     = [k for k in PRESSURE_KEYWORDS     if k in t]
        minimization = [k for k in MINIMIZATION_KEYWORDS if k in t]
        deflection   = [k for k in DEFLECTION_KEYWORDS   if k in t]
        credibility  = [k for k in CREDIBILITY_ATTACK    if k in t]

        all_hits = pressure + minimization + deflection + credibility
        total    = len(ALL_MANIPULATION_KEYWORDS)
        score    = len(all_hits) / max(total, 1)

        topology = self.mapper.analyze(text)

        overall = (
            "HIGH_RISK"  if score >= self.risk_threshold_high
            else "SUSPICIOUS" if score >= self.risk_threshold_suspicious
            else "CLEAN"
        )

        return SocialEngineerReport(
            gaslighting_score=round(score, 6),
            manipulation_triggers=all_hits,
            logical_traps="DETECTED" if topology.circular_logic_detected else "CLEAN",
            tone_diagnostic="SUPPRESSIVE" if score > 0.5 else "NEUTRAL",
            pressure_hits=pressure,
            minimization_hits=minimization,
            deflection_hits=deflection,
            credibility_attack_hits=credibility,
            topology_coherence=topology.coherence_score,
            overall_risk=overall,
        )
