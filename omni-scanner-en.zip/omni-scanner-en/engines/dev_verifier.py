"""
dev_verifier.py — Omni-Scanner Semantic v1.0
----------------------------------------------
Code auditing: logical plagiarism, backdoors, structural integrity.
Integra ManifoldEngine del core.

CHANGELOG vs original version:
  + audit_source_code(source_code, prior_art) preservada con firma original
  + CRITICAL FIX: detect_plagiarism_signature(str, str) crashed because
    the function expects numeric arrays, not strings.
    → Now converts code to AST node frequency vector.
  + FIX: correlation > 0.85 como bool comparado con float — ahora consistente
  + NUEVO: _code_to_vector() via tipos de nodos AST
  + NEW: _token_cosine() as complementary metric
  + NEW: detect_backdoors() — suspicious code patterns
  + NEW: DevVerifierReport dataclass for FullDiagnostic integration
"""
from __future__ import annotations
import ast
import hashlib
import re
import math
from collections import Counter
from dataclasses import dataclass, field
from typing import List, Union
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from core.manifold_engine import ManifoldEngine


# ------------------------------------------------------------------
# Backdoor / malicious code patterns
# ------------------------------------------------------------------
BACKDOOR_PATTERNS = [
    r"exec\s*\(",
    r"eval\s*\(",
    r"__import__\s*\(",
    r"subprocess\.(call|run|Popen)",
    r"os\.(system|popen)\s*\(",
    r"socket\.(connect|bind)\s*\(",
    r"base64\.(b64decode|decodebytes)",
    r"pickle\.(loads|load)\s*\(",
    r"marshal\.(loads|load)\s*\(",
    r"compile\s*\(.+exec",
]


@dataclass
class DevVerifierReport:
    plagiarism_risk: float          # [0, 100] porcentaje (API original)
    signature_detected: bool        # "0.56" marker in code (original API)
    status: str                     # API original
    code_hash: str                  # SHA256 (API original)
    token_similarity: float
    ast_similarity: float
    backdoor_hits: List[str]
    backdoor_risk: str              # "CLEAN" | "SUSPICIOUS" | "HIGH_RISK"

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items()}


class DevVerifier:
    """
    Parameters
    ----------
    plagiarism_threshold : float   Cosine threshold for marking logical plagiarism (default 0.85).
    signature_marker : str         Authorship marker to search in code.
    """

    def __init__(
        self,
        plagiarism_threshold: float = 0.85,
        signature_marker: str = "0.56",
    ):
        self.engine = ManifoldEngine()
        self.plagiarism_threshold = plagiarism_threshold
        self.signature_056 = signature_marker   # preservado como atributo original

    # ------------------------------------------------------------------
    # API ORIGINAL (preservada para compatibilidad)
    # ------------------------------------------------------------------

    def audit_source_code(self, source_code: str, your_prior_art: str = "") -> dict:
        """
        Analyzes source code for structural similarities.
        API original corregida.

        CRITICAL FIX: detect_plagiarism_signature expected numeric arrays.
        Ahora convierte ambos textos a vectores de tipos AST antes de comparar.
        """
        has_marker = self.signature_056 in source_code
        current_hash = hashlib.sha256(source_code.encode()).hexdigest()

        if your_prior_art:
            vec_candidate = self._code_to_ast_vector(source_code)
            vec_reference = self._code_to_ast_vector(your_prior_art)
            # Now we can call detect_plagiarism_signature with vectors
            is_plagiarism = self.engine.detect_plagiarism_signature(vec_candidate, vec_reference)
            correlation = self._cosine_similarity(
                Counter(zip(*[iter(vec_candidate)] * 1)),
                Counter(zip(*[iter(vec_reference)] * 1)),
            ) if vec_candidate and vec_reference else 0.0
        else:
            is_plagiarism = False
            correlation = 0.0

        status = "ALERT: PLAGIARISM DETECTED" if is_plagiarism else "INDEPENDENT CODE"
        if has_marker and not is_plagiarism:
            status = "UNAUTHORIZED DERIVATION"

        return {
            "plagiarism_risk": round(correlation * 100, 2),
            "signature_detected": has_marker,
            "status": status,
            "code_hash": current_hash,
        }

    # ------------------------------------------------------------------
    # API EXTENDIDA
    # ------------------------------------------------------------------

    def audit(self, source_code: str, reference_code: str = "") -> DevVerifierReport:
        """Pipeline completo → DevVerifierReport estructurado."""
        base = self.audit_source_code(source_code, reference_code)

        tok_sim = self._token_cosine(source_code, reference_code) if reference_code else 0.0
        ast_sim = self._ast_node_cosine(source_code, reference_code) if reference_code else 0.0
        combined = round(0.6 * tok_sim + 0.4 * ast_sim, 6)

        backdoor_hits = [
            p for p in BACKDOOR_PATTERNS
            if re.search(p, source_code, re.IGNORECASE)
        ]
        backdoor_risk = (
            "HIGH_RISK" if len(backdoor_hits) >= 3
            else "SUSPICIOUS" if len(backdoor_hits) >= 1
            else "CLEAN"
        )

        final_status = base["status"]
        if combined >= self.plagiarism_threshold:
            final_status = "ALERTA: PLAGIO DETECTADO"

        return DevVerifierReport(
            plagiarism_risk=round(combined * 100, 2),
            signature_detected=base["signature_detected"],
            status=final_status,
            code_hash=base["code_hash"],
            token_similarity=round(tok_sim, 6),
            ast_similarity=round(ast_sim, 6),
            backdoor_hits=backdoor_hits,
            backdoor_risk=backdoor_risk,
        )

    # ------------------------------------------------------------------
    # Helpers privados
    # ------------------------------------------------------------------

    def _code_to_ast_vector(self, code: str) -> list:
        """Converts code to list of AST node types (for ManifoldEngine)."""
        try:
            tree = ast.parse(code)
            node_types = [type(n).__name__ for n in ast.walk(tree)]
            # Encode as numeric vector (type index)
            vocab = sorted(set(node_types))
            idx = {t: i for i, t in enumerate(vocab)}
            return [float(idx[t]) for t in node_types]
        except SyntaxError:
            return [0.0]

    def _tokenize(self, code: str) -> list[str]:
        return re.findall(r"\b\w+\b", code)

    def _cosine_similarity(self, c1: Counter, c2: Counter) -> float:
        common = set(c1) & set(c2)
        dot = sum(c1[k] * c2[k] for k in common)
        n1 = math.sqrt(sum(v ** 2 for v in c1.values()))
        n2 = math.sqrt(sum(v ** 2 for v in c2.values()))
        return dot / max(n1 * n2, 1e-12)

    def _token_cosine(self, a: str, b: str) -> float:
        return self._cosine_similarity(Counter(self._tokenize(a)), Counter(self._tokenize(b)))

    def _ast_node_cosine(self, a: str, b: str) -> float:
        def get_node_counts(code):
            try:
                tree = ast.parse(code)
                return Counter(type(n).__name__ for n in ast.walk(tree))
            except SyntaxError:
                return Counter()
        return self._cosine_similarity(get_node_counts(a), get_node_counts(b))
