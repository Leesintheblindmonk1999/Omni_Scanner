"""
law_auditor.py — Omni-Scanner Semantic v2.1
---------------------------------------------
Contract auditing: detects abusive clauses, rights waivers,
high-vagueness language. Integrates EntropyAnalyzer from core.
Bilingual detection: English + Spanish patterns.

CHANGELOG v2.1:
  + Full English pattern corpus added to RED_FLAGS, TRAP_CLAUSES,
    AUTHORSHIP_CLAUSES, COERCION_PATTERNS
  + Detection is now language-agnostic (EN + ES simultaneous)
  + All user-visible strings in English
"""
from __future__ import annotations
import re
import sys
import os
from dataclasses import dataclass, field
from typing import List

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from core.entropy_analyzer import EntropyAnalyzer


# ── RED FLAGS ─────────────────────────────────────────────────
RED_FLAGS = [
    # Spanish
    r"propiedad\s+exclusiva",
    r"renuncia\s+irrevocable",
    r"derechos\s+de\s+autor\s+del\s+empleador",
    r"confidencialidad\s+perpetua",
    r"licencia\s+gratuita",
    r"usuario\s+final",
    r"cede?\s+(todos\s+los\s+derechos|la\s+totalidad)",
    r"sin\s+derecho\s+a\s+compensaci[oó]n",
    r"de\s+forma\s+exclusiva\s+y\s+(permanente|perpetua)",
    r"propiedad\s+intelectual.{0,50}cede?",
    # English
    r"exclusive\s+property",
    r"irrevocable\s+(waiver|assignment|transfer)",
    r"employer.{0,20}(owns|retains|holds)\s+all\s+(rights|ip|intellectual\s+property)",
    r"perpetual\s+confidentiality",
    r"royalty.free\s+(license|licence)",
    r"end\s+user",
    r"assigns?\s+(all|any)\s+(rights|title|interest)",
    r"without\s+(right\s+to\s+)?compensation",
    r"exclusive\s+and\s+(permanent|perpetual)",
    r"intellectual\s+property.{0,50}(assign|transfer|vest)",
    r"work\s+made\s+for\s+hire",
    r"all\s+inventions.{0,50}(belong|assigned?\s+to)",
]

# ── TRAP CLAUSES ─────────────────────────────────────────────
TRAP_CLAUSES = [
    # Spanish
    r"terminaci[oó]n\s+unilateral",
    r"modificar\s+unilateralmente",
    r"sin\s+previo\s+aviso",
    r"a\s+criterio\s+(exclusivo\s+)?de\s+la\s+(empresa|parte)",
    r"renunci[ao]\s+expresamente\s+a",
    r"no\s+hay\s+derecho\s+a\s+apelar",
    # English
    r"unilateral\s+termination",
    r"(modify|amend|change).{0,30}(unilaterally|at\s+(its|our|their)\s+sole\s+discretion)",
    r"without\s+(prior\s+)?notice",
    r"at\s+(the\s+)?(company|party|employer).{0,10}sole\s+discretion",
    r"expressly\s+waives?",
    r"no\s+right\s+to\s+appeal",
    r"sole\s+and\s+absolute\s+discretion",
    r"may\s+(terminate|cancel|suspend).{0,20}(at\s+any\s+time|immediately)",
    r"reserves?\s+the\s+right\s+to.{0,30}(without|at\s+any\s+time)",
]

# ── AUTHORSHIP CLAUSES ────────────────────────────────────────
AUTHORSHIP_CLAUSES = [
    # Spanish
    r"el\s+(autor|creador|inventor)\s+retiene",
    r"prior\s+art\s+(reconocido|declarado)",
    r"propiedad\s+intelectual\s+preexistente",
    r"derechos\s+morales\s+(del\s+autor|inalienables)",
    r"autoría\s+original\s+reconocida",
    # English
    r"author\s+retains",
    r"prior\s+art\s+(acknowledged|recognized|declared)",
    r"pre.?existing\s+intellectual\s+property",
    r"moral\s+rights\s+(of\s+the\s+author|inalienable)",
    r"original\s+authorship\s+recognized",
    r"inventor\s+(retains|keeps|holds)",
    r"pre.?existing\s+(ip|inventions|works)",
]

# ── COERCION PATTERNS ─────────────────────────────────────────
COERCION_PATTERNS = [
    # Spanish
    r"no\s+(tienes?|tiene)\s+opci[oó]n",
    r"nos\s+veremos\s+obligados",
    r"o\s+acepta\s+o",
    r"con\s+consecuencias\s+legales",
    r"sin\s+alternativa",
    # English
    r"(you\s+have\s+)?no\s+(other\s+)?option",
    r"we\s+(will\s+be|are)\s+forced\s+to",
    r"(take\s+it\s+or\s+leave\s+it|accept\s+or\s+else)",
    r"legal\s+(consequences|action\s+will\s+follow)",
    r"no\s+alternative",
    r"(must|shall)\s+comply\s+or",
    r"failure\s+to\s+(comply|accept).{0,30}(will\s+result|may\s+result)",
    r"non.compliance\s+will",
]


@dataclass
class LawAuditorReport:
    critical_findings: List[str]
    trap_clause_hits: List[str]
    coercion_hits: List[str]
    authorship_clauses_present: bool
    noise_level: float
    entropy_flag: str
    legal_risk_score: float
    verdict: str                    # "STABLE" | "URGENT REVIEW" | "HIGH RISK"

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items()}


class LawAuditor:
    """
    Parameters
    ----------
    risk_threshold : float   Threshold to escalate from REVIEW to HIGH RISK.
    """

    def __init__(self, risk_threshold: float = 0.15):
        self.entropy = EntropyAnalyzer()
        self.risk_threshold = risk_threshold
        # Preserved for original API compatibility
        self.red_flags = [
            # Spanish
            "propiedad exclusiva", "renuncia irrevocable",
            "derechos de autor del empleador", "confidencialidad perpetua",
            "90 días", "usuario final", "licencia gratuita",
            # English
            "exclusive property", "irrevocable waiver",
            "employer owns all rights", "perpetual confidentiality",
            "end user", "royalty-free license", "work made for hire",
        ]

    def scan_contract(self, text: str) -> dict:
        """
        Scans for legal vulnerabilities. Bilingual: EN + ES.
        """
        findings = []
        for flag in RED_FLAGS:
            try:
                if re.search(flag, text, re.IGNORECASE):
                    findings.append(f"RED ALERT: Risk clause detected → '{flag}'")
            except re.error:
                if flag.lower() in text.lower():
                    findings.append(f"RED ALERT: '{flag}'")

        e_report = self.entropy.analyze(text)
        noise_level = e_report.word_entropy

        authorship_present = any(
            re.search(p, text, re.IGNORECASE) for p in AUTHORSHIP_CLAUSES
        )
        origin_status = "RECOGNIZED" if authorship_present else "NOT SPECIFIED"

        verdict = (
            "URGENT REVIEW"
            if len(findings) > 0 or origin_status == "NOT SPECIFIED"
            else "STABLE"
        )

        return {
            "critical_findings": findings,
            "noise_level": round(noise_level, 4),
            "origin_recognition": origin_status,
            "verdict": verdict,
        }

    def audit(self, text: str) -> LawAuditorReport:
        """Full pipeline → structured LawAuditorReport."""
        base = self.scan_contract(text)
        t = text.lower()

        trap_hits     = [p for p in TRAP_CLAUSES      if re.search(p, t)]
        coercion_hits = [p for p in COERCION_PATTERNS if re.search(p, t)]
        authorship    = any(re.search(p, t, re.IGNORECASE) for p in AUTHORSHIP_CLAUSES)

        e_report      = self.entropy.analyze(text)
        total_checks  = len(RED_FLAGS) + len(TRAP_CLAUSES) + len(COERCION_PATTERNS)
        hits          = len(base["critical_findings"]) + len(trap_hits) + len(coercion_hits)
        risk          = hits / max(total_checks, 1)

        if risk >= self.risk_threshold * 2:
            verdict = "HIGH RISK"
        elif risk >= self.risk_threshold or len(base["critical_findings"]) > 0:
            verdict = "URGENT REVIEW"
        else:
            verdict = "STABLE"

        return LawAuditorReport(
            critical_findings=base["critical_findings"],
            trap_clause_hits=trap_hits,
            coercion_hits=coercion_hits,
            authorship_clauses_present=authorship,
            noise_level=base["noise_level"],
            entropy_flag=e_report.flag,
            legal_risk_score=round(risk, 6),
            verdict=verdict,
        )
