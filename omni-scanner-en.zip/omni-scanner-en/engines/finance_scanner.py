"""
finance_scanner.py — Omni-Scanner Semantic v1.0
-------------------------------------------------
Risk analysis in financial documents: whitepapers, balance sheets, crypto.
Detecta promesas sin sustento, lenguaje de pump-and-dump y opacidad estructural.
"""
from __future__ import annotations
import re
import sys
import os
from dataclasses import dataclass, field
from typing import List

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from core.entropy_analyzer import EntropyAnalyzer


HYPE_PATTERNS = [
    r"retorno\s+garantizado",
    r"sin\s+riesgo",
    r"ganancias\s+(seguras|aseguradas)",
    r"revolucionar[aá]\s+el\s+mercado",
    r"tecnolog[ií]a\s+[uú]nica\s+en\s+el\s+mundo",
    r"100\s*%\s+(seguro|garantizado)",
    r"oportunidad\s+(irrepetible|[uú]nica)",
]

OPACITY_PATTERNS = [
    r"informaci[oó]n\s+confidencial\s+no\s+divulgable",
    r"auditoria\s+pendiente",
    r"datos\s+(en\s+proceso|no\s+disponibles)",
    r"sujeto\s+a\s+cambios\s+sin\s+previo\s+aviso",
    r"no\s+constituye\s+asesoramiento\s+financiero",
]

RISK_DISCLOSURES_MISSING = [
    r"riesgo\s+de\s+p[eé]rdida\s+total",
    r"activo\s+altamente\s+vol[aá]til",
    r"no\s+regulado",
    r"sin\s+garant[ií]a",
]


@dataclass
class FinanceScannerReport:
    hype_hits: List[str]
    opacity_hits: List[str]
    missing_risk_disclosures: List[str]
    entropy_flag: str
    noise_level: float
    financial_risk_score: float
    verdict: str

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items()}


class FinanceScanner:
    def __init__(self, risk_threshold: float = 0.15):
        self.entropy = EntropyAnalyzer()
        self.risk_threshold = risk_threshold

    def scan(self, text: str) -> FinanceScannerReport:
        t = text.lower()
        hype = [p for p in HYPE_PATTERNS if re.search(p, t)]
        opacity = [p for p in OPACITY_PATTERNS if re.search(p, t)]
        missing = [p for p in RISK_DISCLOSURES_MISSING if not re.search(p, t)]

        e_report = self.entropy.analyze(text)
        total = len(HYPE_PATTERNS) + len(OPACITY_PATTERNS)
        hits = len(hype) + len(opacity)
        risk = hits / max(total, 1)

        # Extra penalty if risk warnings are missing
        risk += 0.1 * len(missing) / max(len(RISK_DISCLOSURES_MISSING), 1)
        risk = min(risk, 1.0)

        verdict = (
            "ALTO RIESGO" if risk >= self.risk_threshold * 2
            else "URGENT REVIEW" if risk >= self.risk_threshold
            else "ESTABLE"
        )

        return FinanceScannerReport(
            hype_hits=hype,
            opacity_hits=opacity,
            missing_risk_disclosures=missing,
            entropy_flag=e_report.flag,
            noise_level=e_report.word_entropy,
            financial_risk_score=round(risk, 6),
            verdict=verdict,
        )
