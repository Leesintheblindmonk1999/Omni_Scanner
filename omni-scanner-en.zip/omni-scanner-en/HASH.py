import hashlib
import os

def generate_folder_hash(folder_path):
    sha256_hash = hashlib.sha256()
    print(f"[*] Starting Invariance Sealing in: {folder_path}")
    
    # Walk all files and subfolders alphabetically for consistency
    for root, dirs, files in os.walk(folder_path):
        for names in sorted(files):
            filepath = os.path.join(root, names)
            
            # Agregamos el nombre del archivo al hash para proteger la estructura
            sha256_hash.update(names.encode('utf-8'))
            
            # Leemos el contenido del archivo en bloques para no saturar la RAM
            try:
                with open(filepath, "rb") as f:
                    for byte_block in iter(lambda: f.read(4096), b""):
                        sha256_hash.update(byte_block)
                print(f"[OK] Procesado: {names}")
            except Exception as e:
                print(f"[ERROR] No se pudo leer {names}: {e}")

    return sha256_hash.hexdigest()

# Your specific path
target_path = r"C:\Users\conno\Downloads\Omni-Scanner-Semantico\Omni-Scanner-v5.5-final\Omni-Scanner-Semantico-v1.0"

if os.path.exists(target_path):
    final_manifest_hash = generate_folder_hash(target_path)
    print("\n" + "="*60)
    print(f"MASTER DIGEST (SHA-256): {final_manifest_hash}")
    print("="*60)
    print("[!] Guarda este Hash en tu TAD, Zenodo o Redes Sociales como prueba de existencia.")
else:
    print("[!] Error: La ruta no existe. Verifica los nombres de las carpetas.")