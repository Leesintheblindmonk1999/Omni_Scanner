"""
reports/generators/genesis_certifier.py
─────────────────────────────────────────
Genesis Certifier — v5.6

Cambios v5.6:
  · Radar chart generated with matplotlib (without kaleido)
  · "κD Proximity Analysis" section with stability band
  · PDF funciona con solo: pip install fpdf2 matplotlib

Minimum dependencies:
    pip install fpdf2 matplotlib
"""
from __future__ import annotations

import hashlib
import datetime
import json
import io
import sys
import math
from pathlib import Path
from typing import Any

# ── Path ──────────────────────────────────────────────────────
_ROOT = Path(__file__).resolve().parent.parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

VAULT_DIR = _ROOT / "logs" / "evidence_vault"
VAULT_DIR.mkdir(parents=True, exist_ok=True)

# ── fpdf2 ─────────────────────────────────────────────────────
try:
    from fpdf import FPDF, XPos, YPos
    _FPDF_OK = True
except ImportError:
    _FPDF_OK = False

# ── matplotlib (para radar sin kaleido) ───────────────────────
try:
    import matplotlib
    matplotlib.use("Agg")          # backend sin pantalla
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches
    import numpy as np
    _MPL_OK = True
except ImportError:
    _MPL_OK = False

# ── Paleta Dark-Amber (RGB) ───────────────────────────────────
C_BG        = (0,   0,   0)
C_AMBER     = (255, 177, 0)
C_AMBER_DIM = (180, 120, 0)
C_WHITE     = (255, 255, 255)
C_RED       = (255, 45,  45)
C_GREEN     = (0,   220, 120)
C_PANEL     = (12,  12,  12)
C_BORDER    = (40,  30,  0)


class GenesisCertifier:
    """
    Generates cryptographically signed PDF audit certificates.
    El PDF se guarda en evidence_vault/ y su ruta se retorna.
    """

    def __init__(self, vault_dir: Path | None = None):
        self.vault_dir = vault_dir or VAULT_DIR

    # ── Helpers ────────────────────────────────────────────────

    @staticmethod
    def _sha256(text: str) -> str:
        return hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()

    @staticmethod
    def _sha256_bytes(data: bytes) -> str:
        return hashlib.sha256(data).hexdigest()

    @staticmethod
    def _ts() -> str:
        return datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"

    def _build_radar_png(self, report_dict: dict) -> bytes | None:
        """
        Radar Chart con matplotlib — sin kaleido, sin plotly.
        5 ejes: Coherencia Topológica, Estabilidad Fractal,
                Densidad Entrópica, Invarianza κD, Confianza.
        Exporta a PNG en memoria (io.BytesIO).
        """
        if not _MPL_OK:
            return None
        try:
            labels = [
                "Topological\nCoherence",
                "Estabilidad\nFractal",
                "Entropy\nDensity",
                f"Invarianza\nκD=0.56",
                "Confianza",
            ]
            N = len(labels)

            coherence   = float(report_dict.get("coherence_score", 0.0))
            domain_risk = float(report_dict.get("domain_risk", 0.0))
            manifold_sc = float(report_dict.get("manifold_score", 0.0))
            if math.isnan(manifold_sc): manifold_sc = 0.0
            confidence  = float(report_dict.get("confidence", 0.0))
            kd          = 0.56

            fractal_stab = max(0.0, 1.0 - domain_risk)
            entropy_dens = manifold_sc
            kd_prox      = max(0.0, 1.0 - abs(manifold_sc - kd) / kd)
            values       = [coherence, fractal_stab, entropy_dens, kd_prox, confidence]

            angles      = [n / float(N) * 2 * math.pi for n in range(N)]
            angles     += angles[:1]
            values_plot = values + values[:1]

            fig, ax = plt.subplots(figsize=(5, 5),
                                   subplot_kw=dict(polar=True),
                                   facecolor="#000000")
            ax.set_facecolor("#0D0D0D")
            ax.spines["polar"].set_color("#FFB100")
            ax.set_ylim(0, 1)
            ax.set_yticks([0.25, 0.5, 0.75, 1.0])
            ax.set_yticklabels(["0.25", "0.50", "0.75", "1.00"],
                               color="#806000", fontsize=6)
            ax.yaxis.grid(True, color="#FFB100", alpha=0.15, linewidth=0.6)
            ax.xaxis.grid(True, color="#FFB100", alpha=0.20, linewidth=0.6)
            ax.set_thetagrids(
                [a * 180 / math.pi for a in angles[:-1]],
                labels, fontsize=7.5, color="#FFB100", fontfamily="monospace",
            )

            # Banda de estabilidad κD ±0.11
            kd_lo = [max(0, kd - 0.11)] * len(angles)
            kd_hi = [min(1, kd + 0.11)] * len(angles)
            ax.fill_between(angles, kd_lo, kd_hi, alpha=0.10, color="#FFB100")
            ax.plot(angles, [kd] * len(angles),
                    color="#FFB100", linewidth=1, linestyle="--", alpha=0.40)

            verdict = report_dict.get("manifold_verdict", "")
            fill_color = "#FF2D2D" if verdict == "HIGH_RISK" else "#FFB100"
            ax.plot(angles, values_plot, color=fill_color, linewidth=2)
            ax.fill(angles, values_plot, color=fill_color, alpha=0.18)

            ax.set_title("RADAR DE INVARIANZA",
                         color="#FFB100", fontsize=9,
                         fontfamily="monospace", pad=18)
            fig.patch.set_facecolor("#000000")
            plt.tight_layout(pad=1.5)

            buf = io.BytesIO()
            fig.savefig(buf, format="png", dpi=130,
                        facecolor="#000000", bbox_inches="tight")
            plt.close(fig)
            buf.seek(0)
            return buf.read()
        except Exception:
            return None

    def _export_plotly_png(self, fig: Any) -> bytes | None:
        """Legacy: exports Plotly figure with kaleido if available."""
        if fig is None:
            return None
        try:
            return fig.to_image(format="png", width=700, height=380, scale=1.5)
        except Exception:
            return None

    # ── PDF builder ────────────────────────────────────────────

    def generate(
        self,
        report_dict: dict,
        raw_text: str,
        signed_report: dict,
        topology_fig: Any = None,
        input_type: str = "generic",
    ) -> Path:
        """
        Genera el certificado PDF y lo guarda en evidence_vault/.

        Parameters:
            report_dict   : FullDiagnosticReport.__dict__
            raw_text      : Texto original analizado
            signed_report : Resultado de MetadataOrigin.sign_report()
            topology_fig  : Figura Plotly 3D (opcional)
            input_type    : Document type

        Retorna:
            Path al archivo PDF generado.
        """
        if not _FPDF_OK:
            raise ImportError(
                "fpdf2 is not installed. Run: pip install fpdf2"
            )

        ts_now   = self._ts()
        ts_label = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
        input_sha = self._sha256(raw_text)
        cert_id   = f"GEN-{input_sha[:8].upper()}-{datetime.datetime.utcnow().strftime('%Y%m%d%H%M%S')}"

        # Extraer datos del reporte
        verdict       = report_dict.get("overall_verdict", "N/A")
        manifold_sc   = report_dict.get("manifold_score", 0.0)
        coherence     = report_dict.get("coherence_score", 0.0)
        domain_risk   = report_dict.get("domain_risk", 0.0)
        confidence    = report_dict.get("confidence", 0.0)
        manifold_verd = report_dict.get("manifold_verdict", "N/A")
        sov_verd      = report_dict.get("sovereignty_verdict", "N/A")
        raw_reports   = report_dict.get("raw_reports", {})
        domain_data   = raw_reports.get("domain", {})
        man_summary   = raw_reports.get("manifold_summary", "")

        auth          = signed_report.get("authorship", {})
        signed_by     = auth.get("signed_by", "OMNI-SCANNER SEMANTIC v2.0")
        protocol      = auth.get("protocol", "ANEXA Ultra v4.0")
        content_hash  = auth.get("content_hash", input_sha)
        genesis_hash  = auth.get("hash_genesis", input_sha)

        findings = domain_data.get("critical_findings", [])
        traps    = domain_data.get("trap_clause_hits", [])

        # ── Intentar generar radar matplotlib (sin kaleido) ──
        chart_png: bytes | None = self._build_radar_png(report_dict)
        # Fallback: si matplotlib falla, intentar plotly legacy
        if chart_png is None and topology_fig is not None:
            chart_png = self._export_plotly_png(topology_fig)

        # ── Construir PDF ─────────────────────────────────────
        pdf = FPDF()
        pdf.set_auto_page_break(auto=True, margin=18)
        pdf.add_page()

        # Fondo negro
        pdf.set_fill_color(*C_BG)
        pdf.rect(0, 0, 210, 297, style="F")

        # ── FRANJA SUPERIOR AMBER ─────────────────────────────
        pdf.set_fill_color(*C_AMBER)
        pdf.rect(0, 0, 210, 3, style="F")

        # ── HEADER ────────────────────────────────────────────
        pdf.set_y(8)
        pdf.set_font("Helvetica", "B", 14)
        pdf.set_text_color(*C_AMBER)
        pdf.cell(0, 8, "OMNI-SCANNER SEMANTIC v2.0", align="C",
                 new_x=XPos.LMARGIN, new_y=YPos.NEXT)

        pdf.set_font("Helvetica", "", 7)
        pdf.set_text_color(*C_AMBER_DIM)
        pdf.cell(0, 5,
                 "GENESIS CERTIFICATE · INFORMATION PHYSICS · PROTOCOL ANEXA ULTRA v4.0",
                 align="C", new_x=XPos.LMARGIN, new_y=YPos.NEXT)

        # Dividing line
        pdf.set_draw_color(*C_AMBER)
        pdf.set_line_width(0.4)
        pdf.line(14, pdf.get_y() + 2, 196, pdf.get_y() + 2)
        pdf.ln(5)

        # ── CERT ID y TIMESTAMP ───────────────────────────────
        self._section_header(pdf, "CERTIFICATE IDENTIFICATION")
        self._kv(pdf, "Cert-ID",     cert_id)
        self._kv(pdf, "Timestamp",   ts_label)
        self._kv(pdf, "Tipo",        input_type.upper())
        self._kv(pdf, "Protocolo",   protocol)
        pdf.ln(3)

        # ── VERDICT ───────────────────────────────────────────
        self._section_header(pdf, "AUDIT VERDICT")
        verdict_color = (
            C_RED   if verdict == "HIGH_RISK" else
            C_AMBER if verdict == "REVIEW"    else
            C_GREEN
        )
        pdf.set_font("Helvetica", "B", 18)
        pdf.set_text_color(*verdict_color)
        v_icon = {"HIGH_RISK": "⚠ HIGH RISK", "REVIEW": "⚡ REVIEW", "CLEAR": "✓ CLEAR"}.get(verdict, verdict)
        pdf.cell(0, 10, v_icon, align="C", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        pdf.ln(2)

        # ── METRICS ───────────────────────────────────────────
        self._section_header(pdf, "INVARIANCE METRICS")
        pdf.set_font("Courier", "", 8)
        pdf.set_text_color(*C_AMBER_DIM)

        metrics = [
            ("κD Constante de Estabilidad", "0.56",                         "INVARIANTE"),
            ("ManifoldScore",               f"{manifold_sc:.6f}",            manifold_verd),
            ("Topological Coherence",       f"{coherence:.6f}",              ""),
            ("Riesgo de Dominio",           f"{domain_risk:.6f}",            ""),
            ("Analysis Confidence",         f"{confidence:.1%}",             ""),
            ("Semantic Sovereignty",        sov_verd,                        ""),
        ]
        for label, val, note in metrics:
            self._kv(pdf, label, val, note=note)
        pdf.ln(3)

        # ── CRYPTOGRAPHIC SIGNATURE ──────────────────────────
        self._section_header(pdf, "AUTHORSHIP CRYPTOGRAPHIC SIGNATURE")
        self._kv(pdf, "Signed by",      signed_by)
        self._kv(pdf, "SHA-256 Input",  input_sha)
        self._kv(pdf, "Content Hash",   content_hash)
        self._kv(pdf, "Genesis Hash",   genesis_hash)
        self._kv(pdf, "NIST/TAD Node",  f"κD=0.56 · OMNI-SCANNER · {cert_id}")
        pdf.ln(3)

        # ── CRITICAL FINDINGS ────────────────────────────────
        if findings or traps:
            self._section_header(pdf, "CRITICAL FINDINGS")
            import re as _re
            def _clean(s: str) -> str:
                return _re.sub(r'\\s\+|\\b|\\s\*|\(\?i\)', ' ', str(s)).strip()

            if findings:
                pdf.set_font("Helvetica", "B", 7)
                pdf.set_text_color(*C_RED)
                pdf.cell(0, 5, "ALERTAS ROJAS:", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
                pdf.set_font("Courier", "", 7)
                for i, f in enumerate(findings[:10], 1):
                    pdf.set_text_color(*C_RED)
                    safe = _clean(f)[:100]
                    pdf.cell(6, 4.5, f"{i}.", new_x=XPos.RIGHT, new_y=YPos.LAST)
                    pdf.set_text_color(*C_AMBER_DIM)
                    pdf.multi_cell(0, 4.5, safe)

            if traps:
                pdf.ln(1)
                pdf.set_font("Helvetica", "B", 7)
                pdf.set_text_color(255, 100, 0)
                pdf.cell(0, 5, "TRAP CLAUSES:", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
                pdf.set_font("Courier", "", 7)
                for t in traps[:10]:
                    pdf.set_text_color(*C_AMBER_DIM)
                    pdf.cell(0, 4.5, f"  · {_clean(t)[:100]}",
                             new_x=XPos.LMARGIN, new_y=YPos.NEXT)
            pdf.ln(3)

        # ── RADAR CHART ───────────────────────────────────────
        if chart_png:
            self._section_header(pdf, "RADAR DE INVARIANZA — 5 DIMENSIONES")
            # Insertar PNG desde BytesIO — sin archivo temporal
            chart_buf = io.BytesIO(chart_png)
            remaining = 297 - pdf.get_y() - 20
            img_h = min(75, max(45, remaining))
            pdf.image(chart_buf, x=30, w=150, h=img_h)
            pdf.ln(3)
        else:
            self._section_header(pdf, "MANIFOLD + ENTROPY SUMMARY")
            pdf.set_font("Courier", "", 7)
            pdf.set_text_color(*C_AMBER_DIM)
            for line in (man_summary or "Sin datos").split("\n")[:12]:
                if line.strip():
                    pdf.cell(0, 4, line[:95], new_x=XPos.LMARGIN, new_y=YPos.NEXT)
            pdf.ln(3)

        # ── κD PROXIMITY ANALYSIS ─────────────────────────────
        self._section_header(pdf, "κD = 0.56 PROXIMITY ANALYSIS")
        kd_ref   = 0.56
        ms_clean = manifold_sc if not (manifold_sc != manifold_sc) else 0.0
        kd_delta = abs(ms_clean - kd_ref)
        kd_pct   = kd_delta / kd_ref * 100

        if kd_delta <= 0.05:
            kd_status = "ESTABILIDAD SOBERANA"
            kd_color  = C_GREEN
        elif kd_delta <= 0.15:
            kd_status = "DEGRADATION DETECTED"
            kd_color  = C_AMBER
        else:
            kd_status = "COLAPSO DEL MANIFOLD"
            kd_color  = C_RED

        self._kv(pdf, "κD referencia",    "0.56",              note="INVARIANTE")
        self._kv(pdf, "ManifoldScore",    f"{ms_clean:.6f}")
        self._kv(pdf, "Δ proximidad",     f"{kd_delta:.6f}  ({kd_pct:.1f}%)")

        pdf.set_font("Helvetica", "B", 8)
        pdf.set_text_color(*kd_color)
        pdf.set_x(14)
        pdf.cell(0, 6, f"  ESTADO: {kd_status}", new_x=XPos.LMARGIN, new_y=YPos.NEXT)

        # Barra visual de proximidad (100 chars = rango 0→1.12)
        bar_width   = 60
        bar_filled  = int(min(ms_clean, 1.0) * bar_width)
        kd_pos      = int(kd_ref * bar_width)
        bar_chars   = list("░" * bar_width)
        for i in range(bar_filled):
            bar_chars[i] = "█"
        if 0 <= kd_pos < bar_width:
            bar_chars[kd_pos] = "◆"
        bar_str = "".join(bar_chars)

        pdf.set_font("Courier", "", 6.5)
        pdf.set_text_color(*C_AMBER_DIM)
        pdf.set_x(14)
        pdf.cell(0, 5, f"  [0.0  {bar_str}  1.0]  ◆=κD",
                 new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        pdf.ln(4)

        # ── SOVEREIGNTY DECLARATION ───────────────────────────
        pdf.add_page()
        pdf.set_fill_color(*C_BG)
        pdf.rect(0, 0, 210, 297, style="F")
        pdf.set_y(10)

        self._section_header(pdf, "ORIGIN NODE AUTHORSHIP DECLARATION")
        pdf.set_font("Helvetica", "", 8)
        pdf.set_text_color(*C_AMBER_DIM)
        declaration = (
            f"El presente certificado acredita que el documento analizado fue procesado "
            f"by the OMNI-SCANNER SEMANTIC v2.0 system under protocol ANEXA Ultra v4.0, "
            f"in compliance with the invariance standards of the Durante Constant κD = 0.56. "
            f"\n\n"
            f"The analysis was executed on {ts_label}. The SHA-256 hash of the input text "
            f"({input_sha[:20]}...) garantiza la inmutabilidad de la evidencia. "
            f"\n\n"
            f"This certificate is valid as audit evidence under international "
            f"propiedad intelectual computacional vigentes (TAD/NIST Framework). "
            f"The Origin Node is registered in the Evidence Vault with the "
            f"identificador {cert_id}."
        )
        pdf.set_x(14)
        pdf.multi_cell(182, 5.5, declaration)
        pdf.ln(5)

        # ── RAW JSON (extracto) ───────────────────────────────
        self._section_header(pdf, "JSON REPORT EXTRACT (SEALED)")
        summary_dict = {
            "cert_id":          cert_id,
            "timestamp":        ts_now,
            "overall_verdict":  verdict,
            "manifold_score":   round(manifold_sc, 6) if manifold_sc == manifold_sc else None,
            "coherence_score":  round(coherence, 6),
            "domain_risk":      round(domain_risk, 6),
            "confidence":       round(confidence, 6),
            "input_sha256":     input_sha,
            "genesis_hash":     genesis_hash,
            "signed_by":        signed_by,
            "critical_count":   len(findings),
            "trap_count":       len(traps),
        }
        pdf.set_font("Courier", "", 6.5)
        pdf.set_text_color(*C_AMBER_DIM)
        json_str = json.dumps(summary_dict, indent=2, ensure_ascii=False)
        for line in json_str.split("\n")[:30]:
            pdf.cell(0, 3.8, line[:100], new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        pdf.ln(5)

        # ── FRANJA INFERIOR + HASH DEL PDF ────────────────────
        # Generar el PDF sin hash final primero para calcular su propio hash
        pdf_bytes_temp = pdf.output()
        pdf_self_hash  = self._sha256_bytes(bytes(pdf_bytes_temp))

        # Footer
        pdf.set_y(-25)
        pdf.set_draw_color(*C_AMBER)
        pdf.line(14, pdf.get_y(), 196, pdf.get_y())
        pdf.ln(2)
        pdf.set_font("Courier", "", 6)
        pdf.set_text_color(80, 60, 0)
        pdf.cell(0, 4,
                 f"PDF-SHA256: {pdf_self_hash[:32]}... | {cert_id} | {ts_label}",
                 align="C", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        pdf.set_fill_color(*C_AMBER)
        pdf.rect(0, 294, 210, 3, style="F")

        # ── Guardar en vault ──────────────────────────────────
        filename   = f"{cert_id}.pdf"
        output_path = self.vault_dir / filename
        pdf.output(str(output_path))

        # Guardar manifest JSON del certificado
        manifest = {
            "cert_id":          cert_id,
            "pdf_file":         filename,
            "timestamp":        ts_now,
            "input_sha256":     input_sha,
            "pdf_sha256":       pdf_self_hash,
            "verdict":          verdict,
            "signed_by":        signed_by,
            "genesis_hash":     genesis_hash,
        }
        manifest_path = self.vault_dir / f"{cert_id}.manifest.json"
        manifest_path.write_text(
            json.dumps(manifest, indent=2, ensure_ascii=False),
            encoding="utf-8"
        )

        return output_path

    # ── Helpers de formato PDF ─────────────────────────────────

    def _section_header(self, pdf: "FPDF", title: str) -> None:
        pdf.set_fill_color(*C_BORDER)
        pdf.set_text_color(*C_AMBER)
        pdf.set_font("Helvetica", "B", 8)
        pdf.set_x(14)
        pdf.cell(182, 6, f"  {title}", fill=True,
                 new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        pdf.ln(1)

    def _kv(self, pdf: "FPDF", key: str, value: str, note: str = "") -> None:
        pdf.set_font("Courier", "", 7.5)
        pdf.set_x(14)
        # Key
        pdf.set_text_color(*C_AMBER_DIM)
        pdf.cell(55, 5, f"{key}:", new_x=XPos.RIGHT, new_y=YPos.LAST)
        # Value
        pdf.set_text_color(*C_AMBER)
        val_text = str(value)[:80]
        pdf.cell(115, 5, val_text, new_x=XPos.RIGHT, new_y=YPos.LAST)
        # Note
        if note:
            pdf.set_text_color(0, 180, 100)
            pdf.set_font("Helvetica", "I", 6.5)
            pdf.cell(0, 5, f" [{note}]", new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        else:
            pdf.ln(5)
