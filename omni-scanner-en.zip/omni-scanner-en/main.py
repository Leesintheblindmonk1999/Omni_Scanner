#!/usr/bin/env python3
"""
main.py — Omni-Scanner Semantic v5.5 — Dual Audit Interface
────────────────────────────────────────────────────────────────────
Audit Lens Selection:
  1. [MACHINE NODE] — Salud del Manifold + Override-Gaslighting + Shadow-Code
  2. [HUMAN NODE]   — Contract/NDA analysis + Delay Tactics
  3. [FULL SCAN]    — Pipeline completo unificado

Uso:
  python main.py                          → interactive menu
  python main.py --lens machine           → lente MACHINE
  python main.py --lens human             → lente HUMAN
  python main.py --lens full              → pipeline completo
  python main.py --file doc.txt --lens human --sign
"""
from __future__ import annotations
import argparse, json, os, sys, time, datetime
from pathlib import Path

def _load_env(env_path=".env"):
    p = Path(env_path)
    if not p.exists(): return
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line: continue
        key, _, val = line.partition("=")
        os.environ.setdefault(key.strip(), val.strip())
_load_env()

try:
    from colorama import init as _ci, Fore, Style
    _ci(autoreset=True); _HAS_COLOR = True
except ImportError:
    _HAS_COLOR = False
    class Fore:
        RED=YELLOW=GREEN=CYAN=WHITE=MAGENTA=""
    class Style:
        BRIGHT=RESET_ALL=DIM=""

def _c(text, color="", bright=False):
    if not _HAS_COLOR: return text
    b = Style.BRIGHT if bright else ""
    return f"{b}{color}{text}{Style.RESET_ALL}"

from engines.full_diagnostic import FullDiagnostic
from engines.law_auditor import LawAuditor
from utils.text_cleaner import TextCleaner
from utils.api_connector import ApiConnector
from protocols.metadata_origin import MetadataOrigin
from protocols import CONFIG
from logs.forensic_ledger import append_entry as ledger_append, entry_count as ledger_count
from interface.modules.override_gaslighting import OverrideGaslightingDetector
from interface.modules.delay_tactics import DelayTacticsDetector
from interface.modules.shadow_code import ShadowCodeDetector
from interface.modules.ghost_audit import GhostAuditor

K_D        = CONFIG.stability_constant if CONFIG else 0.56
SIGNER     = MetadataOrigin()
CLEANER    = TextCleaner()
DIAGNOSTIC = FullDiagnostic(stability_threshold=K_D)
CONNECTOR  = ApiConnector(base_dir=".")
OG_DETECT  = OverrideGaslightingDetector()
DT_DETECT  = DelayTacticsDetector()
SD_DETECT  = ShadowCodeDetector()
GHOST      = GhostAuditor()
LAW        = LawAuditor()

SEP  = "─" * 66
SEP2 = "═" * 66

def _banner():
    print()
    print(_c(SEP2, Fore.YELLOW, True))
    print(_c("  ⬡  OMNI-SCANNER SEMANTIC v2.0", Fore.YELLOW, True))
    print(_c("     SEMANTIC AUDIT · INFORMATION PHYSICS", Fore.YELLOW))
    print(_c(f"     κD = {K_D}  ·  PROTOCOLO ANEXA ULTRA v4.0", Fore.YELLOW))
    print(_c(SEP2, Fore.YELLOW, True)); print()

def _section(title, color=Fore.CYAN):
    print(); print(_c(f"  ▸ {title}", color, True)); print(_c(SEP, color))

def _kv(key, value, color=Fore.WHITE):
    print(f"  {_c(key+':', Fore.YELLOW)}  {_c(str(value), color)}")

def _bar(score, width=28, risk=False):
    filled = int(max(0.0, min(1.0, score)) * width)
    bar = "█"*filled + "░"*(width-filled)
    col = Fore.RED if risk else (Fore.YELLOW if score < 0.5 else Fore.GREEN)
    return _c(f"[{bar}]", col) + f" {score:.4f}"

def _read_input():
    print(_c("  (Paste text. Single 'END' line to finish)", Fore.YELLOW+Style.DIM))
    lines = []
    try:
        while True:
            line = sys.stdin.readline()
            if not line or line.strip().upper() == "END": break
            lines.append(line)
    except (KeyboardInterrupt, EOFError): pass
    return "".join(lines)

def _load_file(path):
    try: return Path(path).read_text(encoding="utf-8")
    except FileNotFoundError:
        print(_c(f"[ERROR] Archivo no encontrado: {path}", Fore.RED, True)); sys.exit(1)

def _select_lens():
    print(_c("  AUDIT LENS SELECTION", Fore.CYAN, True)); print()
    print(f"  {_c('1', Fore.YELLOW, True)}  {_c('[MACHINE NODE]', Fore.CYAN, True)}")
    print(f"     Manifold · Override-Gaslighting · Shadow-Code")
    print(f"     {_c('→ Code, systems, technical documents', Style.DIM)}")
    print()
    print(f"  {_c('2', Fore.YELLOW, True)}  {_c('[HUMAN NODE]', Fore.GREEN, True)}")
    print(f"     Contracts/NDAs · Abusive clauses · Delay Tactics")
    print(f"     {_c('→ Correos, contratos, comunicaciones corporativas', Style.DIM)}")
    print()
    print(f"  {_c('3', Fore.YELLOW, True)}  {_c('[FULL SCAN]', Fore.MAGENTA, True)}")
    print(f"     Full pipeline — all modules"); print()
    while True:
        c = input(_c("  Selection [1/2/3]: ", Fore.YELLOW, True)).strip()
        if c in ("1","machine"): return "machine"
        if c in ("2","human"):   return "human"
        if c in ("3","full",""):  return "full"
        print(_c("  → Ingrese 1, 2 o 3.", Fore.RED))

# ── MACHINE NODE ──────────────────────────────────────────────

def run_machine_node(raw_text, args):
    _section("MACHINE NODE — MANIFOLD + GASLIGHTING + AUTHORSHIP", Fore.CYAN)
    clean = CLEANER.clean_for_analysis(raw_text)

    print(_c("  [1/4] Manifold analysis...", Fore.CYAN))
    t0 = time.perf_counter()
    report = DIAGNOSTIC.run(clean, input_type=args.type,
                            reference_code=getattr(args, "_ref_content", ""))
    ms_val = report.manifold_score
    ms_ok  = ms_val not in (-1.0,) and ms_val == ms_val
    ms_str = f"{ms_val:.6f}" if ms_ok else "INSUF."
    elapsed = (time.perf_counter() - t0) * 1000
    _kv("ManifoldScore",    f"{ms_str}  [{report.manifold_verdict}]",
        Fore.RED if report.manifold_verdict == "HIGH_RISK" else Fore.GREEN)
    _kv("Coherencia",       f"{report.coherence_score:.6f}")
    _kv("κD invarianza",    f"{K_D}")
    _kv("Analysis latency",f"{elapsed:.1f} ms")
    _kv("Verdict",          report.overall_verdict,
        Fore.RED if report.overall_verdict == "HIGH_RISK" else
        Fore.YELLOW if report.overall_verdict == "REVIEW" else Fore.GREEN)

    print(_c("\n  [2/4] Override-Gaslighting...", Fore.CYAN))
    og = OG_DETECT.analyze(raw_text)
    _kv("Override score", f"{og.overall_score:.4f}")
    _kv("Verdict",        og.verdict,
        Fore.RED if "ACTIVA" in og.verdict else
        Fore.YELLOW if "SOSPECHOSOS" in og.verdict else Fore.GREEN)
    for cat, hits in list(og.hits_by_category.items())[:3]:
        print(f"    {_c('▸ '+cat, Fore.YELLOW)}: {len(hits)} hit(s)")
        for h in hits[:1]: print(_c(f"      {h[:80]}", Fore.RED+Style.DIM))

    print(_c("\n  [3/4] Shadow-Code detector...", Fore.CYAN))
    sd = SD_DETECT.analyze(raw_text)
    _kv("Human Score",       f"{sd.human_score:.4f}",
        Fore.GREEN if sd.human_score > 0.6 else
        Fore.RED if sd.human_score < 0.35 else Fore.YELLOW)
    _kv("Fractal Roughness", f"{sd.fractal_roughness:.4f}")
    _kv("Verdict",           sd.verdict,
        Fore.RED if "PLAGIO" in sd.verdict or "IA" == sd.verdict else Fore.GREEN)

    print(_c("\n  [4/4] Ghost Audit...", Fore.CYAN))
    ga = GHOST.analyze(raw_text)
    _kv("Semantic score", f"{ga.overall_score:.4f}")
    _kv("Nivel",          ga.alert_level,
        Fore.RED if "CRITICAL" in ga.alert_level else
        Fore.YELLOW if ga.alert_level != "SALUDABLE" else Fore.GREEN)

    _section("RADAR DE INVARIANZA (κD=0.56)", Fore.YELLOW)
    invarianza_score = min(ms_val if ms_ok and ms_val > 0 else 0.5, 1.0)
    axes = {
        "Invarianza (κD)":        invarianza_score,
        "Coherencia estructural": report.coherence_score,
        "Linguistic transp.":  max(0.0, 1.0 - og.overall_score),
        "Legal symmetry":         max(0.0, 1.0 - report.domain_risk),
    }
    for axis, val in axes.items():
        print(f"  {axis:<28} {_bar(val, 25, val < 0.35)}")

    return {"lens":"machine","report":report,"og":og,"shadow":sd,"ghost":ga}

# ── HUMAN NODE ────────────────────────────────────────────────

def run_human_node(raw_text, args):
    _section("HUMAN NODE — LEGAL + DELAY TACTICS + GASLIGHTING", Fore.GREEN)
    clean = CLEANER.clean_for_analysis(raw_text)

    print(_c("  [1/3] Contract/NDA analysis...", Fore.GREEN))
    law = LAW.audit(clean)
    _kv("Riesgo legal",  f"{law.legal_risk_score:.4f}",
        Fore.RED if law.legal_risk_score > 0.3 else Fore.GREEN)
    _kv("Verdict",       law.verdict,
        Fore.RED if "RIESGO" in law.verdict else
        Fore.YELLOW if "REVIEW" in law.verdict else Fore.GREEN)
    _kv("Prior authorship","RECOGNIZED" if law.authorship_clauses_present else "NOT SPECIFIED",
        Fore.GREEN if law.authorship_clauses_present else Fore.YELLOW)
    if law.critical_findings:
        print(_c(f"    ⚠ Critical clauses: {len(law.critical_findings)}", Fore.RED, True))
        for f in law.critical_findings[:4]:
            print(_c(f"      · {str(f)[:80]}", Fore.RED+Style.DIM))
    if law.trap_clause_hits:
        print(_c(f"    ⚡ Trap clauses: {len(law.trap_clause_hits)}", Fore.YELLOW))
    if law.coercion_hits:
        print(_c(f"    ⚠ Coercion: {len(law.coercion_hits)}", Fore.RED))

    print(_c("\n  [2/3] Delay Tactics detector...", Fore.GREEN))
    dt = DT_DETECT.analyze(raw_text)
    _kv("Delay score",       f"{dt.overall_score:.4f}",
        Fore.RED if dt.overall_score > 0.4 else
        Fore.YELLOW if dt.overall_score > 0.2 else Fore.GREEN)
    _kv("Verdict",           dt.verdict,
        Fore.RED if "ACTIVA" in dt.verdict else
        Fore.YELLOW if "DELAY" in dt.verdict else Fore.GREEN)
    _kv("Commitment voids", str(dt.commitment_void_count))
    _kv("Bureaucratic detours", str(dt.bureaucratic_depth))
    for tactic, hits in list(dt.tactics_by_category.items())[:3]:
        print(f"    {_c('▸ '+tactic, Fore.YELLOW)}: {len(hits)} hit(s)")
    if dt.recommendation:
        print(); print(_c(f"  RECOMMENDATION: {dt.recommendation}", Fore.CYAN))

    print(_c("\n  [3/3] Override-Gaslighting en texto legal...", Fore.GREEN))
    og = OG_DETECT.analyze(raw_text)
    _kv("Override score", f"{og.overall_score:.4f}")
    _kv("Verdict",        og.verdict,
        Fore.RED if "ACTIVA" in og.verdict else Fore.GREEN)
    if og.dominant_tactic != "—":
        _kv("Dominant tactic",  og.dominant_tactic, Fore.YELLOW)

    _section("RADAR DE RIESGO LEGAL", Fore.YELLOW)
    axes = {
        "Invarianza (κD)":        K_D,
        "Coherencia estructural": max(0.0, 1.0 - law.legal_risk_score * 2),
        "Linguistic transp.":  max(0.0, 1.0 - og.overall_score),
        "Legal symmetry":         max(0.0, 1.0 - dt.overall_score),
    }
    for axis, val in axes.items():
        print(f"  {axis:<28} {_bar(val, 25, val < 0.35)}")

    return {"lens":"human","law":law,"delay":dt,"override":og}

# ── FULL SCAN ─────────────────────────────────────────────────

def run_full_scan(raw_text, args):
    _section("FULL SCAN — PIPELINE COMPLETO", Fore.MAGENTA)
    machine = run_machine_node(raw_text, args)
    human   = run_human_node(raw_text, args)
    return {"lens":"full","machine":machine,"human":human}

# ── Firma y Ledger ────────────────────────────────────────────

def _seal(raw_text, results, args):
    _section("CRYPTOGRAPHIC SIGNATURE AND FORENSIC LEDGER", Fore.YELLOW)
    report_dict = {}
    if "report" in results:
        report_dict = results["report"].__dict__
    elif "machine" in results and "report" in results["machine"]:
        report_dict = results["machine"]["report"].__dict__

    signed = SIGNER.sign_report(report_dict or {"lens": results.get("lens","unknown")})
    sig    = signed["authorship"]
    _kv("Signed by",    sig["signed_by"])
    _kv("Protocolo",    sig["protocol"])
    _kv("Timestamp",    sig["timestamp"])
    _kv("SHA-256",      sig["content_hash"][:32]+"...")
    _kv("Genesis Hash", sig["hash_genesis"][:32]+"...")

    try:
        ledger_append(raw_text=raw_text, report_dict=report_dict or {},
                      authorship=sig)
        n = ledger_count()
        print(_c(f"\n  ▦  Forensic Ledger: entry #{n} recorded.", Fore.GREEN, True))
    except Exception as e:
        print(_c(f"\n  [WARN] Ledger: {e}", Fore.YELLOW))

    if args.sign:
        try:
            vault_path = CONNECTOR.export_evidence(
                signed, label=f"{args.lens}_{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}")
            print(_c(f"  ⬥  Evidence sealed: {vault_path.name}", Fore.GREEN))
        except Exception as e:
            print(_c(f"  [WARN] Vault: {e}", Fore.YELLOW))

# ── Pipeline ──────────────────────────────────────────────────

def run(args):
    _banner()
    lens = args.lens
    if not lens or lens == "menu":
        lens = _select_lens()
    args.lens = lens
    labels = {"machine":_c("[MACHINE NODE]",Fore.CYAN,True),
              "human":  _c("[HUMAN NODE]",Fore.GREEN,True),
              "full":   _c("[FULL SCAN]",Fore.MAGENTA,True)}
    print(f"  Lente: {labels.get(lens, lens)}")

    if args.file:
        raw_text = _load_file(args.file)
        print(_c(f"  Archivo: {args.file} ({len(raw_text):,} chars)", Style.DIM))
    else:
        print(); print(_c("  Ingrese texto a analizar:", Fore.YELLOW))
        raw_text = _read_input()

    if not raw_text.strip():
        print(_c("[ERROR] Sin contenido.", Fore.RED, True)); sys.exit(1)

    args._ref_content = _load_file(args.ref) if args.ref else ""

    if lens == "machine":   results = run_machine_node(raw_text, args)
    elif lens == "human":   results = run_human_node(raw_text, args)
    else:                   results = run_full_scan(raw_text, args)

    _seal(raw_text, results, args)

    print(); print(_c(SEP2, Fore.YELLOW, True))
    print(_c("  ✓  AUDIT COMPLETE", Fore.GREEN, True))
    print(_c(SEP2, Fore.YELLOW, True)); print()

def build_parser():
    p = argparse.ArgumentParser(
        prog="omni-scanner",
        description="Omni-Scanner Semantic v2.0 — Dual Machine/Human Interface",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Lentes:  machine | human | full | menu (default)

Ejemplos:
  python main.py
  python main.py --lens machine --file codigo.py
  python main.py --lens human   --file contrato.txt --sign
  python main.py --lens full    --file email.txt    --sign
        """)
    p.add_argument("--file",  help="Archivo a analizar")
    p.add_argument("--ref",   help="Reference file / Prior Art")
    p.add_argument("--lens",  choices=["machine","human","full","menu"], default="menu")
    p.add_argument("--type",  choices=["legal","code","discourse","finance","generic"], default="generic")
    p.add_argument("--sign",  action="store_true", help="Sellar en evidence_vault")
    p.add_argument("--json",  action="store_true", help="Salida JSON")
    return p

if __name__ == "__main__":
    run(build_parser().parse_args())
