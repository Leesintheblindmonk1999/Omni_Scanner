"""
interface/modules/clipboard_shield.py
──────────────────────────────────────
Live Clipboard Shield — Omni-Scanner v2.0 Module 1

Monitorea el portapapeles en un hilo secundario. Si detecta texto con
entropy deviation above threshold (config.yaml:noise_gap_threshold),
escribe una alerta en el SessionState compartido para que el hilo principal
de Streamlit la muestre via st.toast().

NOTA DE ARQUITECTURA:
  Streamlit ejecuta el script completo en cada rerun. Los threads de fondo
  deben ser singletons — se usa una variable global protegida por lock para
  garantizar que solo exista un hilo activo aunque Streamlit rerenderice.

Dependencias adicionales:
    pip install pyperclip
"""
from __future__ import annotations
import threading
import time
import hashlib
import math
import sys
from pathlib import Path
from typing import Callable

# ── Path para poder importar core/ ────────────────────────────
_ROOT = Path(__file__).resolve().parent.parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))


# ── Import opcional de pyperclip ──────────────────────────────
try:
    import pyperclip
    _PYPERCLIP_OK = True
except ImportError:
    _PYPERCLIP_OK = False


# ── Singleton del thread ──────────────────────────────────────
_shield_lock   = threading.Lock()
_shield_thread: threading.Thread | None = None
_shield_active = False


# ── Fast entropy (independent of EntropyAnalyzer) ─────────────
def _shannon_entropy(text: str) -> float:
    """Shannon character entropy over the given text."""
    if not text:
        return 0.0
    freq: dict[str, int] = {}
    for ch in text:
        freq[ch] = freq.get(ch, 0) + 1
    n = len(text)
    return -sum((c / n) * math.log2(c / n) for c in freq.values())


def _expected_entropy(text: str) -> float:
    """Expected entropy estimate for natural text (≈ log2 of vocabulary)."""
    words = text.split()
    if not words:
        return 0.0
    vocab = len(set(words))
    return math.log2(vocab + 1)


def _entropy_gap(text: str) -> float:
    """Gap = |H_observada - H_esperada| / H_esperada  (normalizado)."""
    h_obs = _shannon_entropy(text)
    h_exp = _expected_entropy(text)
    if h_exp == 0:
        return 0.0
    return abs(h_obs - h_exp) / h_exp


# ── Worker del hilo ───────────────────────────────────────────
def _monitor_worker(
    alert_queue: list[dict],
    threshold: float,
    poll_interval: float,
    stop_event: threading.Event,
) -> None:
    """
    Corre en background. Compara el portapapeles cada `poll_interval` segundos.
    When it detects text with entropy gap > threshold, appends to alert_queue.
    """
    last_hash = ""

    while not stop_event.is_set():
        try:
            if _PYPERCLIP_OK:
                clip_text = pyperclip.paste()
            else:
                # Sin pyperclip: no hay nada que monitorear
                time.sleep(poll_interval)
                continue

            if not isinstance(clip_text, str) or len(clip_text.strip()) < 20:
                time.sleep(poll_interval)
                continue

            # Only process if content changed
            text_hash = hashlib.md5(clip_text.encode("utf-8", errors="replace")).hexdigest()
            if text_hash == last_hash:
                time.sleep(poll_interval)
                continue

            last_hash = text_hash
            gap = _entropy_gap(clip_text)

            if gap > threshold:
                h_obs = _shannon_entropy(clip_text)
                preview = clip_text[:80].replace("\n", " ").strip()
                alert_queue.append({
                    "ts":      __import__("datetime").datetime.now().isoformat(),
                    "gap":     round(gap, 4),
                    "h_obs":   round(h_obs, 4),
                    "preview": preview,
                    "hash":    text_hash[:12],
                    "level":   "HIGH" if gap > threshold * 2 else "MEDIUM",
                })
        except Exception:
            # Silenciar errores (acceso denegado al portapapeles en algunos SO)
            pass

        time.sleep(poll_interval)


# ── Public API ────────────────────────────────────────────────

def start_shield(
    alert_queue: list[dict],
    threshold: float = 0.15,
    poll_interval: float = 3.0,
) -> threading.Event | None:
    """
    Starts the monitoring thread if not active.
    Returns the stop_event to stop it, or None if already running.
    """
    global _shield_thread, _shield_active

    with _shield_lock:
        if _shield_active and _shield_thread and _shield_thread.is_alive():
            return None  # Ya activo

        if not _PYPERCLIP_OK:
            return None  # Sin dependencia, no iniciamos

        stop_event = threading.Event()
        t = threading.Thread(
            target=_monitor_worker,
            args=(alert_queue, threshold, poll_interval, stop_event),
            daemon=True,
            name="ClipboardShield",
        )
        t.start()
        _shield_thread = t
        _shield_active = True
        return stop_event


def stop_shield(stop_event: threading.Event) -> None:
    """Detiene el hilo de monitoreo."""
    global _shield_active
    stop_event.set()
    with _shield_lock:
        _shield_active = False


def is_active() -> bool:
    """Returns True if the thread is running."""
    with _shield_lock:
        return _shield_active and _shield_thread is not None and _shield_thread.is_alive()


def pyperclip_available() -> bool:
    return _PYPERCLIP_OK
