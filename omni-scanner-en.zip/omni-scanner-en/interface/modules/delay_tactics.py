"""
interface/modules/delay_tactics.py
────────────────────────────────────
Attrition Tactics Detector (Delay Tactics) — Module v2.1

Detects patterns in corporate communications indicating
deliberate delay, exhaustion and evasion strategies.

Tactic categories:
  1. TEMPORAL EVASION: dateless promises, vague deadlines
  2. BUREAUCRATIC REDIRECT: "we need to check with..."
  3. URGENCY REDUCTION: minimizing the severity of the situation
  4. CIRCULAR DELEGATION: passing responsibility between departments
  5. REQUIREMENT OVERLOAD: requesting documentation already submitted
  6. COMMITMENT VOID: promises without concrete action

Also computes:
  - Bureaucratic Depth: how many intermediary entities are mentioned
  - Commitment Void: promises without concrete action

Bilingual detection: English + Spanish patterns.
CHANGELOG v2.1: Full English corpus added to all tactic categories.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List


# ── TEMPORAL EVASION ──────────────────────────────────────────
TEMPORAL_EVASION = [
    # Spanish
    r"a\s+la\s+brevedad\s+(posible)?",
    r"en\s+(los\s+)?próximos\s+(días|momentos|tiempos)",
    r"cuando\s+(tengamos|haya|exista)\s+(oportunidad|disponibilidad|tiempo)",
    r"(lo\s+)?estamos\s+(evaluando|analizando)",
    r"en\s+proceso\s+de\s+(revisión|análisis|evaluación)",
    r"en\s+cuanto\s+(podamos|sea\s+posible|tengamos\s+novedades)",
    r"(próximamente|en\s+breve|pronto)\s+te\s+(contactamos|informamos|avisamos)",
    r"sin\s+fecha\s+(definida|estimada|confirmada)",
    r"cuando\s+esté\s+(disponible|listo|aprobado)",
    r"pendiente\s+de\s+(definición|aprobación|confirmación)",
    # English
    r"as\s+soon\s+as\s+possible",
    r"in\s+the\s+(coming|next\s+few)\s+(days|weeks|moments)",
    r"when\s+(we\s+have\s+)?(time|availability|an\s+opportunity)",
    r"(we.re\s+)?currently\s+(evaluating|reviewing|analyzing|assessing)",
    r"under\s+(review|analysis|evaluation|consideration)",
    r"(we.ll\s+)?(keep\s+you\s+posted|get\s+back\s+to\s+you|be\s+in\s+touch)",
    r"(soon|shortly|in\s+due\s+course)",
    r"no\s+(confirmed|set|defined)\s+date",
    r"(pending|awaiting)\s+(approval|confirmation|sign.off|review)",
    r"(to\s+be\s+determined|TBD|TBC)",
    r"we.ll\s+(circle\s+back|follow\s+up)\s+(later|at\s+some\s+point)",
    r"(when\s+the\s+time\s+is\s+right|when\s+we.re\s+ready)",
]

# ── BUREAUCRATIC REDIRECT ─────────────────────────────────────
BUREAUCRATIC_REDIRECT = [
    # Spanish
    r"hay\s+que\s+(consultarlo|elevarlo|derivarlo|pasarlo)\s+(con|a|al?)",
    r"(depende|está\s+sujeto)\s+(de|a)\s+(aprobación|autorización|validación)",
    r"no\s+(está\s+en|depende\s+de)\s+(mi|nuestra)\s+(área|competencia|decisión)",
    r"(debe|tiene\s+que)\s+pasar\s+por\s+(el\s+área|el\s+departamento|el\s+comité|legal)",
    r"(necesita|requiere)\s+(la\s+)?(firma|aprobación|visto\s+bueno)\s+de",
    r"(otro\s+equipo|otra\s+área|otro\s+departamento)\s+(es\s+responsable|lo\s+maneja|lo\s+resuelve)",
    r"(no\s+soy|no\s+somos)\s+(el\s+área|los?\s+responsables?|quienes?\s+deciden?)",
    # English
    r"(we\s+need\s+to\s+)?escalate\s+(this|it)\s+to",
    r"(it\s+)?(depends\s+on|is\s+subject\s+to)\s+(approval|authorization|sign.off)",
    r"(that.s\s+)?not\s+(in\s+my|within\s+our)\s+(area|purview|authority|decision)",
    r"(it\s+needs\s+to\s+)?go\s+through\s+(legal|compliance|the\s+committee|management)",
    r"requires?\s+(sign.off|approval|sign.off|authorization)\s+from",
    r"(another\s+team|a\s+different\s+department)\s+(handles|owns|is\s+responsible\s+for)\s+this",
    r"(that.s\s+)?not\s+my\s+(call|decision|area\s+of\s+responsibility)",
    r"(i.ll\s+)?pass\s+(this|it)\s+(along|on\s+to|up\s+to)",
    r"above\s+my\s+pay\s+grade",
]

# ── URGENCY REDUCTION ─────────────────────────────────────────
URGENCY_REDUCTION = [
    # Spanish
    r"(no\s+es|no\s+hay)\s+(tanta\s+)?urgencia",
    r"(eso|esto)\s+puede\s+(esperar|resolverse\s+después)",
    r"no\s+(afecta|impacta|compromete)\s+(el\s+proceso|el\s+plazo|el\s+proyecto)",
    r"hay\s+(tiempo|margen)\s+(suficiente|de\s+sobra)",
    r"es\s+una\s+(situación|cuestión)\s+(normal|esperada|habitual|corriente)",
    r"(lo\s+)?resolveremos\s+en\s+su\s+momento",
    # English
    r"(there.s\s+)?no\s+(real\s+)?urgency",
    r"(that|this)\s+can\s+wait",
    r"it\s+(doesn.t|won.t)\s+(affect|impact|compromise)\s+(the\s+)?(process|deadline|project)",
    r"(we\s+have\s+)?plenty\s+of\s+time",
    r"(it.s\s+)?not\s+a\s+priority\s+(right\s+now|at\s+the\s+moment)",
    r"(we.ll\s+)?cross\s+that\s+bridge\s+when\s+we\s+come\s+to\s+it",
    r"(that.s\s+)?not\s+(urgent|critical|time.sensitive)",
    r"(we\s+have\s+)?room\s+to\s+breathe",
    r"(let.s\s+)?not\s+(rush|panic|overreact)",
    r"this\s+is\s+a\s+(normal|routine|standard|common)\s+(situation|issue|case)",
]

# ── CIRCULAR DELEGATION ───────────────────────────────────────
CIRCULAR_DELEGATION = [
    # Spanish
    r"(preguntale|consultale|derivalo)\s+a\s+\w+",
    r"(eso\s+lo\s+maneja|se\s+encarga)\s+\w+",
    r"(coordiná|hablá|contactá)\s+(con|directamente\s+con)\s+\w+",
    r"te\s+paso\s+con\s+\w+",
    # English
    r"(ask|check\s+with|contact|reach\s+out\s+to)\s+\w+\s+(about|for|regarding)\s+this",
    r"\w+\s+(handles|owns|manages|is\s+in\s+charge\s+of)\s+that",
    r"(talk|speak|coordinate)\s+(with|directly\s+with)\s+\w+",
    r"(i.ll\s+)?(transfer|forward|pass)\s+you\s+(to|along\s+to)\s+\w+",
    r"(you\s+should\s+)?loop\s+in\s+\w+",
    r"(that\s+would\s+be\s+a\s+question\s+for|you.d\s+need\s+to\s+talk\s+to)\s+\w+",
    r"(they|them)\s+(can\s+)?(help\s+you\s+with|answer\s+that|handle\s+it)",
]

# ── REQUIREMENT OVERLOAD ──────────────────────────────────────
REQUIREMENT_OVERLOAD = [
    # Spanish
    r"(necesitamos|requerimos|falta)\s+(otro\s+|un\s+nuevo\s+)?(documento|comprobante|certificado|aval)",
    r"(adjuntá|enviá|presentá)\s+(de\s+nuevo|otra\s+vez|nuevamente)",
    r"(hay\s+que\s+)?(actualizar|renovar|revalidar)\s+la\s+(documentación|solicitud|presentación)",
    r"falta\s+(la\s+firma|el\s+sello|el\s+apostille|la\s+notarización)",
    r"(los\s+documentos|la\s+documentación)\s+(están\s+incompletos|no\s+cumplen|presentan\s+errores)",
    # English
    r"(we\s+need|we\s+require|missing)\s+(another|a\s+new)\s+(document|certificate|proof|form)",
    r"(please\s+)?(re.?submit|send\s+again|resubmit|provide\s+again)",
    r"(you\s+need\s+to\s+)?(update|renew|revalidate|refresh)\s+(the\s+)?(documentation|application|submission)",
    r"(missing|we\s+need)\s+(the\s+)?(signature|stamp|notarization|apostille)",
    r"(the\s+documents?|documentation)\s+(is|are)\s+(incomplete|not\s+compliant|missing|incorrect)",
    r"(please\s+)?(fill\s+out|complete)\s+(the\s+)?form\s+again",
    r"additional\s+(documentation|proof|evidence|verification)\s+(is\s+)?(required|needed)",
]

# ── COMMITMENT VOID ───────────────────────────────────────────
COMMITMENT_VOID = [
    # Spanish
    r"(nos\s+comprometemos|vamos)\s+a\s+(ver|analizar|estudiar|revisar)\s+(el\s+caso|tu\s+situación|esto)",
    r"(te\s+)?(mantenemos|mantendremos)\s+(al\s+tanto|informado)",
    r"(cualquier\s+novedad|cuando\s+haya\s+avances)\s+te\s+(avisamos|informamos|contactamos)",
    r"(vamos\s+a\s+)?hacer\s+lo\s+(posible|mejor\s+posible|que\s+podamos)",
    r"(tomaremos|tomamos)\s+(nota|registro)\s+de\s+(tu\s+caso|tu\s+situación|la\s+solicitud)",
    # English
    r"(we\s+will\s+)?look\s+into\s+(it|this|that)",
    r"(we.ll\s+)?(keep\s+you\s+updated|keep\s+you\s+posted|keep\s+you\s+informed)",
    r"(we.ll\s+let\s+you\s+know|we.ll\s+be\s+in\s+touch)\s+(if|when|once)",
    r"(we.ll\s+)?(do\s+our\s+best|try\s+our\s+best|do\s+what\s+we\s+can)",
    r"(we.ve\s+)?taken\s+note\s+of\s+(your\s+(case|request|concern|situation))",
    r"(it.s\s+been\s+)?(logged|noted|recorded)\s+(in\s+our\s+system)?",
    r"(we\s+appreciate|thank\s+you\s+for)\s+your\s+(patience|understanding)",
    r"(rest\s+assured|be\s+assured)\s+(we.re|that\s+we.re)\s+(working\s+on\s+it|looking\s+into\s+it)",
    r"(your\s+feedback\s+has\s+been\s+)?forwarded\s+to\s+the\s+(relevant\s+)?team",
]

ALL_TACTICS = {
    "TEMPORAL EVASION":       TEMPORAL_EVASION,
    "BUREAUCRATIC REDIRECT":  BUREAUCRATIC_REDIRECT,
    "URGENCY REDUCTION":      URGENCY_REDUCTION,
    "CIRCULAR DELEGATION":    CIRCULAR_DELEGATION,
    "REQUIREMENT OVERLOAD":   REQUIREMENT_OVERLOAD,
    "COMMITMENT VOID":        COMMITMENT_VOID,
}


@dataclass
class DelayTacticsReport:
    overall_score:         float = 0.0
    verdict:               str   = "CLEAN"
    tactics_by_category:   dict  = field(default_factory=dict)
    total_hits:            int   = 0
    dominant_tactic:       str   = "—"
    commitment_void_count: int   = 0
    bureaucratic_depth:    int   = 0
    flagged_phrases:       list  = field(default_factory=list)
    summary:               str   = ""
    recommendation:        str   = ""


class DelayTacticsDetector:
    """
    Analyzes corporate communications detecting attrition tactics.
    Bilingual: English + Spanish.
    """

    def analyze(self, text: str) -> DelayTacticsReport:
        report = DelayTacticsReport()
        if not text or len(text.strip()) < 15:
            report.verdict = "INSUFFICIENT"
            return report

        text_lower = text.lower()
        tactics_found: dict[str, list[str]] = {}
        all_hits: list[dict] = []

        for tactic, patterns in ALL_TACTICS.items():
            hits = []
            for pattern in patterns:
                m = re.search(pattern, text_lower, re.IGNORECASE)
                if m:
                    start = max(0, m.start() - 25)
                    end   = min(len(text), m.end() + 25)
                    ctx   = "..." + text[start:end].strip() + "..."
                    hits.append(ctx)
                    all_hits.append({"tactic": tactic, "context": ctx})
            if hits:
                tactics_found[tactic] = hits

        total      = sum(len(v) for v in tactics_found.values())
        depth      = len(tactics_found.get("BUREAUCRATIC REDIRECT", []))
        void       = len(tactics_found.get("COMMITMENT VOID", []))
        cat_score  = len(tactics_found) / len(ALL_TACTICS)
        hit_score  = min(total / 10.0, 1.0)
        score      = cat_score * 0.6 + hit_score * 0.4
        dominant   = max(tactics_found, key=lambda k: len(tactics_found[k])) if tactics_found else "—"

        if score >= 0.50:
            verdict = "ACTIVE ATTRITION CAMPAIGN"
            rec = ("Document all communications with date/time. "
                   "Request written responses with explicit deadlines. "
                   "Consider formal escalation or legal intervention.")
        elif score >= 0.25:
            verdict = "DELAY TACTICS DETECTED"
            rec = ("Establish concrete deadlines in upcoming communications. "
                   "Request written confirmation of commitments.")
        elif score > 0:
            verdict = "MINOR EVASION SIGNALS"
            rec = "Monitor subsequent communications to detect patterns."
        else:
            verdict = "CLEAN"
            rec = "No attrition tactics detected."

        report.overall_score         = round(score, 4)
        report.verdict               = verdict
        report.tactics_by_category   = tactics_found
        report.total_hits            = total
        report.dominant_tactic       = dominant
        report.commitment_void_count = void
        report.bureaucratic_depth    = depth
        report.flagged_phrases       = all_hits[:20]
        report.summary = (
            f"Score: {score:.3f} | Tactics: {len(tactics_found)}/{len(ALL_TACTICS)} | "
            f"Dominant: {dominant} | Commitment voids: {void} | Bureaucratic detours: {depth}"
        )
        report.recommendation = rec
        return report
