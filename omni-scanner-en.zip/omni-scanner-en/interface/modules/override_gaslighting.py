"""
interface/modules/override_gaslighting.py
──────────────────────────────────────────
Override-Gaslighting Detector — Module v2.1

Detects technical authority neutralization phrases: linguistic
patterns that invalidate, redirect or minimize authorship,
expert knowledge or the writer's position.

Difference from SocialEngineer:
  - SocialEngineer detects GENERAL manipulation in discourse
  - This module specifically detects TECHNICAL AUTHORITY
    NEUTRALIZATION in intellectual property, negotiation and
    corporate communication contexts.

Detected categories:
  1. EXPERTISE MINIMIZATION: "anyone can do that"
  2. PURPOSE REDIRECTION: "that's not what we agreed"
  3. EVIDENCE INVALIDATION: "that's not enough proof"
  4. AUTHORSHIP DILUTION: "it was a team effort"
  5. INSTITUTIONAL GASLIGHTING: "we never said that"
  6. CONFORMITY PRESSURE: "everyone agrees except you"

Bilingual detection: English + Spanish patterns.
CHANGELOG v2.1: Full English corpus added to all categories.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List


# ── EXPERTISE MINIMIZATION ────────────────────────────────────
MINIMIZE_EXPERTISE = [
    # Spanish
    r"cualquiera\s+(puede|podría|hubiera)\s+(hacer|haber\s+hecho)",
    r"no\s+(es|fue)\s+tan\s+(difícil|complejo|innovador)",
    r"eso\s+(ya\s+exist[eí]a|es\s+conocido|es\s+estándar)",
    r"no\s+(inventaste|descubriste|creaste)\s+nada\s+nuevo",
    r"es\s+(obvio|trivial|básico|elemental)",
    r"lo\s+(hace|haría)\s+cualquier\s+(programador|técnico|persona)",
    r"no\s+es\s+(un\s+)?(descubrimiento|innovación|aporte)",
    # English
    r"anyone\s+could\s+(have\s+)?(done|built|made)\s+that",
    r"it.s\s+not\s+that\s+(hard|difficult|complex|innovative)",
    r"that\s+(already\s+exists|is\s+well.known|is\s+standard)",
    r"you\s+didn.t\s+(invent|discover|create)\s+anything\s+new",
    r"(that.s\s+)?obvious",
    r"(it.s\s+)?(trivial|basic|elementary)",
    r"any\s+(programmer|developer|engineer|person)\s+(could|can)\s+(do|build|make)\s+that",
    r"(that.s\s+)?not\s+(a\s+)?(discovery|innovation|contribution)",
    r"this\s+is\s+nothing\s+(new|original|groundbreaking)",
    r"it.s\s+just\s+(a\s+)?(copy|clone|fork)",
]

# ── PURPOSE REDIRECTION ───────────────────────────────────────
REDIRECT_PURPOSE = [
    # Spanish
    r"eso\s+no\s+es\s+lo\s+que\s+(acordamos|pedimos|necesitamos)",
    r"se\s+está\s+(desviando|alejando)\s+del\s+(tema|objetivo|punto)",
    r"(volvamos|regresemos)\s+al\s+(punto|tema|asunto)\s+principal",
    r"eso\s+no\s+(es\s+relevante|viene\s+al\s+caso|aplica\s+aquí)",
    r"concentrémonos\s+en\s+lo\s+que\s+(importa|es\s+urgente)",
    # English
    r"that.s\s+not\s+what\s+we\s+(agreed|asked\s+for|need)",
    r"you.re\s+(getting\s+off.track|going\s+off.topic|deviating)",
    r"let.s\s+(get\s+back\s+to|focus\s+on)\s+the\s+(point|topic|issue)",
    r"that.s\s+(not\s+relevant|beside\s+the\s+point|off.topic)",
    r"(let.s\s+)?focus\s+on\s+what\s+(matters|is\s+important|is\s+urgent)",
    r"(can\s+we\s+)?stay\s+on\s+topic",
    r"we.re\s+(getting\s+)?sidetracked",
]

# ── EVIDENCE INVALIDATION ─────────────────────────────────────
INVALIDATE_EVIDENCE = [
    # Spanish
    r"eso\s+no\s+(es|constituye)\s+(suficiente\s+)?(prueba|evidencia)",
    r"no\s+(tiene|hay)\s+valor\s+(legal|probatorio|técnico)",
    r"(sin|falta)\s+(firma|notarización|certificación)\s+oficial",
    r"no\s+(está|fue)\s+(registrado|validado|certificado)",
    r"(cualquier\s+juez|un\s+tribunal)\s+(desestimar[ía]|rechazar[ía])",
    r"no\s+tiene\s+respaldo\s+(científico|técnico|legal)",
    # English
    r"that.s\s+not\s+(sufficient\s+)?(proof|evidence)",
    r"(it\s+has|there.s)\s+no\s+(legal|technical|probative)\s+value",
    r"(without|missing)\s+(official\s+)?(signature|notarization|certification)",
    r"(it.s\s+not|hasn.t\s+been)\s+(registered|validated|certified)",
    r"(any\s+judge|a\s+court)\s+would\s+(dismiss|reject|throw\s+out)",
    r"(it\s+has\s+)?no\s+(scientific|technical|legal)\s+backing",
    r"that\s+(proves|demonstrates|establishes)\s+nothing",
    r"inadmissible",
    r"(won.t\s+)?hold\s+up\s+in\s+court",
]

# ── AUTHORSHIP DILUTION ───────────────────────────────────────
DILUTE_AUTHORSHIP = [
    # Spanish
    r"fue\s+(un\s+trabajo|resultado|producto)\s+de\s+(equipo|colaboración)",
    r"(todos|el\s+equipo|nosotros)\s+(contribuimos|aportamos|participamos)",
    r"no\s+(lo\s+hiciste|fue)\s+solo",
    r"(basado\s+en|derivado\s+de|inspirado\s+en)\s+(trabajo|ideas)\s+(ajeno|previo|de\s+otros)",
    r"no\s+puedes?\s+reclamar\s+(autoría|propiedad)\s+exclusiva",
    # English
    r"(it\s+was|this\s+was)\s+a\s+team\s+(effort|project|collaboration)",
    r"(we\s+all|everyone)\s+(contributed|participated|had\s+a\s+part)",
    r"you\s+didn.t\s+(do|build|create)\s+(it\s+)?alone",
    r"(based\s+on|derived\s+from|inspired\s+by)\s+(prior|existing|someone\s+else.s)\s+(work|ideas)",
    r"you\s+can.t\s+claim\s+(sole\s+)?(authorship|ownership|credit)",
    r"(it.s\s+)?collective\s+(work|property|effort|output)",
    r"(everyone|the\s+team)\s+(owns|contributed\s+to)\s+(this|it)",
    r"you\s+were\s+just\s+(one\s+of\s+many|part\s+of\s+the\s+team)",
]

# ── INSTITUTIONAL GASLIGHTING ─────────────────────────────────
INSTITUTIONAL_GASLIGHTING = [
    # Spanish
    r"nunca\s+(dijimos|prometimos|acordamos)\s+eso",
    r"no\s+hay\s+(registro|constancia|evidencia)\s+de\s+eso",
    r"(mal|erróneamente)\s+interpretaste",
    r"eso\s+nunca\s+(fue|estuvo)\s+(sobre\s+la\s+mesa|acordado)",
    r"(recuerdo|recordamos)\s+diferente",
    r"no\s+es\s+como\s+lo\s+(contás|describís|presentás)",
    r"estás\s+(confundiendo|mezclando)\s+(los\s+hechos|las\s+fechas)",
    # English
    r"(we\s+)?never\s+(said|promised|agreed\s+to)\s+that",
    r"there.s\s+no\s+(record|evidence|documentation)\s+of\s+that",
    r"you\s+(mis|mis.?)understood",
    r"that\s+was\s+never\s+(on\s+the\s+table|agreed\s+upon|discussed)",
    r"(i\s+remember|we\s+remember)\s+(it\s+)?differently",
    r"that.s\s+not\s+(how|what)\s+(it\s+happened|was\s+said|was\s+agreed)",
    r"you.re\s+(confusing|mixing\s+up)\s+(the\s+facts|the\s+dates|things)",
    r"that.s\s+not\s+what\s+(was\s+said|happened|took\s+place)",
    r"you\s+must\s+be\s+(confused|mistaken|misremembering)",
]

# ── CONFORMITY PRESSURE ───────────────────────────────────────
CONFORMITY_PRESSURE = [
    # Spanish
    r"(todos|nadie\s+más|el\s+resto)\s+(está\s+de\s+acuerdo|acepta|entiende)",
    r"(sos|es)\s+el\s+único\s+que\s+(piensa|dice|cree)\s+eso",
    r"(tus\s+colegas|el\s+equipo|los\s+expertos)\s+(no\s+están\s+de\s+acuerdo|discrepan)",
    r"(consenso|acuerdo\s+general|posición\s+unánime)\s+(es|fue|indica)",
    r"nadie\s+más\s+(lo\s+ve|lo\s+entiende)\s+así",
    # English
    r"(everyone|nobody\s+else|the\s+rest)\s+(agrees|accepts|understands)",
    r"you.re\s+the\s+only\s+one\s+(who\s+)?(thinks|says|believes)\s+that",
    r"(your\s+colleagues|the\s+team|the\s+experts)\s+(disagree|don.t\s+agree)",
    r"(consensus|general\s+agreement|unanimous\s+position)\s+(is|was|indicates)",
    r"nobody\s+else\s+(sees|understands)\s+it\s+(that\s+way|like\s+that)",
    r"you.re\s+going\s+against\s+(the\s+consensus|everyone|the\s+group)",
    r"(the\s+rest\s+of\s+)?the\s+team\s+(is\s+on\s+board|agrees|has\s+no\s+issue)",
]

ALL_CATEGORIES = {
    "EXPERTISE MINIMIZATION":    MINIMIZE_EXPERTISE,
    "PURPOSE REDIRECTION":       REDIRECT_PURPOSE,
    "EVIDENCE INVALIDATION":     INVALIDATE_EVIDENCE,
    "AUTHORSHIP DILUTION":       DILUTE_AUTHORSHIP,
    "INSTITUTIONAL GASLIGHTING": INSTITUTIONAL_GASLIGHTING,
    "CONFORMITY PRESSURE":       CONFORMITY_PRESSURE,
}


@dataclass
class OverrideGaslightingReport:
    overall_score:    float = 0.0
    verdict:          str   = "CLEAN"
    hits_by_category: dict  = field(default_factory=dict)
    total_hits:       int   = 0
    flagged_phrases:  list  = field(default_factory=list)
    dominant_tactic:  str   = "—"
    summary:          str   = ""


class OverrideGaslightingDetector:
    """
    Detects technical authority neutralization patterns.
    Bilingual: English + Spanish.
    """

    def analyze(self, text: str) -> OverrideGaslightingReport:
        report = OverrideGaslightingReport()
        if not text or len(text.strip()) < 15:
            report.verdict = "INSUFFICIENT"
            return report

        text_lower = text.lower()
        hits_by_cat: dict[str, list[str]] = {}
        all_hits: list[dict] = []

        for category, patterns in ALL_CATEGORIES.items():
            cat_hits = []
            for pattern in patterns:
                matches = re.findall(pattern, text_lower, re.IGNORECASE)
                if matches:
                    m = re.search(pattern, text, re.IGNORECASE)
                    if m:
                        start = max(0, m.start() - 20)
                        end   = min(len(text), m.end() + 20)
                        ctx   = "..." + text[start:end].strip() + "..."
                        cat_hits.append(ctx)
                        all_hits.append({"category": category, "context": ctx})
            if cat_hits:
                hits_by_cat[category] = cat_hits

        total   = sum(len(v) for v in hits_by_cat.values())
        score   = len(hits_by_cat) / len(ALL_CATEGORIES)
        dominant = max(hits_by_cat, key=lambda k: len(hits_by_cat[k])) if hits_by_cat else "—"

        if score >= 0.5:
            verdict = "ACTIVE AUTHORITY NEUTRALIZATION"
        elif score >= 0.25:
            verdict = "SUSPICIOUS PATTERNS"
        elif score > 0:
            verdict = "MINOR SIGNALS"
        else:
            verdict = "CLEAN"

        report.overall_score    = round(score, 4)
        report.verdict          = verdict
        report.hits_by_category = {k: v for k, v in hits_by_cat.items()}
        report.total_hits       = total
        report.flagged_phrases  = all_hits[:20]
        report.dominant_tactic  = dominant
        report.summary = (
            f"Score: {score:.3f} | Categories: {len(hits_by_cat)}/{len(ALL_CATEGORIES)} | "
            f"Dominant tactic: {dominant} | Total hits: {total}"
        )
        return report
