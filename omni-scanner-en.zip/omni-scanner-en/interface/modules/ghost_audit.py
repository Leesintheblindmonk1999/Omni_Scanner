"""
interface/modules/ghost_audit.py
─────────────────────────────────
Ghost Audit — Semantic Potential Loss Analyzer

Detecta texto "corporativo/vacío": high in filler words,
low in real informational density. Emits alerta de Degradación
Degradation alert when lexical entropy falls below threshold.

METHODOLOGY:
  · Lexical Entropy: Shannon entropy over word distribution
  · Type-Token Ratio (TTR): lexical diversity = unique_vocab / total_tokens
  · Corporate Buzzword Density: frequency of known empty terms
  · Syntactic Flatness: sentence length variance (low = monotonous)
  · Information Density Score: weighted combination of the above

Niveles de alerta:
  CRITICAL DEGRADATION  → score < 0.25
  SEMANTIC RISK         → score < 0.45
  POTENCIAL REDUCIDO   → score < 0.60
  SALUDABLE            → score ≥ 0.60
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import List


# ── Empty corporate buzzword dictionary ───────────────────────
# Includes Spanish and English terms common in 'empty' documents
CORPORATE_BUZZWORDS: set[str] = {
    # Empty management (ES)
    "sinergia", "sinergias", "alineamiento", "alinear", "robusto", "robusta",
    "escalable", "escalabilidad", "empoderamiento", "empoderar", "paradigma",
    "holístico", "holística", "ecosistema", "proactivo", "proactiva",
    "innovador", "innovadora", "disruptivo", "disruptiva", "transversal",
    "estratégico", "estratégica", "optimizar", "optimización",
    "valor agregado", "core", "mindset", "feedback", "roadmap",
    "stakeholder", "stakeholders", "deliverable", "benchmark",
    "best practice", "best practices", "kpi", "okr",
    # Management empty (EN)
    "leverage", "synergy", "synergies", "paradigm", "holistic",
    "scalable", "scalability", "ecosystem", "proactive", "innovative",
    "disruptive", "streamline", "optimize", "optimization",
    "value-added", "actionable", "impactful", "robust", "seamless",
    "cutting-edge", "state-of-the-art", "world-class", "best-in-class",
    "game-changer", "game-changing", "next-level", "mission-critical",
    "move the needle", "low-hanging fruit", "circle back",
    "bandwidth", "pivot", "agile", "nimble", "thought leader",
    # Empty legal jargon
    "en virtud de lo anterior", "a los efectos de", "en el marco de",
    "en atención a", "habida cuenta", "no obstante lo anterior",
    "sin perjuicio de", "de conformidad con",
}

# Template-generated text markers (structural repetition)
TEMPLATE_MARKERS = [
    r'\b(la empresa|the company)\b.{0,30}\b(se reserva|reserves)\b',
    r'\b(cualquier|any)\b.{0,20}\b(será considerado|shall be deemed)\b',
    r'\b(el presente|this agreement|this document)\b.{0,20}\b(rige|governs)\b',
    r'\bnull and void\b',
    r'\bnulo de pleno derecho\b',
    r'\birrevocablemente\b.{0,30}\brenuncia\b',
]


@dataclass
class GhostAuditReport:
    """Result of semantic degradation analysis."""
    overall_score:       float = 1.0     # 0=empty, 1=rich
    alert_level:         str   = "SALUDABLE"
    lexical_entropy:     float = 0.0
    type_token_ratio:    float = 0.0
    buzzword_density:    float = 0.0
    syntactic_flatness:  float = 0.0
    template_hits:       list  = field(default_factory=list)
    buzzwords_found:     list  = field(default_factory=list)
    token_count:         int   = 0
    unique_tokens:       int   = 0
    summary:             str   = ""
    recommendation:      str   = ""


class GhostAuditor:
    """
    Analyzes text looking for semantic emptiness signals:
    corporate languageo repetitivo, baja densidad informacional,
    estructuras de template.
    """

    def __init__(
        self,
        entropy_floor: float   = 0.60,   # minimum normalized entropy threshold
        ttr_floor:     float   = 0.30,   # minimum acceptable TTR
        buzzword_ceil: float   = 0.08,   # max 8% buzzwords before alerting
    ):
        self.entropy_floor  = entropy_floor
        self.ttr_floor      = ttr_floor
        self.buzzword_ceil  = buzzword_ceil

    # ── Tokenization ──────────────────────────────────────────

    @staticmethod
    def _tokenize(text: str) -> list[str]:
        """Word tokens, lowercased, without punctuation."""
        return re.findall(r'\b[a-záéíóúñüA-ZÁÉÍÓÚÑÜ]{3,}\b', text.lower())

    @staticmethod
    def _sentences(text: str) -> list[str]:
        """Splits into sentences by punctuation."""
        parts = re.split(r'[.!?;]+', text)
        return [p.strip() for p in parts if len(p.strip()) > 10]

    # ── Individual metrics ────────────────────────────────────

    def _lexical_entropy(self, tokens: list[str]) -> float:
        """
        Shannon entropy over word distribution.
        Normalized by log2(N) so 1.0 = perfectly uniform distribution.
        """
        if len(tokens) < 5:
            return 0.0
        freq: dict[str, int] = {}
        for t in tokens:
            freq[t] = freq.get(t, 0) + 1
        n = len(tokens)
        h = -sum((c / n) * math.log2(c / n) for c in freq.values())
        max_h = math.log2(n) if n > 1 else 1.0
        return h / max_h

    def _type_token_ratio(self, tokens: list[str]) -> float:
        """TTR = unique tokens / total tokens. Corrected for long texts."""
        if not tokens:
            return 0.0
        # RTTR (Root TTR) — more stable for texts of different lengths
        return len(set(tokens)) / math.sqrt(len(tokens))

    def _buzzword_density(self, tokens: list[str], text_lower: str) -> tuple[float, list[str]]:
        """Buzzword proportion over total tokens."""
        if not tokens:
            return 0.0, []
        found = []
        # Palabras sueltas
        token_set = set(tokens)
        for bw in CORPORATE_BUZZWORDS:
            if " " in bw:
                if bw in text_lower:
                    found.append(bw)
            elif bw in token_set:
                found.append(bw)
        density = len([t for t in tokens if t in CORPORATE_BUZZWORDS]) / len(tokens)
        return density, list(set(found))

    def _syntactic_flatness(self, sentences: list[str]) -> float:
        """
        Sentence length variance.
        Monotonous texts (always same length) have low variance → high flatness.
        Retorna flatness ∈ [0,1]: 1 = completamente plano.
        """
        if len(sentences) < 3:
            return 0.5  # insuficiente para medir
        lens = [len(s.split()) for s in sentences]
        mean = sum(lens) / len(lens)
        var  = sum((l - mean) ** 2 for l in lens) / len(lens)
        # Normalize: high variance (>50) = dynamic = low flatness
        flatness = 1.0 - min(var / 50.0, 1.0)
        return flatness

    def _template_hits(self, text: str) -> list[str]:
        """Busca marcadores de texto generado por templates."""
        hits = []
        text_lower = text.lower()
        for pattern in TEMPLATE_MARKERS:
            if re.search(pattern, text_lower):
                hits.append(pattern.replace(r'\b', '').replace('(', '').split('.')[0][:50])
        return hits

    # ── Main analysis ─────────────────────────────────────────

    def analyze(self, text: str) -> GhostAuditReport:
        """
        Analiza el texto y retorna un GhostAuditReport.
        """
        report = GhostAuditReport()

        if not text or len(text.strip()) < 20:
            report.alert_level  = "INSUFICIENTE"
            report.summary      = "Text too short for analysis."
            return report

        tokens      = self._tokenize(text)
        sentences   = self._sentences(text)
        text_lower  = text.lower()

        if len(tokens) < 5:
            report.alert_level = "INSUFICIENTE"
            report.summary     = "Vocabulario insuficiente."
            return report

        # Calculate metrics
        lex_h       = self._lexical_entropy(tokens)
        ttr         = self._type_token_ratio(tokens)
        bwd, bwords = self._buzzword_density(tokens, text_lower)
        flatness    = self._syntactic_flatness(sentences)
        tmpl_hits   = self._template_hits(text)

        # Normalize TTR to [0,1]  (RTTR typical: 2–8 for natural texts)
        ttr_norm = min(ttr / 6.0, 1.0)

        # Composite score (higher = semantically richer)
        # buzzword y flatness son penalizaciones (invertidas)
        bwd_penalty      = min(bwd / self.buzzword_ceil, 1.0)
        flatness_penalty = flatness
        tmpl_penalty     = min(len(tmpl_hits) * 0.15, 0.45)

        overall = (
            lex_h    * 0.35
            + ttr_norm * 0.30
            + (1.0 - bwd_penalty)      * 0.20
            + (1.0 - flatness_penalty) * 0.10
            + (1.0 - tmpl_penalty)     * 0.05
        )
        overall = max(0.0, min(1.0, overall))

        # Nivel de alerta
        if overall < 0.25:
            level = "CRITICAL DEGRADATION"
            rec   = ("The text shows severe signs of semantic emptying. "
                     "High probability of template-generated or AI language without critical review.")
        elif overall < 0.45:
            level = "SEMANTIC RISK"
            rec   = ("Densidad informacional baja. Exceso de términos de relleno. "
                     "Revisar y enriquecer con argumentos específicos y datos concretos.")
        elif overall < 0.60:
            level = "POTENCIAL REDUCIDO"
            rec   = ("El texto es funcional pero tiene margen de mejora en originalidad léxica. "
                     "Reducir repetición y aumentar especificidad técnica.")
        else:
            level = "SALUDABLE"
            rec   = "Adequate semantic density. No degradation signals."

        report.overall_score      = round(overall, 4)
        report.alert_level        = level
        report.lexical_entropy    = round(lex_h, 4)
        report.type_token_ratio   = round(ttr_norm, 4)
        report.buzzword_density   = round(bwd, 4)
        report.syntactic_flatness = round(flatness, 4)
        report.template_hits      = tmpl_hits
        report.buzzwords_found    = bwords[:15]
        report.token_count        = len(tokens)
        report.unique_tokens      = len(set(tokens))
        report.recommendation     = rec
        report.summary = (
            f"Lexical entropy: {lex_h:.3f} | TTR: {ttr:.3f} | "
            f"Buzzwords: {bwd:.1%} ({len(bwords)}) | "
            f"Templates: {len(tmpl_hits)} | Score: {overall:.4f}"
        )
        return report
