"""
interface/app.py — Omni-Scanner Semantic v2.0
──────────────────────────────────────────────
Modules v2.0:
  · Module 4: Ghost Audit        (semantic degradation detector)
  · Module 5: Shadow-Code        (AI vs human authorship analysis)
  · Ancla de Identidad           (embed PDF steganographic anchor)

Installation:
    pip install streamlit plotly numpy networkx fpdf2 pyperclip
    pip install kaleido  # for exporting charts to PDF

Run (from project root):
    streamlit run interface/app.py
"""
from __future__ import annotations
import sys
import os
import json
import math
import hashlib
import datetime
from pathlib import Path

# ── Path setup (run from project root) ────────────────────────
ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

import streamlit as st
import numpy as np
import plotly.graph_objects as go
import plotly.express as px

# ── System imports ─────────────────────────────────────────────
from engines.full_diagnostic import FullDiagnostic, FullDiagnosticReport
from utils.text_cleaner import TextCleaner
from utils.api_connector import ApiConnector
from protocols.metadata_origin import MetadataOrigin
from protocols import CONFIG

# ── Modules v2.0 ─────────────────────────────────────────────
try:
    from core.semantic_diff import SemanticDiff, SemanticDiffReport
    _DIFF_OK = True
except ImportError:
    _DIFF_OK = False

try:
    from core.batch_auditor import BatchAuditor, BatchReport, FileResult
    _BATCH_OK = True
except ImportError:
    _BATCH_OK = False

try:
    from core.stream_monitor import StreamMonitor, ShieldEvent
    _MONITOR_OK = True
except ImportError:
    _MONITOR_OK = False

try:
    from core.ledger_vanguard import LedgerVanguard, LedgerEntry
    _LEDGER_OK = True
except ImportError:
    _LEDGER_OK = False

try:
    from core.threshold_calibrator import ThresholdCalibrator
    _CALIB_OK = True
except ImportError:
    _CALIB_OK = False

# ── Constants ─────────────────────────────────────────────────
K_DURANTE = CONFIG.stability_constant if CONFIG else 0.56
VAULT_DIR = ROOT / "logs" / "evidence_vault"
CSS_PATH  = Path(__file__).parent / "assets" / "style.css"
VERSION   = "v2.0 · ANEXA Ultra v4.0"

# ── Modules v2.0 ──────────────────────────────────────────────
from interface.modules.clipboard_shield import (
    start_shield, stop_shield, is_active as shield_is_active,
    pyperclip_available,
)
from interface.modules.inverse_plagiarism import (
    InversePlagiarismDetector, PlagiarismReport
)
from reports.generators.genesis_certifier import GenesisCertifier

CERTIFIER  = GenesisCertifier()
PLAGIARISM = InversePlagiarismDetector()

# ── Modules v3.0 (legacy) ───────────────────────────────────────
from interface.modules.ghost_audit  import GhostAuditor,  GhostAuditReport
from interface.modules.shadow_code  import ShadowCodeDetector, ShadowCodeReport

GHOST_AUDITOR  = GhostAuditor()
SHADOW_DETECT  = ShadowCodeDetector()

# ── Module v3.1: Forensic Ledger ───────────────────────────────
from logs.forensic_ledger import (
    append_entry  as ledger_append,
    read_entries  as ledger_read,
    entry_count   as ledger_count,
    verify_integrity as ledger_verify,
)

# ══════════════════════════════════════════════════════════════
# PAGE CONFIGURATION
# ══════════════════════════════════════════════════════════════

st.set_page_config(
    page_title="Omni-Scanner Semantic v2.0",
    page_icon="⬡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Cargar CSS ─────────────────────────────────────────────────
# Inject fonts via direct <link> (more reliable than @import in Streamlit)
st.markdown("""
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Orbitron:wght@400;700;900&display=swap" rel="stylesheet">
""", unsafe_allow_html=True)

if CSS_PATH.exists():
    st.markdown(f"<style>{CSS_PATH.read_text(encoding='utf-8')}</style>",
                unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════
# CONSTANTES Y SINGLETONS
# ══════════════════════════════════════════════════════════════

K_D = CONFIG.stability_constant if CONFIG else 0.56
NOISE_THRESHOLD = CONFIG.noise_gap_threshold if CONFIG else 0.15
PLAGIARISM_THRESHOLD = CONFIG.plagiarism_threshold if CONFIG else 0.85

CLEANER    = TextCleaner()
# min_tokens reducido a 20 para la interfaz — textos cortos como contratos
# brief texts should be analyzed. The core remains configurable via config.yaml.
from core.entropy_analyzer import EntropyAnalyzer as _EA
from core.multifractal_processor import MultifractalProcessor as _MFP
from core.manifold_engine import ManifoldEngine as _ME
from core.topology_mapper import TopologyMapper as _TM
_me = _ME(K_DURANTE=K_D)
_me._entropy    = _EA(noise_gap_threshold=NOISE_THRESHOLD, min_tokens=20)
_me._fractal    = _MFP(stability_threshold=K_D, min_series_len=20)
_topo = _TM()
if hasattr(_topo, 'min_sentences'):
    _topo.min_sentences = 2
_me._topology = _topo
DIAGNOSTIC = FullDiagnostic(stability_threshold=K_D)
DIAGNOSTIC.manifold = _me
CONNECTOR  = ApiConnector(base_dir=str(ROOT))
SIGNER     = MetadataOrigin()

# ══════════════════════════════════════════════════════════════
# SESSION STATE
# ══════════════════════════════════════════════════════════════

def _init_state():
    defaults = {
        "report":            None,
        "signed_report":     None,
        "raw_text":          "",
        "clean_text":        "",
        "scan_log":          [],
        "sealed":            False,
        "scan_count":        0,
        # v2.0
        "cert_path":         None,       # Path to last generated PDF
        "cert_bytes":        None,       # Bytes del PDF para descarga
        "clip_alerts":       [],         # Alertas del Clipboard Shield
        "clip_shield_on":    False,      # Shield state
        "clip_stop_event":   None,       # threading.Event para detenerlo
        "plag_report":       None,       # Last PlagiarismReport
        "plag_code":         "",         # Analyzed suspicious code
        # v3.0 (legacy)
        "ghost_report":      None,       # GhostAuditReport del texto actual
        "shadow_report":     None,       # ShadowCodeReport
        "shadow_code":       "",         # Code analyzed by Shadow
        "anchor_data":       None,       # Payload del Ancla de Identidad
        # v5.5 wizard (legacy)
        "wizard_done":       False,      # True once onboarding is complete
        "node_lens":         "FULL",     # MACHINE | HUMAN | FULL
        "kd_calibrated":     0.56,       # κD calibrado por el usuario
        "sigma_threshold":   0.05,       # σ threshold for manifold degradation
        "entropy_sens":      0.15,       # entropy sensitivity (clipboard)
        # v2.0 new modules
        "diff_report":       None,       # SemanticDiffReport
        "batch_report":      None,       # BatchReport
        "ledger_entry":      None,       # LedgerEntry of the last diagnostic
        "stream_events":     [],         # ShieldEvents history
        "stream_score_hist": [],         # monitor score history
        "kd_live":           0.56,       # κD activo (puede ser ajustado por slider)
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

_init_state()

# ══════════════════════════════════════════════════════════════
# INITIALIZATION WIZARD v5.5 (runs only on first access)
# ══════════════════════════════════════════════════════════════

if not st.session_state["wizard_done"]:
    st.markdown("""
    <style>
    .stApp { background: #000 !important; }
    .wz-title { text-align:center; font-family:Orbitron,monospace;
                font-size:1.55rem; color:#FFB100; letter-spacing:.25em;
                text-shadow:0 0 18px rgba(255,177,0,.55);
                padding:2.5rem 0 .4rem; }
    .wz-sub   { text-align:center; font-size:.7rem;
                color:rgba(255,177,0,.4); letter-spacing:.15em;
                margin-bottom:2rem; }
    .wz-box   { background:#0D0D0D; border:1px solid rgba(255,177,0,.2);
                border-radius:6px; padding:1.4rem 1.6rem; margin-bottom:1rem; }
    .wz-label { font-family:Orbitron,monospace; font-size:.75rem;
                color:#FFB100; letter-spacing:.12em; margin-bottom:.7rem; }
    </style>
    """, unsafe_allow_html=True)

    st.markdown('<div class="wz-title">⬡ OMNI-SCANNER SEMANTIC v2.0</div>',
                unsafe_allow_html=True)
    st.markdown('<div class="wz-sub">SESSION INITIALIZATION · PARAMETER CALIBRATION</div>',
                unsafe_allow_html=True)

    _, wzcol, _ = st.columns([1, 2, 1])
    with wzcol:

        # ── PASO 1 ───────────────────────────────────────────
        st.markdown('<div class="wz-box"><div class="wz-label">STEP 1 · NODE IDENTIFICATION</div>',
                    unsafe_allow_html=True)
        node_map = {
            "🖥  MACHINE — Manifold · Shadow-Code · Gaslighting": "MACHINE",
            "👤  HUMAN  — Contratos · NDAs · Delay Tactics":      "HUMAN",
            "⬡  FULL   — Complete pipeline (all modules)":  "FULL",
        }
        node_choice = st.radio("nodo", list(node_map.keys()),
                               index=2, label_visibility="collapsed")
        st.markdown('</div>', unsafe_allow_html=True)

        # ── PASO 2 ───────────────────────────────────────────
        st.markdown('<div class="wz-box"><div class="wz-label">STEP 2 · PARAMETER CALIBRATION</div>',
                    unsafe_allow_html=True)
        c1, c2 = st.columns(2)
        with c1:
            kd_val = st.slider("κD — Stability constant",
                               0.40, 0.80, 0.56, 0.01,
                               help="Umbral ManifoldEngine. Referencia: 0.56")
        with c2:
            sigma_pct = st.slider("σ — Degradation threshold (%)",
                                  1, 30, 5, 1)
            sigma_val = sigma_pct / 100.0
        c3, _ = st.columns(2)
        with c3:
            ent_sens = st.slider("Entropy sensitivity (Clipboard)",
                                 0.05, 0.50, 0.15, 0.01)

        thr2 = sigma_val * 3
        st.markdown(f"""
        <div style="font-size:.62rem;color:rgba(255,177,0,.5);
                    font-family:Share Tech Mono,monospace;
                    line-height:2;margin-top:.5rem;">
        σ &lt; {sigma_val:.0%} &nbsp;→&nbsp;
        <span style="color:#00FF88">SOVEREIGN STABILITY</span><br>
        σ {sigma_val:.0%}–{thr2:.0%} &nbsp;→&nbsp;
        <span style="color:#FFB100">DEGRADATION</span><br>
        σ &gt; {thr2:.0%} &nbsp;→&nbsp;
        <span style="color:#FF2D2D">MANIFOLD COLLAPSE</span>
        </div>
        """, unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)

        # ── STEP 3 ────────────────────────────────────────────
        st.markdown('<div class="wz-box"><div class="wz-label">STEP 3 · CONFIRM AND START</div>',
                    unsafe_allow_html=True)
        st.markdown(f"""
        <div style="font-size:.68rem;color:rgba(255,177,0,.65);
                    font-family:Share Tech Mono,monospace;line-height:2;">
        NODE &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {node_map[node_choice]}<br>
        κD &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {kd_val}<br>
        σ THRESHOLD &nbsp; {sigma_val:.0%}<br>
        ENTROPY &nbsp; {ent_sens}<br>
        PROTOCOL ANEXA ULTRA v4.0
        </div>
        """, unsafe_allow_html=True)
        if st.button("⬡  START AUDIT SESSION",
                     use_container_width=True, type="primary"):
            st.session_state.update({
                "wizard_done":     True,
                "node_lens":       node_map[node_choice],
                "kd_calibrated":   kd_val,
                "sigma_threshold": sigma_val,
                "entropy_sens":    ent_sens,
            })
            # Recalibrar motores en vivo
            try:
                if hasattr(_me._entropy, '_noise_gap_threshold'):
                    _me._entropy._noise_gap_threshold = ent_sens
                if hasattr(_me._fractal, '_stability_threshold'):
                    _me._fractal._stability_threshold = kd_val
            except Exception:
                pass
            st.rerun()
        st.markdown('</div>', unsafe_allow_html=True)

    st.stop()  # Do not render anything else until wizard is complete


# ══════════════════════════════════════════════════════════════
# VISUALIZATION HELPERS
# ══════════════════════════════════════════════════════════════

def _verdict_css(verdict: str) -> str:
    return {
        "CLEAR":     "verdict-clear",
        "REVIEW":    "verdict-review",
        "HIGH_RISK": "verdict-highrisk",
    }.get(verdict, "verdict-review")


def _badge(text: str, kind: str = "review") -> str:
    return f'<span class="badge badge-{kind}">{text}</span>'


def _metric_card(label: str, value: str, delta: str = "",
                 kind: str = "const") -> str:
    return f"""
    <div class="metric-card">
        <div class="metric-label">{label}</div>
        <div class="metric-value {kind}">{value}</div>
        {"<div class='metric-delta'>" + delta + "</div>" if delta else ""}
    </div>
    """


def _stability_bar(score: float, risk: bool = False) -> str:
    pct = max(0, min(100, score * 100))
    cls = "risk" if risk else ""
    return f"""
    <div class="stability-bar">
        <div class="stability-fill {cls}" style="width:{pct:.1f}%"></div>
    </div>
    <div style="font-size:0.65rem;color:var(--text-dim);margin-top:2px;">
        Score: {score:.4f}
    </div>
    """


def _log(msg: str, level: str = "warn") -> None:
    ts = datetime.datetime.now().strftime("%H:%M:%S")
    st.session_state["scan_log"].append(
        f'<span class="log-{level}">[{ts}] {msg}</span>'
    )


# ══════════════════════════════════════════════════════════════
# PLOTLY CHARTS
# ══════════════════════════════════════════════════════════════

AMBER = "#FFB100"
RED   = "#FF2D2D"
GREEN = "#00FF88"
BG    = "#000000"
PANEL = "#0D0D0D"

_PLOTLY_LAYOUT = dict(
    paper_bgcolor=BG,
    plot_bgcolor=PANEL,
    font=dict(family="IBM Plex Mono, monospace", color=AMBER, size=10),
    margin=dict(l=10, r=10, t=40, b=10),
)


def build_topology_3d(report: FullDiagnosticReport) -> go.Figure:
    """
    3D surface representing the semantic topology of the latent space.
    Axes: Entropy × Fractal Dimension × ManifoldScore
    Zonas de Mala Fe (score < 0.3) pulsantes en rojo.
    """
    score = report.manifold_score if not math.isnan(report.manifold_score) else 0.0
    if score < 0 or score == -1.0:
        score = 0.0
    coherence = max(report.coherence_score, 0.0)
    risk = max(report.domain_risk, 0.0)

    # Grid del manifold
    x = np.linspace(0, 1, 40)
    y = np.linspace(0, 2, 40)
    X, Y = np.meshgrid(x, y)

    # Surface = Gaussian projection of the real analysis point
    # centrada en (entropy_norm, higuchi_dim_norm)
    raw_reports = report.raw_reports
    try:
        manifold_txt = raw_reports.get("manifold_summary", "")
        higuchi = float(
            next((l.split(":")[1].strip().split()[0]
                  for l in manifold_txt.split("\n") if "Higuchi" in l), "1.5")
        )
    except Exception:
        higuchi = 1.5

    cx = min(risk, 1.0)
    cy = min(higuchi / 2.0, 1.0) * 2

    # Z: always generates visual relief using risk and fractal dimension
    # even if manifold_score is low. Minimum amplitude guaranteed.
    sigma = 0.35
    rng = np.random.default_rng(42)
    Z_gauss = np.exp(-((X - cx)**2 + (Y - cy)**2) / (2 * sigma**2))
    Z_noise = 0.12 * rng.standard_normal(X.shape)
    # Minimum amplitude 0.35 so the surface never stays flat
    amplitude = max(score, 0.35) + risk * 0.4
    Z = Z_gauss * amplitude + Z_noise * 0.4 + 0.1

    # Bad faith peaks: if critical findings, insert red spikes
    domain_data = raw_reports.get("domain", {})
    n_findings  = len(domain_data.get("critical_findings", []))
    if n_findings > 0:
        for i in range(min(n_findings, 3)):
            px_ = rng.uniform(0.6, 0.95)
            py_ = rng.uniform(0.8, 1.6)
            spike = 0.5 * np.exp(-((X - px_)**2 + (Y - py_)**2) / 0.02)
            Z += spike

    # Color: rojo en zonas de mala fe (Z alto + riesgo alto)
    colorscale = [
        [0.0,  "#001A00"],
        [0.35, "#1A3300"],
        [0.55, AMBER],
        [0.80, "#FF6600"],
        [1.0,  RED],
    ] if risk > 0.3 else [
        [0.0,  "#001A00"],
        [0.40, "#003311"],
        [0.70, AMBER],
        [1.0,  "#FFD966"],
    ]

    fig = go.Figure(data=[go.Surface(
        x=X, y=Y, z=Z,
        colorscale=colorscale,
        showscale=False,
        opacity=0.88,
        contours=dict(
            z=dict(show=True, usecolormap=True,
                   highlightcolor=RED if risk > 0.3 else AMBER,
                   project_z=True)
        ),
    )])

    # Real analysis point
    fig.add_trace(go.Scatter3d(
        x=[cx], y=[cy], z=[score],
        mode="markers+text",
        marker=dict(size=8, color=RED if risk > 0.3 else GREEN,
                    symbol="diamond",
                    line=dict(color=AMBER, width=2)),
        text=[f"κD={K_D}"],
        textfont=dict(color=AMBER, size=9),
    ))

    # Plano de estabilidad κD
    fig.add_trace(go.Surface(
        x=X, y=Y,
        z=np.full_like(Z, K_D),
        colorscale=[[0, "rgba(255,177,0,0.04)"], [1, "rgba(255,177,0,0.04)"]],
        showscale=False, opacity=0.25,
    ))

    fig.update_layout(
        **_PLOTLY_LAYOUT,
        title=dict(text="LATENT SPACE TOPOLOGY", font=dict(size=11, color=AMBER)),
        scene=dict(
            xaxis=dict(title="RISK / ENTROPY", color=AMBER,
                       gridcolor="rgba(255,177,0,0.15)", showbackground=False),
            yaxis=dict(title="FRACTAL DIM.", color=AMBER,
                       gridcolor="rgba(255,177,0,0.15)", showbackground=False),
            zaxis=dict(title="MANIFOLD SCORE", color=AMBER,
                       gridcolor="rgba(255,177,0,0.15)", showbackground=False,
                       range=[0, 1]),
            bgcolor=BG,
            camera=dict(eye=dict(x=1.4, y=1.4, z=0.9)),
        ),
        height=440,
    )
    return fig


def build_hausdorff_chart(report: FullDiagnosticReport) -> go.Figure:
    """
    Semantic roughness chart: simulates the Hausdorff dimension curve
    across scales, using real report data.
    """
    raw = report.raw_reports
    try:
        manifold_txt = raw.get("manifold_summary", "")
        higuchi = float(
            next((l.split(":")[1].strip().split()[0]
                  for l in manifold_txt.split("\n") if "Higuchi" in l), "1.5")
        )
    except Exception:
        higuchi = 1.5

    # Simulated log-log curve based on real dimension
    rng = np.random.default_rng(42)
    scales = np.logspace(-1, 1, 30)
    # N(s) ~ s^(-D)  con ruido realista
    counts = scales ** (-higuchi) * (1 + 0.06 * rng.standard_normal(30))
    counts = np.clip(counts, 0.01, None)

    # Reference: ideal dimension 1.58
    ref_counts = scales ** (-1.58)

    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=np.log(1 / scales), y=np.log(counts),
        mode="lines+markers",
        name=f"Hausdorff estimado (D={higuchi:.3f})",
        line=dict(color=AMBER, width=2),
        marker=dict(size=4, color=AMBER),
    ))

    fig.add_trace(go.Scatter(
        x=np.log(1 / scales), y=np.log(ref_counts),
        mode="lines",
        name="Referencia (D=1.58)",
        line=dict(color="rgba(255,177,0,0.30)", width=1, dash="dot"),
    ))

    # Zona de estabilidad κD
    fig.add_hrect(
        y0=np.log(scales[0] ** (-K_D)) * 0.85,
        y1=np.log(scales[0] ** (-K_D)) * 1.15,
        fillcolor="rgba(255,177,0,0.04)",
        line_width=0,
        annotation_text=f"κD={K_D} ± 15%",
        annotation_font=dict(color=AMBER, size=8),
    )

    fig.update_layout(
        **_PLOTLY_LAYOUT,
        title=dict(text="HAUSDORFF SEMANTIC ROUGHNESS", font=dict(size=11, color=AMBER)),
        xaxis=dict(title="log(1/escala)", color=AMBER,
                   gridcolor="rgba(255,177,0,0.10)", showgrid=True),
        yaxis=dict(title="log(N(s))", color=AMBER,
                   gridcolor="rgba(255,177,0,0.10)", showgrid=True),
        legend=dict(font=dict(size=8, color=AMBER),
                    bgcolor="rgba(0,0,0,0.6)", bordercolor=AMBER, borderwidth=1),
        height=300,
    )
    return fig


def build_risk_radar(report: FullDiagnosticReport) -> go.Figure:
    """Risk signal radar by dimension."""
    domain = report.raw_reports.get("domain", {})

    legal_risk    = domain.get("legal_risk_score",    report.domain_risk)
    gaslighting   = domain.get("gaslighting_score",   domain.get("risk_score", 0))
    coherence_inv = 1.0 - report.coherence_score
    manifold_gap  = 1.0 - max(report.manifold_score, 0)
    plagiarism    = domain.get("plagiarism_risk", 0) / 100 if "plagiarism_risk" in domain else 0

    categories = ["LEGAL", "GASLIGHTING", "FRAGMENTATION", "MANIFOLD\nANOMALY", "PLAGIARISM"]
    values = [legal_risk, gaslighting, coherence_inv, manifold_gap, plagiarism]
    values_closed = values + [values[0]]
    categories_closed = categories + [categories[0]]

    color = RED if report.overall_verdict == "HIGH_RISK" else AMBER

    fig = go.Figure(go.Scatterpolar(
        r=values_closed,
        theta=categories_closed,
        fill="toself",
        fillcolor=f"rgba(255,177,0,0.08)" if color == AMBER else "rgba(255,45,45,0.10)",
        line=dict(color=color, width=2),
        marker=dict(color=color, size=6),
    ))

    fig.update_layout(
        **_PLOTLY_LAYOUT,
        title=dict(text="RISK SIGNALS", font=dict(size=11, color=AMBER)),
        polar=dict(
            bgcolor=PANEL,
            radialaxis=dict(visible=True, range=[0, 1],
                            color=AMBER, gridcolor="rgba(255,177,0,0.12)",
                            tickfont=dict(size=8)),
            angularaxis=dict(color=AMBER, gridcolor="rgba(255,177,0,0.15)",
                             tickfont=dict(size=8)),
        ),
        height=320,
    )
    return fig


# ══════════════════════════════════════════════════════════════
# SIDEBAR
# ══════════════════════════════════════════════════════════════

with st.sidebar:
    st.markdown("""
    <div style="font-size:0.65rem;color:rgba(255,177,0,0.4);
                letter-spacing:0.18em;border-bottom:1px solid rgba(255,177,0,0.2);
                padding-bottom:0.6rem;margin-bottom:1rem;">
    ⬡ SYSTEM / CONFIGURATION
    </div>
    """, unsafe_allow_html=True)

    input_type = st.selectbox(
        "DOCUMENT TYPE",
        options=["legal", "code", "discourse", "finance", "generic"],
        index=0,
        help="Select the domain analysis engine."
    )

    # ── SLIDER MAESTRO κD ──────────────────────────────────────
    st.markdown("""
    <div style="margin-top:0.8rem;font-size:0.62rem;color:#FFB100;
                letter-spacing:0.14em;margin-bottom:0.3rem;">
    ⬡ DURANTE EQUILIBRIUM POINT — κD
    </div>
    """, unsafe_allow_html=True)

    kd_slider = st.slider(
        "κD",
        min_value=0.40,
        max_value=0.80,
        value=float(st.session_state.get("kd_live", 0.56)),
        step=0.01,
        format="%.2f",
        label_visibility="collapsed",
        key="kd_master_slider",
        help="Semantic invariance threshold. 0.56 = Durante Equilibrium Point.",
    )
    st.session_state["kd_live"] = kd_slider
    K_D_LIVE = kd_slider

    # Indicador visual del slider
    _kd_zone = (
        "🟡 ZONA DE RUIDO" if kd_slider < 0.48
        else "🟢 DURANTE EQUILIBRIUM" if abs(kd_slider - 0.56) < 0.02
        else "🔴 OVER-RESTRICTION" if kd_slider > 0.72
        else "🟡 TENSION ZONE"
    )
    _kd_color = "#00CC66" if abs(kd_slider - 0.56) < 0.02 else "#FFB100"
    st.markdown(f"""
    <div style="display:flex;align-items:center;justify-content:space-between;
                font-size:0.60rem;margin-bottom:0.2rem;">
        <span style="color:{_kd_color};font-family:monospace;font-weight:700;
                     font-size:0.85rem;">κD = {kd_slider:.2f}</span>
        <span style="color:rgba(255,177,0,0.55);">{_kd_zone}</span>
    </div>
    """, unsafe_allow_html=True)

    # Visual slider bar with golden line at 0.56
    _pct_cur = (kd_slider - 0.40) / (0.80 - 0.40) * 100
    _pct_056 = (0.56 - 0.40) / (0.80 - 0.40) * 100
    st.markdown(f"""
    <div style="position:relative;height:6px;background:rgba(255,177,0,0.12);
                border-radius:3px;margin-bottom:0.8rem;">
        <div style="position:absolute;left:0;top:0;height:100%;
                    width:{_pct_cur:.1f}%;background:{_kd_color};
                    border-radius:3px;opacity:0.7;"></div>
        <div style="position:absolute;top:-3px;left:{_pct_056:.1f}%;
                    width:2px;height:12px;background:#FFB100;
                    box-shadow:0 0 4px rgba(255,177,0,0.8);"></div>
    </div>
    """, unsafe_allow_html=True)

    if abs(kd_slider - 0.56) > 0.02:
        st.markdown(
            f'<div style="font-size:0.57rem;color:rgba(255,177,0,0.45);">'
            f'⚠ Moving away from κD=0.56 — probabilistic noise zone</div>',
            unsafe_allow_html=True,
        )
    else:
        st.markdown(
            '<div style="font-size:0.57rem;color:rgba(0,204,102,0.6);">'
            '◆ κD at Durante Equilibrium Point</div>',
            unsafe_allow_html=True,
        )

    st.markdown("---")
    st.markdown(f"""
    <div style="font-size:0.65rem;color:rgba(255,177,0,0.4);letter-spacing:0.14em;">
    ACTIVE PARAMETERS
    </div>
    <div style="font-size:0.72rem;color:rgba(255,177,0,0.7);margin-top:0.5rem;line-height:1.9;">
    κD (stability)  <strong style="color:#FFB100">{kd_slider:.2f}</strong><br>
    Max gap        <strong style="color:#FFB100">{NOISE_THRESHOLD}</strong><br>
    Plagiarism threshold     <strong style="color:#FFB100">{PLAGIARISM_THRESHOLD}</strong><br>
    Protocolo         <strong style="color:#FFB100">ANEXA Ultra v4.0</strong>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown(f"""
    <div style="font-size:0.65rem;color:rgba(255,177,0,0.4);letter-spacing:0.14em;">
    SESSION STATUS
    </div>
    <div style="font-size:0.72rem;color:rgba(255,177,0,0.6);margin-top:0.5rem;line-height:1.9;">
    Scans         <strong style="color:#FFB100">{st.session_state['scan_count']}</strong><br>
    Sealed         <strong style="color:#FFB100">{'YES' if st.session_state['sealed'] else 'NO'}</strong>
    </div>
    """, unsafe_allow_html=True)

    if st.button("⟳  RESET SESSION"):
        for k in list(st.session_state.keys()):
            del st.session_state[k]
        _init_state()
        st.rerun()

    # ── MODULE 1: Clipboard Shield ───────────────────────────────
    st.markdown("---")
    st.markdown(f"""
    <div style="font-size:0.65rem;color:rgba(255,177,0,0.4);letter-spacing:0.14em;">
    CLIPBOARD SHIELD v2.0
    </div>
    """, unsafe_allow_html=True)

    shield_on  = st.session_state.get("clip_shield_on", False)
    shield_avail = pyperclip_available()

    if not shield_avail:
        st.markdown("""
        <div style="font-size:0.65rem;color:rgba(255,100,0,0.7);margin-top:0.4rem;">
        ⚠ Install pyperclip:<br><code>pip install pyperclip</code>
        </div>
        """, unsafe_allow_html=True)
    else:
        _shield_label = "⬛ STOP SHIELD" if shield_on else "⬡ ACTIVATE SHIELD"
        if st.button(_shield_label, use_container_width=True):
            if shield_on:
                stop_ev = st.session_state.get("clip_stop_event")
                if stop_ev:
                    stop_shield(stop_ev)
                st.session_state["clip_shield_on"]  = False
                st.session_state["clip_stop_event"] = None
                _log("Clipboard Shield desactivado.", "dim")
            else:
                alerts_queue = st.session_state["clip_alerts"]
                stop_ev = start_shield(alerts_queue, threshold=NOISE_THRESHOLD, poll_interval=2.5)
                st.session_state["clip_shield_on"]  = True
                st.session_state["clip_stop_event"] = stop_ev
                _log("Clipboard Shield activated. Monitoring entropy...", "ok")
            st.rerun()

        _status_color = "#00FF88" if shield_on else "rgba(255,177,0,0.3)"
        _status_text  = "ACTIVE" if shield_on else "INACTIVE"
        st.markdown(f"""
        <div style="font-size:0.65rem;color:{_status_color};
                    letter-spacing:0.1em;margin-top:0.3rem;">
        ● {_status_text}
        {"· Threshold gap: " + str(NOISE_THRESHOLD) if shield_on else ""}
        </div>
        """, unsafe_allow_html=True)

        if st.session_state.get("clip_alerts"):
            nalerts = len(st.session_state["clip_alerts"])
            st.markdown(f"""
            <div style="font-size:0.65rem;color:#FF2D2D;animation:pulse 1s infinite;">
            ⚠ {nalerts} alerta(s) pendiente(s)
            </div>
            """, unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════
# HEADER PRINCIPAL
# ══════════════════════════════════════════════════════════════

st.markdown("""
<div class="omni-header">
  <div class="omni-title flicker">⬡ OMNI-SCANNER SEMANTIC v2.0</div>
  <div class="omni-subtitle cursor">
    SEMANTIC AUDIT SYSTEM · INFORMATION PHYSICS · ORIGIN NODE ACTIVE
  </div>
</div>
""", unsafe_allow_html=True)

# ── Clipboard Shield: mostrar alertas pendientes ──────────────
_clip_alerts: list[dict] = st.session_state.get("clip_alerts", [])
if _clip_alerts:
    for _alert in _clip_alerts:
        _level = _alert.get("level", "MEDIUM")
        _gap   = _alert.get("gap", 0)
        _prev  = _alert.get("preview", "")[:60]
        _msg   = f"⚠ CLIPBOARD SHIELD: Entropy gap {_gap:.3f} [{_level}] · {_prev}..."
        st.toast(_msg, icon="⚠")
    # Clear after showing (avoid spam on reruns)
    st.session_state["clip_alerts"] = []


# ── Monitor de Invarianza (KPI row) ───────────────────────────
report: FullDiagnosticReport | None = st.session_state["report"]

gaslighting_val = "—"
gaslighting_kind = "const"
if report:
    domain = report.raw_reports.get("domain", {})
    gas = domain.get("gaslighting_score", domain.get("risk_score", None))
    if gas is not None:
        gaslighting_val = f"{gas:.4f}"
        gaslighting_kind = "risk" if gas > 0.3 else ("warn" if gas > 0.1 else "ok")

nist_status = "SYNCHRONIZED" if report else "STANDBY"
nist_kind   = ("ok" if report and report.overall_verdict == "CLEAR"
               else "risk" if report and report.overall_verdict == "HIGH_RISK"
               else "const")

c1, c2, c3 = st.columns(3)
with c1:
    st.markdown(_metric_card("κD — STABILITY CONSTANT", f"{K_D}", "Semantic invariance", "const"),
                unsafe_allow_html=True)
with c2:
    st.markdown(_metric_card("GASLIGHTING INDEX", gaslighting_val,
                             "Discursive manipulation detected", gaslighting_kind),
                unsafe_allow_html=True)
with c3:
    st.markdown(_metric_card("NIST/TAD STATUS", nist_status,
                             f"Protocol: ANEXA Ultra v4.0", nist_kind),
                unsafe_allow_html=True)

st.markdown("<div style='margin-top:1.4rem'></div>", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════
# TABS PRINCIPALES
# ══════════════════════════════════════════════════════════════

tab_scan, tab_viz, tab_vault, tab_plag, tab_shadow, tab_ledger, tab_diff, tab_batch, tab_monitor, tab_log = st.tabs([
    "⬡  AUDIT TERMINAL",
    "◈  LATENT SPACE",
    "⬥  EVIDENCE VAULT",
    "⬣  ORDER INJECTOR",
    "◉  SHADOW-CODE",
    "▦  INVARIANCE LEDGER",
    "◑  SEMANTIC DIFF",
    "≣  FORENSIC AUDIT",
    "⚙  ACTIVE SURVEILLANCE",
    "⬦  SYSTEM LOG",
])


# ══════════════════════════════════════════════════════════════
# TAB 1: AUDIT TERMINAL
# ══════════════════════════════════════════════════════════════

with tab_scan:
    col_input, col_result = st.columns([1, 1], gap="medium")

    with col_input:
        st.markdown("""
        <div class="section-title"><span>▸</span> DATA INPUT</div>
        """, unsafe_allow_html=True)

        upload_mode = st.radio(
            "Fuente",
            ["File", "Direct text"],
            horizontal=True,
            label_visibility="collapsed",
        )

        raw_text = ""

        if upload_mode == "File":
            uploaded = st.file_uploader(
                "Drag your document here",
                type=["txt", "py", "md", "json", "csv"],
                label_visibility="collapsed",
            )
            if uploaded:
                try:
                    raw_text = uploaded.read().decode("utf-8", errors="replace")
                    st.markdown(
                        f'<div class="hash-display"><strong>File:</strong> {uploaded.name} '
                        f'({len(raw_text):,} chars)</div>',
                        unsafe_allow_html=True,
                    )
                except Exception as e:
                    st.error(f"Error leyendo archivo: {e}")
        else:
            raw_text = st.text_area(
                "Ingrese texto a auditar",
                height=200,
                placeholder="Paste the contract, code or discourse to analyze here...",
                label_visibility="collapsed",
            )

            # ── Ghost Audit: inline real-time analysis ─────────────
            if raw_text and len(raw_text.strip()) > 40:
                _ghost = GHOST_AUDITOR.analyze(raw_text)
                st.session_state["ghost_report"] = _ghost
                if _ghost.alert_level != "SALUDABLE" and _ghost.alert_level != "INSUFICIENTE":
                    _ghost_colors = {
                        "CRITICAL DEGRADATION": "#FF2D2D",
                        "SEMANTIC RISK":    "#FF6600",
                        "POTENCIAL REDUCIDO":  "#FFB100",
                    }
                    _gc = _ghost_colors.get(_ghost.alert_level, "#FFB100")
                    st.markdown(f"""
                    <div style="border-left:3px solid {_gc};padding:.5rem .8rem;
                                margin:.4rem 0;background:rgba(255,45,45,0.05);">
                        <span style="color:{_gc};font-family:Orbitron,monospace;
                                     font-size:.7rem;letter-spacing:.1em;">
                        ⚠ {_ghost.alert_level}
                        </span>
                        <span style="color:rgba(255,177,0,0.6);font-size:.65rem;margin-left:.5rem;">
                        Score: {_ghost.overall_score:.3f} · Buzzwords: {len(_ghost.buzzwords_found)}
                        {"· Templates: " + str(len(_ghost.template_hits)) if _ghost.template_hits else ""}
                        </span>
                        <br><span style="color:rgba(255,177,0,0.45);font-size:.62rem;">
                        {_ghost.recommendation[:120]}
                        </span>
                    </div>
                    """, unsafe_allow_html=True)

        ref_text = ""
        if input_type == "code":
            with st.expander("◈ Prior Art / Reference Code"):
                ref_upload = st.file_uploader("Referencia", type=["py", "txt"],
                                              key="ref_upload")
                if ref_upload:
                    ref_text = ref_upload.read().decode("utf-8", errors="replace")
                    st.caption(f"Referencia: {ref_upload.name}")

        st.markdown("<div style='margin-top:0.8rem'></div>", unsafe_allow_html=True)

        btn_scan = st.button("⬡  EXECUTE MULTIFRACTAL SCAN", use_container_width=True)

        if btn_scan:
            if not raw_text.strip():
                st.warning("No hay contenido para analizar.")
            else:
                with st.spinner("Analyzing latent space..."):
                    try:
                        _log("Starting lexical cleanup...", "dim")
                        clean = CLEANER.clean_for_analysis(raw_text)
                        meta = CLEANER.extract_metadata(clean)
                        st.session_state["raw_text"]   = raw_text
                        st.session_state["clean_text"] = clean

                        _log(f"Tokens limpios: {len(clean.split())} | "
                             f"Refs. legales: {len(meta['legal_references'])}", "dim")

                        _log("Running ManifoldEngine + EntropyAnalyzer...", "warn")
                        result = DIAGNOSTIC.run(clean, input_type=input_type,
                                                reference_code=ref_text)

                        st.session_state["report"]  = result
                        st.session_state["sealed"]  = False
                        st.session_state["scan_count"] += 1

                        CONNECTOR.log_scan(result.__dict__)

                        level = {"CLEAR": "ok", "REVIEW": "warn",
                                 "HIGH_RISK": "risk"}.get(result.overall_verdict, "warn")
                        ms_display = (
                            f"{result.manifold_score:.4f}"
                            if result.manifold_score not in (float("nan"), -1.0)
                            and result.manifold_score == result.manifold_score
                            else "INSUF."
                        )
                        _log(f"Verdict: {result.overall_verdict} | "
                             f"ManifoldScore: {ms_display}", level)
                        _log(f"Confianza: {result.confidence:.1%} | "
                             f"Tipo: {input_type}", "dim")

                        st.rerun()
                    except Exception as e:
                        _log(f"ERROR: {e}", "risk")
                        st.error(f"Error during analysis: {e}")

    with col_result:
        st.markdown("""
        <div class="section-title"><span>▸</span> VERDICT</div>
        """, unsafe_allow_html=True)

        if report is None:
            st.markdown("""
            <div style="color:rgba(255,177,0,0.25);font-size:0.75rem;
                        text-align:center;padding:3rem 1rem;
                        border:1px dashed rgba(255,177,0,0.15);">
            SYSTEM IDLE<br>
            <span style="font-size:0.65rem">Load a document and run the scan</span>
            </div>
            """, unsafe_allow_html=True)
        else:
            # Verdict banner
            v_css = _verdict_css(report.overall_verdict)
            v_icons = {"CLEAR": "✓", "REVIEW": "⚡", "HIGH_RISK": "⚠"}
            st.markdown(f"""
            <div class="verdict-banner {v_css}">
                {v_icons.get(report.overall_verdict,'?')} &nbsp;
                {report.overall_verdict}
            </div>
            """, unsafe_allow_html=True)

            st.markdown("<div style='margin-top:1rem'></div>", unsafe_allow_html=True)

            # Secondary metrics
            mc1, mc2 = st.columns(2)
            with mc1:
                ms_val = report.manifold_score
                ms_valid = ms_val not in (-1.0,) and ms_val == ms_val  # not NaN, not -1
                ms_str = f"{ms_val:.4f}" if ms_valid else "INSUF."
                kind = ("ok" if ms_valid and ms_val > 0.6
                        else "risk" if ms_valid and ms_val < 0.3
                        else "const")
                st.markdown(_metric_card(
                    "MANIFOLD SCORE", ms_str,
                    report.manifold_verdict, kind),
                    unsafe_allow_html=True)
            with mc2:
                coh_kind = "ok" if report.coherence_score > 0.5 else "risk"
                st.markdown(_metric_card(
                    "TOPOLOGICAL COHERENCE",
                    f"{report.coherence_score:.4f}",
                    report.topology_flag, coh_kind),
                    unsafe_allow_html=True)

            st.markdown("<div style='margin-top:0.8rem'></div>", unsafe_allow_html=True)

            # Barra de estabilidad
            ms = report.manifold_score if not math.isnan(report.manifold_score) else 0.0
            st.markdown(
                f'<div class="metric-label">SEMANTIC STABILITY INDEX</div>'
                + _stability_bar(ms, risk=report.overall_verdict == "HIGH_RISK"),
                unsafe_allow_html=True,
            )

            st.markdown("<div style='margin-top:0.8rem'></div>", unsafe_allow_html=True)

            # Manifold analysis detail
            with st.expander("◈ MANIFOLD + ENTROPY DETAIL"):
                summary = report.raw_reports.get("manifold_summary", "Sin datos")
                st.markdown(
                    f'<div class="terminal-output">{summary}</div>',
                    unsafe_allow_html=True,
                )

            # Detalle dominio — con limpieza de regex crudas
            with st.expander("◈ DOMAIN DETAIL"):
                import re as _re
                domain_raw = report.raw_reports.get("domain", {})

                def _clean_regex(val):
                    """Convierte patrones regex a texto legible."""
                    if isinstance(val, str):
                        return _re.sub(r'\\s\+', ' ', _re.sub(r'\\b|\\s\*|\(\?i\)', '', val))
                    if isinstance(val, list):
                        return [_clean_regex(v) for v in val]
                    if isinstance(val, dict):
                        return {k: _clean_regex(v) for k, v in val.items()}
                    return val

                domain_clean = _clean_regex(domain_raw)

                # Display elegante por secciones en lugar de st.json crudo
                findings = domain_clean.get("critical_findings", [])
                traps    = domain_clean.get("trap_clause_hits", [])
                coerce   = domain_clean.get("coercion_hits", [])
                verdict  = domain_clean.get("verdict", "—")
                risk_sc  = domain_clean.get("legal_risk_score", 0)
                entropy  = domain_clean.get("noise_level", 0)

                if findings:
                    st.markdown("**🔴 CRITICAL FINDINGS**")
                    for f in findings:
                        st.markdown(
                            f"<div style='padding:.3rem .8rem;margin:.2rem 0;"
                            f"border-left:3px solid #FF2D2D;color:#FF2D2D;"
                            f"font-size:.75rem;'>{f}</div>",
                            unsafe_allow_html=True)

                if traps:
                    st.markdown("**⚠ TRAP CLAUSES**")
                    for t in traps:
                        st.markdown(
                            f"<div style='padding:.3rem .8rem;margin:.2rem 0;"
                            f"border-left:3px solid #FF6600;color:#FFB100;"
                            f"font-size:.75rem;'>{t}</div>",
                            unsafe_allow_html=True)

                if coerce:
                    st.markdown("**⚡ COERCION PATTERNS**")
                    for c in coerce:
                        st.markdown(
                            f"<div style='padding:.3rem .8rem;margin:.2rem 0;"
                            f"border-left:3px solid #FFB100;color:#CC8D00;"
                            f"font-size:.75rem;'>{c}</div>",
                            unsafe_allow_html=True)

                c_v1, c_v2, c_v3 = st.columns(3)
                c_v1.metric("Domain Verdict",    verdict)
                c_v2.metric("Legal Risk Score", f"{risk_sc:.4f}")
                c_v3.metric("Noise Level (bits)", f"{entropy:.2f}")

            st.markdown("<div style='margin-top:1rem'></div>", unsafe_allow_html=True)

            # Sign and Seal button — Module 2: Genesis Certifier
            if not st.session_state["sealed"]:
                if st.button("⬥  SIGN & SEAL IN EVIDENCE VAULT",
                             use_container_width=True):
                    with st.spinner("Generating cryptographic signature and PDF certificate..."):
                        signed = SIGNER.sign_report(report.__dict__)
                        vault_path = CONNECTOR.export_evidence(
                            signed,
                            label=f"{input_type}_{report.overall_verdict}"
                        )
                        st.session_state["signed_report"] = signed
                        st.session_state["sealed"] = True
                        sig = signed["authorship"]
                        _log(f"Sealed: {vault_path.name}", "ok")
                        _log(f"SHA-256: {sig['content_hash']}", "dim")

                        # ── Generar PDF Certificate ────────────────
                        try:
                            # Obtener figura 3D actual
                            _topo_fig = build_topology_3d(report)
                            cert_path = CERTIFIER.generate(
                                report_dict   = report.__dict__,
                                raw_text      = st.session_state.get("raw_text", ""),
                                signed_report = signed,
                                topology_fig  = _topo_fig,
                                input_type    = input_type,
                            )
                            # ── Identity Anchor v3.0 ──────────────
                            cert_id_for_anchor = Path(cert_path).stem
                            try:
                                anchor_data = SIGNER.embed_identity_anchor(
                                    cert_path,
                                    cert_id=cert_id_for_anchor,
                                )
                                st.session_state["anchor_data"] = anchor_data
                                _log(f"Identity Anchor embedded · Origin: {anchor_data['origin_hash'][:16]}...", "ok")
                            except Exception as _ae:
                                _log(f"Anchor not embedded: {_ae}", "dim")

                            # Guardar bytes para descarga inmediata
                            cert_bytes = cert_path.read_bytes()
                            st.session_state["cert_path"]  = str(cert_path)
                            st.session_state["cert_bytes"] = cert_bytes
                            _log(f"PDF Certificate: {cert_path.name}", "ok")
                        except ImportError as e:
                            _log(f"PDF not generated (fpdf2 not installed): {e}", "dim")
                            st.session_state["cert_path"]  = None
                            st.session_state["cert_bytes"] = None
                        except Exception as e:
                            _log(f"Error generating PDF: {e}", "warn")
                            st.session_state["cert_path"]  = None
                            st.session_state["cert_bytes"] = None

                        # ── Forensic Ledger ────────────────────────
                        try:
                            _ledger_entry = ledger_append(
                                raw_text         = st.session_state.get("raw_text", ""),
                                report_dict      = report.__dict__,
                                authorship       = sig,
                                cert_path        = str(cert_path) if st.session_state.get("cert_path") else None,
                                anchor_data      = st.session_state.get("anchor_data"),
                            )
                            _log(f"Ledger: entry #{ledger_count()} recorded.", "ok")
                        except Exception as _le:
                            _log(f"Ledger error: {_le}", "dim")

                        st.rerun()
            else:
                signed = st.session_state.get("signed_report", {})
                sig = signed.get("authorship", {})
                st.markdown(f"""
                <div class="hash-display">
                    <strong>SEALED BY:</strong> {sig.get('signed_by','—')}<br>
                    <strong>PROTOCOL :</strong> {sig.get('protocol','—')}<br>
                    <strong>TIMESTAMP :</strong> {sig.get('timestamp','—')}<br>
                    <strong>SHA-256   :</strong> {sig.get('content_hash','—')}
                </div>
                """, unsafe_allow_html=True)
                st.markdown(_badge("EVIDENCE SEALED", "ok"), unsafe_allow_html=True)

                # Mostrar Ancla de Identidad si existe
                anchor_data = st.session_state.get("anchor_data")
                if anchor_data:
                    with st.expander("◈ IDENTITY ANCHOR v2.0"):
                        st.markdown(f"""
                        <div class="hash-display" style="font-size:.68rem;">
                        <strong>ORIGIN HASH:</strong> {anchor_data.get('origin_hash','—')[:32]}...<br>
                        <strong>TAD TIMESTAMP:</strong> {anchor_data.get('tad_timestamp','—')}<br>
                        <strong>κD NODE:</strong> {anchor_data.get('nist_node','—')}<br>
                        <strong>PDF SHA-256:</strong> {anchor_data.get('anchored_pdf_sha256','—')[:32]}...<br>
                        <strong>CERT-ID:</strong> {anchor_data.get('cert_id','—')}
                        </div>
                        """, unsafe_allow_html=True)
                        st.markdown(
                            _badge("XMP METADATA EMBEDDED IN PDF", "ok"),
                            unsafe_allow_html=True
                        )

                # PDF download button if available
                cert_bytes = st.session_state.get("cert_bytes")
                cert_path  = st.session_state.get("cert_path")

                # Fix: if cert_bytes was lost in serialization, re-read from file
                if not cert_bytes and cert_path:
                    try:
                        _cp = Path(cert_path)
                        if _cp.exists():
                            cert_bytes = _cp.read_bytes()
                            st.session_state["cert_bytes"] = cert_bytes
                    except Exception:
                        pass

                if cert_bytes:
                    cert_name = Path(cert_path).name if cert_path else "genesis_cert.pdf"
                    st.download_button(
                        label     = "⬇  DOWNLOAD PDF CERTIFICATE",
                        data      = cert_bytes,
                        file_name = cert_name,
                        mime      = "application/pdf",
                        use_container_width=True,
                    )
                    st.markdown(
                        _badge("GENESIS CERTIFICATE GENERATED", "ok"),
                        unsafe_allow_html=True
                    )
                else:
                    st.markdown(
                        '<div style="font-size:0.7rem;color:rgba(255,177,0,0.4);margin-top:0.5rem;">'
                        'PDF unavailable — install fpdf2: <code>pip install fpdf2 kaleido</code>'
                        '</div>',
                        unsafe_allow_html=True
                    )


# ══════════════════════════════════════════════════════════════
# TAB 2: LATENT SPACE (Visualizations)
# ══════════════════════════════════════════════════════════════

with tab_viz:
    if report is None:
        st.markdown("""
        <div style="color:rgba(255,177,0,0.25);font-size:0.75rem;
                    text-align:center;padding:4rem 1rem;">
        RUN A SCAN TO VISUALIZE THE LATENT SPACE
        </div>
        """, unsafe_allow_html=True)
    else:
        st.markdown("""
        <div class="section-title"><span>▸</span> LATENT SPACE VISUALIZER</div>
        """, unsafe_allow_html=True)

        # Main 3D chart
        st.plotly_chart(build_topology_3d(report),
                        use_container_width=True, key="chart_3d")

        col_hd, col_radar = st.columns([3, 2], gap="medium")
        with col_hd:
            st.markdown("""
            <div class="section-title"><span>▸</span>
            RUGOSIDAD DE HAUSDORFF</div>
            """, unsafe_allow_html=True)
            st.plotly_chart(build_hausdorff_chart(report),
                            use_container_width=True, key="chart_hd")

        with col_radar:
            st.markdown("""
            <div class="section-title"><span>▸</span>
            RADAR DE RIESGO</div>
            """, unsafe_allow_html=True)
            st.plotly_chart(build_risk_radar(report),
                            use_container_width=True, key="chart_radar")

        # Topology metrics
        topo = report.raw_reports.get("topology", {})
        if topo:
            st.markdown("""
            <div class="section-title" style="margin-top:1rem">
            <span>▸</span> TOPOLOGICAL METRICS</div>
            """, unsafe_allow_html=True)
            t1, t2, t3, t4 = st.columns(4)
            with t1:
                st.markdown(_metric_card("NODOS", str(topo.get("node_count","—")),
                                         "Unidades de pensamiento"), unsafe_allow_html=True)
            with t2:
                st.markdown(_metric_card("ARISTAS", str(topo.get("edge_count","—")),
                                         "Logical connections"), unsafe_allow_html=True)
            with t3:
                comp = topo.get("components", 1)
                comp_kind = "risk" if comp > 3 else "ok"
                st.markdown(_metric_card("COMPONENTES", str(comp),
                                         "Logical fragmentation", comp_kind),
                            unsafe_allow_html=True)
            with t4:
                circ = topo.get("circular_logic_detected", False)
                st.markdown(_metric_card("CIRCULAR LOGIC",
                                         "YES" if circ else "NO",
                                         "Cyclic argument",
                                         "risk" if circ else "ok"),
                            unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════
# TAB 3: EVIDENCE VAULT
# ══════════════════════════════════════════════════════════════

with tab_vault:
    st.markdown("""
    <div class="section-title"><span>▸</span> EVIDENCE VAULT</div>
    """, unsafe_allow_html=True)

    vault_dir = ROOT / "logs" / "evidence_vault"
    vault_files = sorted(vault_dir.glob("*.json"), reverse=True) \
        if vault_dir.exists() else []

    # Filtrar manifests
    evidence_files = [f for f in vault_files if ".manifest." not in f.name]

    if not evidence_files:
        st.markdown("""
        <div style="color:rgba(255,177,0,0.25);font-size:0.75rem;
                    text-align:center;padding:2rem;">
        EMPTY VAULT — SEAL EVIDENCE FROM THE AUDIT TERMINAL
        </div>
        """, unsafe_allow_html=True)
    else:
        # Construir tabla
        rows = []
        for f in evidence_files:
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                manifest_f = vault_dir / (f.name + ".manifest.json")
                sha = ""
                if manifest_f.exists():
                    m = json.loads(manifest_f.read_text())
                    sha = m.get("sha256", "")[:20] + "..."

                verdict  = data.get("overall_verdict", data.get("verdict", "N/A"))
                inp_type = data.get("input_type", "—")
                score    = data.get("manifold_score", "—")
                ts       = f.name[:15].replace("_", " ")
                auth     = data.get("authorship", {}).get("signed_by", "—")

                rows.append({
                    "Timestamp":      ts,
                    "Type":           inp_type,
                    "Verdict":        verdict,
                    "ManifoldScore":  f"{score:.4f}" if isinstance(score, float) else score,
                    "Signed by":      auth,
                    "SHA-256":        sha,
                    "File":           f.name,
                })
            except Exception:
                continue

        if rows:
            import pandas as pd
            df = pd.DataFrame(rows)
            st.dataframe(
                df.drop(columns=["File"]),
                use_container_width=True,
                hide_index=True,
            )

            # Selector para ver detalles
            selected = st.selectbox(
                "Ver detalle de evidencia:",
                options=[r["File"] for r in rows],
                format_func=lambda x: x[:50],
            )
            if selected:
                sel_path = vault_dir / selected
                try:
                    sel_data = json.loads(sel_path.read_text(encoding="utf-8"))
                    with st.expander(f"◈ DETAIL: {selected}"):
                        st.json(sel_data)

                    # Exportar JSON
                    st.download_button(
                        label="⬇  EXPORT EVIDENCE (JSON)",
                        data=json.dumps(sel_data, default=str, indent=2),
                        file_name=selected,
                        mime="application/json",
                    )
                except Exception as e:
                    st.error(f"Error leyendo evidencia: {e}")

        col_stats1, col_stats2, col_stats3 = st.columns(3)
        with col_stats1:
            st.markdown(_metric_card("TOTAL SEALED", str(len(evidence_files)),
                                     "Evidence in vault"), unsafe_allow_html=True)
        with col_stats2:
            high_risk = sum(1 for r in rows if r["Verdict"] == "HIGH_RISK")
            st.markdown(_metric_card("HIGH_RISK", str(high_risk),
                                     "Critical documents",
                                     "risk" if high_risk > 0 else "ok"),
                        unsafe_allow_html=True)
        with col_stats3:
            clear = sum(1 for r in rows if r["Verdict"] == "CLEAR")
            st.markdown(_metric_card("LIMPIOS", str(clear),
                                     "No anomalies detected", "ok"),
                        unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════
# TAB 4: ORDER INJECTOR (Plagio Inverso)
# ══════════════════════════════════════════════════════════════

with tab_plag:
    st.markdown("""
    <div class="section-title"><span>▸</span> ORDER INJECTOR — INVERSE PLAGIARISM AUDIT</div>
    """, unsafe_allow_html=True)

    st.markdown(f"""
    <div style="font-size:0.72rem;color:rgba(255,177,0,0.5);margin-bottom:1rem;
                border-left:3px solid rgba(255,177,0,0.3);padding-left:0.8rem;">
    Compares external code against <code>core/manifold_engine.py</code>.
    Detects replication of κD = {K_D} logic under any variable name.
    </div>
    """, unsafe_allow_html=True)

    col_plag_in, col_plag_out = st.columns([1, 1], gap="medium")

    with col_plag_in:
        st.markdown("""
        <div class="section-title" style="font-size:0.75rem">
        <span>▸</span> SUSPICIOUS CODE</div>
        """, unsafe_allow_html=True)

        plag_upload_mode = st.radio(
            "Code source",
            ["File .py", "Direct text"],
            horizontal=True,
            label_visibility="collapsed",
            key="plag_mode",
        )

        suspicious_code = ""
        if plag_upload_mode == "File .py":
            plag_file = st.file_uploader(
                "Upload suspicious code",
                type=["py", "txt", "js", "ts", "cpp", "java"],
                label_visibility="collapsed",
                key="plag_uploader",
            )
            if plag_file:
                suspicious_code = plag_file.read().decode("utf-8", errors="replace")
        else:
            suspicious_code = st.text_area(
                "Paste suspicious code:",
                height=280,
                placeholder="# Paste code to analyze...\n\ndef stability_factor(x):\n    return x * 0.56",
                label_visibility="collapsed",
                key="plag_textarea",
            )

        # Mostrar info de referencia
        ref_exists = (ROOT / "core" / "manifold_engine.py").exists()
        ref_lines  = 0
        if ref_exists:
            ref_lines = len((ROOT / "core" / "manifold_engine.py").read_text(encoding="utf-8", errors="replace").splitlines())
        st.markdown(f"""
        <div style="font-size:0.65rem;color:rgba(255,177,0,0.35);margin-top:0.5rem;">
        REFERENCE: core/manifold_engine.py
        {"· " + str(ref_lines) + " lines" if ref_exists else " · NOT FOUND"}
        </div>
        """, unsafe_allow_html=True)

        st.markdown("<div style='margin-top:0.8rem'></div>", unsafe_allow_html=True)
        run_plag = st.button("⬣  EXECUTE STRUCTURAL PLAGIARISM ANALYSIS",
                             use_container_width=True,
                             key="btn_plag")

    with col_plag_out:
        st.markdown("""
        <div class="section-title" style="font-size:0.75rem">
        <span>▸</span> RESULT</div>
        """, unsafe_allow_html=True)

        if run_plag:
            if not suspicious_code.strip():
                st.warning("No code to analyze.")
            else:
                with st.spinner("Analyzing structural similarity..."):
                    _log("Starting inverse plagiarism analysis...", "warn")
                    p_report = PLAGIARISM.analyze(suspicious_code)
                    st.session_state["plag_report"] = p_report
                    st.session_state["plag_code"]   = suspicious_code
                    level = ("risk" if "PLAGIO" in p_report.verdict
                             else "warn" if "SOSPECHOSA" in p_report.verdict
                             else "ok")
                    _log(f"Plagio: {p_report.verdict} | Score: {p_report.overall_score:.4f}", level)
                st.rerun()

        p_rep: PlagiarismReport | None = st.session_state.get("plag_report")

        if p_rep is None:
            st.markdown("""
            <div style="color:rgba(255,177,0,0.2);font-size:0.75rem;
                        text-align:center;padding:3rem 1rem;
                        border:1px dashed rgba(255,177,0,0.1);">
            SYSTEM IDLE<br>
            <span style="font-size:0.65rem">Load code and run the analysis</span>
            </div>
            """, unsafe_allow_html=True)
        else:
            # Verdict banner
            v_colors = {
                "INTENTO DE PLAGIO ESTRUCTURAL": ("verdict-highrisk", "⚠"),
                "SIMILITUD SOSPECHOSA":           ("verdict-review",   "⚡"),
                "ORIGINAL":                       ("verdict-clear",    "✓"),
            }
            v_css, v_icon = v_colors.get(p_rep.verdict, ("verdict-review", "?"))
            st.markdown(f"""
            <div class="{v_css}">
                {v_icon} &nbsp; {p_rep.verdict}
            </div>
            """, unsafe_allow_html=True)

            st.markdown("<div style='margin-top:1rem'></div>", unsafe_allow_html=True)

            # Score desglosado
            p1, p2 = st.columns(2)
            with p1:
                score_kind = ("risk" if p_rep.overall_score >= 0.6
                              else "warn" if p_rep.overall_score >= 0.35
                              else "ok")
                st.markdown(_metric_card(
                    "SCORE GLOBAL", f"{p_rep.overall_score:.4f}",
                    p_rep.verdict[:20], score_kind),
                    unsafe_allow_html=True)
            with p2:
                st.markdown(_metric_card(
                    "SIMILITUD κD", f"{p_rep.constant_sim:.4f}",
                    f"{len(p_rep.kappa_hits)} constante(s) detectada(s)",
                    "risk" if p_rep.constant_sim > 0.5 else "const"),
                    unsafe_allow_html=True)

            st.markdown("<div style='margin-top:0.8rem'></div>", unsafe_allow_html=True)

            p3, p4 = st.columns(2)
            with p3:
                st.markdown(_metric_card(
                    "ESTRUCTURAL AST", f"{p_rep.structural_sim:.4f}",
                    p_rep.structural_details[:40] + "...",
                    "warn" if p_rep.structural_sim > 0.3 else "ok"),
                    unsafe_allow_html=True)
            with p4:
                st.markdown(_metric_card(
                    "API SURFACE", f"{p_rep.api_sim:.4f}",
                    f"{len(p_rep.api_hits)} matching function(s)",
                    "risk" if p_rep.api_sim > 0.3 else "ok"),
                    unsafe_allow_html=True)

            # Barra visual del score
            st.markdown(
                '<div class="metric-label" style="margin-top:0.8rem;">STRUCTURAL SIMILARITY INDEX</div>'
                + _stability_bar(p_rep.overall_score, risk=p_rep.overall_score >= 0.6),
                unsafe_allow_html=True,
            )

            # κD hits detalle
            if p_rep.kappa_hits:
                with st.expander(f"◈ κD CONSTANTS DETECTED ({len(p_rep.kappa_hits)})"):
                    for h in p_rep.kappa_hits:
                        color = {"EXACTO": "#FF2D2D", "EQUIVALENTE": "#FF6600",
                                 "CLOSE": "#FFB100"}.get(h["type"], "#CC8D00")
                        st.markdown(
                            f"<div style='padding:.3rem .8rem;margin:.2rem 0;"
                            f"border-left:3px solid {color};font-size:.75rem;'>"
                            f"<span style='color:{color}'>[{h['type']}]</span> "
                            f"Line <strong>{h['line']}</strong>: "
                            f"<code>{h['value']}</code> "
                            f"(Δ={h['delta']:.4f})</div>",
                            unsafe_allow_html=True,
                        )

            # API hits
            if p_rep.api_hits:
                with st.expander(f"◈ MATCHING API SIGNATURES ({len(p_rep.api_hits)})"):
                    for h in p_rep.api_hits:
                        st.markdown(
                            f"<div style='padding:.3rem .8rem;border-left:3px solid #FF6600;"
                            f"font-size:.75rem;color:#FFB100;'>{h}</div>",
                            unsafe_allow_html=True,
                        )

            # Semantic patterns
            if p_rep.pattern_hits:
                with st.expander(f"◈ SEMANTIC PATTERNS ({len(p_rep.pattern_hits)})"):
                    for h in p_rep.pattern_hits:
                        st.markdown(
                            f"<div style='padding:.3rem .8rem;border-left:3px solid #CC8D00;"
                            f"font-size:.75rem;color:#CC8D00;'>{h}</div>",
                            unsafe_allow_html=True,
                        )

            # Evidencia completa
            with st.expander("◈ COMPLETE EVIDENCE SUMMARY"):
                st.markdown(
                    f'<div class="terminal-output">{p_rep.evidence_summary.replace(chr(10),"<br>")}</div>',
                    unsafe_allow_html=True,
                )


# ══════════════════════════════════════════════════════════════
# TAB 5: SHADOW-CODE DETECTOR
# ══════════════════════════════════════════════════════════════

with tab_shadow:
    st.markdown("""
    <div class="section-title"><span>▸</span> SHADOW-CODE DETECTOR — COMPUTATIONAL AUTHORSHIP ANALYSIS</div>
    """, unsafe_allow_html=True)
    st.markdown(f"""
    <div style="font-size:.72rem;color:rgba(255,177,0,.5);margin-bottom:1rem;
                border-left:3px solid rgba(255,177,0,.3);padding-left:.8rem;">
    Detects whether code was written by a human or generated by AI attempting
    to replicate κD = {K_D} invariance logic.
    Metrics: fractal roughness · lexical burstiness · comment density ·
    naming entropy · structural regularity.
    </div>
    """, unsafe_allow_html=True)

    col_sd_in, col_sd_out = st.columns([1, 1], gap="medium")

    with col_sd_in:
        st.markdown('<div class="section-title" style="font-size:.75rem"><span>▸</span> CODE TO EXAMINE</div>',
                    unsafe_allow_html=True)

        sd_mode = st.radio("Source", ["File", "Direct text"],
                           horizontal=True, label_visibility="collapsed", key="sd_mode")

        shadow_source = ""
        if sd_mode == "File":
            sd_file = st.file_uploader("Code to examine",
                                       type=["py", "js", "ts", "cpp", "java", "txt"],
                                       label_visibility="collapsed", key="sd_upload")
            if sd_file:
                shadow_source = sd_file.read().decode("utf-8", errors="replace")
        else:
            shadow_source = st.text_area(
                "Paste code:",
                height=300,
                placeholder="# Code to examine...",
                label_visibility="collapsed",
                key="sd_text",
            )

        run_shadow = st.button("◉  EXECUTE SHADOW-CODE ANALYSIS",
                               use_container_width=True, key="btn_shadow")

    with col_sd_out:
        st.markdown('<div class="section-title" style="font-size:.75rem"><span>▸</span> RESULT</div>',
                    unsafe_allow_html=True)

        if run_shadow:
            if not shadow_source.strip():
                st.warning("No code to analyze.")
            else:
                with st.spinner("Computing authorship fractal roughness..."):
                    _log("Shadow-Code analysis iniciado...", "warn")
                    sd_report = SHADOW_DETECT.analyze(shadow_source)
                    st.session_state["shadow_report"] = sd_report
                    st.session_state["shadow_code"]   = shadow_source
                    _log(f"Shadow: {sd_report.verdict} | Human: {sd_report.human_score:.4f}", "warn")
                st.rerun()

        sd_rep: ShadowCodeReport | None = st.session_state.get("shadow_report")

        if sd_rep is None:
            st.markdown("""
            <div style="color:rgba(255,177,0,.2);font-size:.75rem;text-align:center;
                        padding:3rem;border:1px dashed rgba(255,177,0,.1);">
            LOAD CODE AND RUN THE ANALYSIS
            </div>""", unsafe_allow_html=True)
        else:
            # Veredicto banner
            _sd_css = {
                "PROBABLE ALGORITHMIC PLAGIARISM": ("verdict-highrisk", "⚠"),
                "GENERADO POR IA":              ("verdict-highrisk", "⚠"),
                "ASISTIDO POR IA":              ("verdict-review",   "⚡"),
                "PROBABLE HUMAN AUTHORSHIP":    ("verdict-clear",    "✓"),
            }
            _sd_c, _sd_i = _sd_css.get(sd_rep.verdict, ("verdict-review", "?"))
            st.markdown(f'<div class="{_sd_c}">{_sd_i} &nbsp; {sd_rep.verdict}</div>',
                        unsafe_allow_html=True)
            st.markdown("<div style='margin-top:.8rem'></div>", unsafe_allow_html=True)

            sd1, sd2 = st.columns(2)
            with sd1:
                _hk = ("ok" if sd_rep.human_score > .6 else
                       "risk" if sd_rep.human_score < .35 else "const")
                st.markdown(_metric_card("HUMAN SCORE", f"{sd_rep.human_score:.4f}",
                                         sd_rep.verdict[:22], _hk), unsafe_allow_html=True)
            with sd2:
                st.markdown(_metric_card("FRACTAL ROUGHNESS", f"{sd_rep.fractal_roughness:.4f}",
                                         "Line irregularity",
                                         "ok" if sd_rep.fractal_roughness > .5 else "risk"),
                             unsafe_allow_html=True)
            st.markdown("<div style='margin-top:.5rem'></div>", unsafe_allow_html=True)
            sd3, sd4 = st.columns(2)
            with sd3:
                st.markdown(_metric_card("LEXICAL BURSTINESS", f"{sd_rep.lexical_burstiness:.4f}",
                                         "Gini del vocabulario",
                                         "ok" if sd_rep.lexical_burstiness > .5 else "risk"),
                             unsafe_allow_html=True)
            with sd4:
                st.markdown(_metric_card("COMMENT RATIO", f"{sd_rep.comment_ratio:.1%}",
                                         "Sobre-comentado" if sd_rep.comment_ratio > .3 else "Normal",
                                         "risk" if sd_rep.comment_ratio > .3 else "ok"),
                             unsafe_allow_html=True)

            # Barra de human score
            st.markdown(
                '<div class="metric-label" style="margin-top:.6rem;">HUMANITY INDEX</div>'
                + _stability_bar(sd_rep.human_score, risk=sd_rep.human_score < .35),
                unsafe_allow_html=True)

            # Evidencia
            if sd_rep.evidence_points:
                with st.expander(f"◈ FORENSIC EVIDENCE ({len(sd_rep.evidence_points)} signals)"):
                    for ep in sd_rep.evidence_points:
                        _ec = "#FF2D2D" if "LLM" in ep else "#FFB100"
                        st.markdown(
                            f"<div style='padding:.3rem .8rem;margin:.2rem 0;"
                            f"border-left:3px solid {_ec};font-size:.75rem;color:{_ec};'>{ep}</div>",
                            unsafe_allow_html=True)

    # ── Plotly scatter chart ───────────────────────────────────
    if st.session_state.get("shadow_report"):
        sd_rep = st.session_state["shadow_report"]
        st.markdown('<div class="section-title" style="margin-top:1rem"><span>▸</span> AUTHORSHIP MAP — DISPERSIÓN FRACTAL</div>',
                    unsafe_allow_html=True)

        # Construir figura
        scatter_data = sd_rep.scatter_data
        fig_sc = go.Figure()

        # Zonas de fondo
        fig_sc.add_shape(type="rect", x0=0, y0=0, x1=0.5, y1=0.5,
                         fillcolor="rgba(255,45,45,0.06)", line_width=0, layer="below")
        fig_sc.add_shape(type="rect", x0=0.5, y0=0.5, x1=1, y1=1,
                         fillcolor="rgba(0,255,136,0.06)", line_width=0, layer="below")

        # Puntos de referencia
        ref_pts = [p for p in scatter_data if p.get("ref")]
        main_pt = [p for p in scatter_data if not p.get("ref")]

        if ref_pts:
            llm_pts  = [p for p in ref_pts if p["color"] == "#FF2D2D"]
            hum_pts  = [p for p in ref_pts if p["color"] == "#00FF88"]
            fig_sc.add_trace(go.Scatter(
                x=[p["x"] for p in llm_pts], y=[p["y"] for p in llm_pts],
                mode="markers", name="Zona IA",
                marker=dict(color="#FF2D2D", size=10, symbol="circle",
                            line=dict(color="#FF2D2D", width=1)),
                opacity=0.5,
            ))
            fig_sc.add_trace(go.Scatter(
                x=[p["x"] for p in hum_pts], y=[p["y"] for p in hum_pts],
                mode="markers", name="Zona Humana",
                marker=dict(color="#00FF88", size=10, symbol="circle",
                            line=dict(color="#00FF88", width=1)),
                opacity=0.5,
            ))

        # Punto analizado
        if main_pt:
            p = main_pt[0]
            hs = p.get("human_score", 0.5)
            pt_color = ("#00FF88" if hs > .6 else "#FF2D2D" if hs < .35 else "#FFB100")
            fig_sc.add_trace(go.Scatter(
                x=[p["x"]], y=[p["y"]],
                mode="markers+text",
                name="Documento analizado",
                text=[f"  Score={hs:.3f}"],
                textposition="middle right",
                textfont=dict(color=AMBER, size=10),
                marker=dict(color=pt_color, size=18, symbol="diamond",
                            line=dict(color=AMBER, width=2)),
            ))

        # Threshold lines
        fig_sc.add_hline(y=0.5, line_dash="dash", line_color=AMBER,
                         annotation_text=" Umbral Humano/IA",
                         annotation_font=dict(color=AMBER, size=8))
        fig_sc.add_vline(x=0.5, line_dash="dash", line_color=AMBER)

        # Anotaciones de zonas
        fig_sc.add_annotation(x=0.25, y=0.1, text="ZONA IA / LLM",
                               font=dict(color="#FF2D2D", size=9, family="Orbitron"),
                               showarrow=False)
        fig_sc.add_annotation(x=0.75, y=0.9, text="ZONA HUMANA",
                               font=dict(color="#00FF88", size=9, family="Orbitron"),
                               showarrow=False)

        fig_sc.update_layout(
            **_PLOTLY_LAYOUT,
            title=dict(text=f"FRACTAL AUTHORSHIP SCATTER — {sd_rep.verdict}",
                       font=dict(size=10, color=AMBER)),
            xaxis=dict(title="Fractal Roughness →", color=AMBER, range=[0, 1],
                       gridcolor="rgba(255,177,0,.1)"),
            yaxis=dict(title="Lexical Burstiness →", color=AMBER, range=[0, 1],
                       gridcolor="rgba(255,177,0,.1)"),
            legend=dict(font=dict(color=AMBER, size=9), bgcolor="rgba(0,0,0,.5)"),
            height=420,
        )
        st.plotly_chart(fig_sc, use_container_width=True, key="chart_shadow")

        # κD hits si existen
        if sd_rep.kappa_constants:
            st.markdown(f"""
            <div style="border:1px solid #FF2D2D;padding:.8rem;margin-top:.5rem;
                        background:rgba(255,45,45,.05);">
            <span style="color:#FF2D2D;font-family:Orbitron,monospace;font-size:.75rem;">
            ⚠ {len(sd_rep.kappa_constants)} CONSTANTE(S) κD-PROXIMAL(ES) DETECTADA(S)
            </span><br>
            <span style="color:rgba(255,177,0,.6);font-size:.65rem;">
            {'  |  '.join(f"L{h['line']}: {h['value']} (Δ={h['delta']})"
                          for h in sd_rep.kappa_constants[:5])}
            </span>
            </div>
            """, unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════
# TAB 6: INVARIANCE LEDGER (Forensic Ledger)
# ══════════════════════════════════════════════════════════════

with tab_ledger:
    st.markdown("""
    <div class="section-title"><span>▸</span> INVARIANCE LEDGER — FORENSIC RECORD</div>
    """, unsafe_allow_html=True)

    # Integrity check + stats
    _integrity = ledger_verify()
    _n         = _integrity.get("entries", 0)

    lc1, lc2, lc3, lc4 = st.columns(4)
    with lc1:
        st.markdown(_metric_card("TOTAL ENTRIES", str(_n), "Sealed operations", "const"),
                    unsafe_allow_html=True)
    with lc2:
        st.markdown(_metric_card("INTEGRITY", "✓ OK" if _integrity["valid"] else "⚠ ERROR",
                                 "Chain hash verified", "ok"), unsafe_allow_html=True)
    with lc3:
        st.markdown(_metric_card("FIRST ENTRY", _integrity.get("first_ts", "—")[:10] or "—",
                                 "UTC", "const"), unsafe_allow_html=True)
    with lc4:
        st.markdown(_metric_card("LAST ENTRY",      _integrity.get("last_ts",  "—")[:10] or "—",
                                 "UTC", "const"), unsafe_allow_html=True)

    if _integrity.get("chain_hash"):
        st.markdown(f"""
        <div style="font-size:.62rem;color:rgba(255,177,0,.35);margin:.4rem 0 1rem;
                    font-family:Share Tech Mono,monospace;letter-spacing:.05em;">
        CHAIN HASH: {_integrity['chain_hash']}
        </div>
        """, unsafe_allow_html=True)

    st.markdown("---")

    # Load and display entries
    _entries = ledger_read()

    if not _entries:
        st.markdown("""
        <div style="color:rgba(255,177,0,.2);font-size:.75rem;text-align:center;
                    padding:2.5rem;border:1px dashed rgba(255,177,0,.1);">
        EMPTY LEDGER — Entries appear when using "Sign and Seal"
        </div>""", unsafe_allow_html=True)
    else:
        import pandas as pd

        rows = []
        for e in reversed(_entries):           # most recent first
            kd  = e.get("kd_result", {})
            auth = e.get("authorship_status", {})
            ms  = kd.get("manifold_score")
            rows.append({
                "Timestamp":    e.get("timestamp", "")[:19].replace("T", " "),
                "Type":         e.get("input_type", "—"),
                "Verdict":      e.get("verdict", "—"),
                "ManifoldScore": f"{ms:.4f}" if ms is not None else "INSUF.",
                "κD":           str(kd.get("kappa_d", "0.56")),
                "Signed":       "✓" if auth.get("signed") else "✗",
                "Anchored":     "✓" if auth.get("anchored") else "—",
                "Cert-ID":      (e.get("cert_id") or "—")[:20],
                "File Hash":    e.get("file_hash", "")[:16] + "...",
            })

        df = pd.DataFrame(rows)

        # Color rows by verdict
        def _color_row(row):
            c = {"HIGH_RISK": "color: #FF2D2D",
                 "REVIEW":    "color: #FFB100",
                 "CLEAR":     "color: #00FF88"}.get(row["Verdict"],   "color: #CC8D00")
            return [c] * len(row)

        st.dataframe(
            df.style.apply(_color_row, axis=1),
            use_container_width=True,
            hide_index=True,
            height=min(60 + len(rows) * 35, 500),
        )

        # Export
        col_ex1, col_ex2 = st.columns(2)
        with col_ex1:
            import json as _json
            st.download_button(
                "⬇  EXPORT LEDGER (JSONL)",
                data       = "\n".join(_json.dumps(e, ensure_ascii=False) for e in _entries),
                file_name  = "audit_ledger.jsonl",
                mime       = "application/jsonlines",
                use_container_width=True,
            )
        with col_ex2:
            st.download_button(
                "⬇  EXPORT LEDGER (CSV)",
                data       = df.to_csv(index=False),
                file_name  = "audit_ledger.csv",
                mime       = "text/csv",
                use_container_width=True,
            )

        # Detail expander for selected entry
        st.markdown("---")
        st.markdown('<div class="section-title" style="font-size:.75rem"><span>▸</span> ENTRY DETAIL</div>',
                    unsafe_allow_html=True)
        _sel_idx = st.selectbox(
            "Seleccionar entrada:",
            options=range(len(_entries)),
            format_func=lambda i: (
                f"[{len(_entries)-i}] "
                f"{_entries[-(i+1)].get('timestamp','')[:19]}  "
                f"{_entries[-(i+1)].get('verdict','—')}  "
                f"{_entries[-(i+1)].get('input_type','—')}"
            ),
            label_visibility="collapsed",
        )
        with st.expander("◈ COMPLETE JSON", expanded=False):
            st.json(_entries[-(int(_sel_idx)+1)])



# ══════════════════════════════════════════════════════════════
# TAB 7: SEMANTIC DIFF
# ══════════════════════════════════════════════════════════════

with tab_diff:
    st.markdown("""
    <div class="section-title"><span>▸</span> TOPOLOGICAL SEMANTIC DIFF — H₁ MANIFOLD COMPARATOR</div>
    """, unsafe_allow_html=True)

    _kd_diff = st.session_state.get("kd_live", K_D)

    st.markdown(f"""
    <div style="border:1px solid rgba(255,177,0,0.18);border-radius:6px;
                padding:0.7rem 1rem;margin-bottom:1rem;font-size:0.71rem;
                color:rgba(255,177,0,0.65);letter-spacing:0.05em;line-height:1.7;">
    Compares two documents at the <strong style="color:#FFB100">H₁ topological structure</strong> level.
    The Wasserstein Distance measures transformation energy between manifolds.
    Si el <strong style="color:#FFB100">ISI</strong> cae por debajo de
    κD = <strong style="color:#FFB100">{_kd_diff:.2f}</strong>,
    the <strong style="color:#FF2D2D">Structural Manipulation Alert</strong> is triggered.
    </div>
    """, unsafe_allow_html=True)

    if not _DIFF_OK:
        st.warning("Module semantic_diff.py not found. Copy it to core/")
    else:
        col_da, col_db = st.columns(2, gap="medium")
        with col_da:
            st.markdown('<div style="font-size:0.63rem;color:#FFB100;letter-spacing:0.12em;margin-bottom:0.3rem;">DOCUMENT A — ORIGINAL</div>', unsafe_allow_html=True)
            text_da = st.text_area("doc_a", placeholder="Paste the original document...",
                                   height=210, label_visibility="collapsed", key="diff_text_a")
        with col_db:
            st.markdown('<div style="font-size:0.63rem;color:#FFB100;letter-spacing:0.12em;margin-bottom:0.3rem;">DOCUMENT B — SUSPECT VERSION</div>', unsafe_allow_html=True)
            text_db = st.text_area("doc_b", placeholder="Paste the modified version...",
                                   height=210, label_visibility="collapsed", key="diff_text_b")

        col_la, col_lb, col_btn = st.columns([2, 2, 1], gap="small")
        with col_la:
            label_da = st.text_input("lbl_a", value="Original Document",
                                     key="diff_label_a", label_visibility="collapsed")
        with col_lb:
            label_db = st.text_input("lbl_b", value="Modified Version",
                                     key="diff_label_b", label_visibility="collapsed")
        with col_btn:
            btn_diff = st.button("◑  COMPARE", use_container_width=True, key="btn_diff")

        if btn_diff:
            if not text_da or not text_db:
                st.warning("⚠ Enter text in both documents.")
            else:
                with st.spinner("Calculating H₁ topological distances..."):
                    try:
                        _de = SemanticDiff(kappa_d=_kd_diff)
                        _dr = _de.compare_manifolds(text_da, text_db, label_da, label_db)
                        st.session_state["diff_report"] = _dr
                    except Exception as _e:
                        st.error(f"Error: {_e}")

        dr = st.session_state.get("diff_report")
        if dr is not None:
            isi_val = dr.invariant_similarity_index
            alert   = dr.manipulation_alert

            # ── DURANTE THERMOMETER ────────────────────────────
            if isi_val >= _kd_diff:
                bar_color, bar_label = "#00CC66", "✓ STABLE MANIFOLD"
                lbl_color = "#00CC66"
            elif isi_val >= _kd_diff * 0.7:
                bar_color, bar_label = "#FFB100", "△ STRUCTURAL CHANGE"
                lbl_color = "#FFB100"
            else:
                bar_color, bar_label = "#FF2D2D", "⚠ MANIFOLD RUPTURE — Structural Manipulation Detected"
                lbl_color = "#FF2D2D"

            kd_pct = (_kd_diff - 0.0) * 100  # κD en escala 0-1 → %

            st.markdown(f"""
            <div style="margin:0.6rem 0 1.2rem 0;">
                <div style="font-size:0.62rem;color:#FFB100;letter-spacing:0.13em;margin-bottom:0.5rem;">
                    DURANTE THERMOMETER — INVARIANT SIMILARITY INDEX (ISI)
                </div>
                <div style="position:relative;width:100%;height:34px;
                            background:rgba(255,177,0,0.08);border-radius:4px;
                            border:1px solid rgba(255,177,0,0.18);overflow:visible;">
                    <div style="position:absolute;top:0;left:0;height:100%;
                                width:{isi_val*100:.2f}%;background:{bar_color};
                                border-radius:3px;opacity:0.82;"></div>
                    <div style="position:absolute;top:-6px;left:{kd_pct:.1f}%;
                                width:2px;height:46px;background:#FFB100;
                                box-shadow:0 0 6px rgba(255,177,0,0.6);z-index:10;"></div>
                    <div style="position:absolute;top:-20px;left:calc({kd_pct:.1f}% - 40px);
                                font-size:0.57rem;color:#FFB100;font-family:monospace;white-space:nowrap;">
                        ◆ κD={_kd_diff:.2f}
                    </div>
                    <div style="position:absolute;top:0;left:0;width:100%;height:100%;
                                display:flex;align-items:center;padding-left:10px;">
                        <span style="font-size:0.70rem;font-family:monospace;
                                     color:#000;font-weight:700;">ISI = {isi_val:.4f}</span>
                    </div>
                </div>
                <div style="margin-top:0.45rem;font-size:0.72rem;color:{lbl_color};
                            letter-spacing:0.10em;font-weight:700;">{bar_label}</div>
            </div>
            """, unsafe_allow_html=True)

            if alert:
                st.markdown(f"""
                <div style="border:2px solid #FF2D2D;border-radius:6px;
                            padding:0.8rem 1.1rem;margin:0 0 0.8rem 0;
                            background:rgba(255,45,45,0.08);">
                    <div style="font-size:0.78rem;color:#FF2D2D;letter-spacing:0.13em;font-weight:700;">
                        ⚠ STRUCTURAL MANIPULATION ALERT DETECTED
                    </div>
                    <div style="font-size:0.66rem;color:rgba(255,100,100,0.85);margin-top:0.4rem;line-height:1.8;">
                        ISI = <strong style="color:#FF2D2D">{isi_val:.4f}</strong> &lt; κD = {_kd_diff:.2f}<br>
                        Wasserstein H₁ = <strong style="color:#FF2D2D">{dr.wasserstein_h1:.6f}</strong>
                        &nbsp;|&nbsp; Bottleneck = <strong style="color:#FF2D2D">{dr.bottleneck_h1:.6f}</strong>
                    </div>
                </div>
                """, unsafe_allow_html=True)

                # ── GENERADOR DE CONTRA-CONTEXTO ──────────────
                st.markdown("""
                <div class="section-title"><span>▸</span> STRUCTURED VERIFICATION PROTOCOL</div>
                """, unsafe_allow_html=True)

                if st.button("◎  GENERATE STRUCTURED VERIFICATION (3 surgical questions)",
                             key="btn_contra", use_container_width=True):
                    _wass  = dr.wasserstein_h1
                    _bott  = dr.bottleneck_h1
                    _dfaults = dr.delta.delta_structural_faults
                    _di    = dr.delta.delta_integrity

                    # Questions dynamically generated from actual metrics
                    _q1 = (
                        f"La Distancia de Wasserstein H₁ entre ambas versiones es {_wass:.4f}, "
                        f"superando el umbral κD={_kd_diff:.2f}. "
                        f"Can you identify which section of Document B introduces the highest transformation energy "
                        f"relative to Document A, and justify why that change does not alter the original legal/logicginal?"
                    )
                    _q2 = (
                        f"Se detectaron {_dfaults:+d} ciclos H₁ STRUCTURAL_FALSEHOOD nuevos en el documento B "
                        f"(integridad: {dr.report_b.get('integrity_score', 0):.4f} vs {dr.report_a.get('integrity_score', 0):.4f} en A). "
                        f"What is the source of the introduced semantic circularity, and why was it absent from the original version?"
                    )
                    _q3 = (
                        f"La Distancia de Bottleneck es {_bott:.4f} "
                        f"({'CRITICAL' if _bott > _kd_diff * 0.5 else 'MODERATE'}). "
                        f"This indicates at least one topological cycle was severely perturbed. "
                        f"Can you identify the specific clause, paragraph, or proposition constituting that semantic 'wormhole', "
                        f"y demostrar que no cambia las obligaciones establecidas?"
                    )

                    st.markdown(f"""
                    <div style="border:1px solid rgba(255,177,0,0.25);border-radius:6px;
                                padding:1rem 1.2rem;background:rgba(255,177,0,0.03);">
                        <div style="font-size:0.62rem;color:#FFB100;letter-spacing:0.12em;
                                    margin-bottom:0.8rem;font-weight:700;">
                            ◎ STRUCTURED VERIFICATION — 3 SURGICAL PRECISION QUESTIONS
                        </div>
                        <div style="font-size:0.70rem;color:rgba(255,177,0,0.85);line-height:1.9;
                                    border-left:2px solid #FFB100;padding-left:0.8rem;margin-bottom:0.7rem;">
                            <strong style="color:#FFB100;">① ENERGY TRACEABILITY:</strong><br>{_q1}
                        </div>
                        <div style="font-size:0.70rem;color:rgba(255,177,0,0.85);line-height:1.9;
                                    border-left:2px solid #FF6600;padding-left:0.8rem;margin-bottom:0.7rem;">
                            <strong style="color:#FF6600;">② H₁ CYCLE ORIGIN:</strong><br>{_q2}
                        </div>
                        <div style="font-size:0.70rem;color:rgba(255,177,0,0.85);line-height:1.9;
                                    border-left:2px solid #FF2D2D;padding-left:0.8rem;">
                            <strong style="color:#FF2D2D;">③ WORMHOLE LOCALIZATION:</strong><br>{_q3}
                        </div>
                    </div>
                    """, unsafe_allow_html=True)

                    st.download_button(
                        "⬇ EXPORT QUESTIONS (TXT)",
                        data=f"STRUCTURED VERIFICATION\nκD={_kd_diff:.2f} | ISI={isi_val:.4f} | {dr.verdict}\n\n① {_q1}\n\n② {_q2}\n\n③ {_q3}",
                        file_name=f"verificacion_{dr.hash_a[:8]}_{dr.hash_b[:8]}.txt",
                        mime="text/plain",
                        key="dl_contra",
                    )

            # ── Metrics and H₁ scatter ─────────────────────────
            mc1, mc2, mc3, mc4 = st.columns(4, gap="small")
            for _col, _lbl, _val, _note, _c in [
                (mc1, "WASSERSTEIN H₁", f"{dr.wasserstein_h1:.4f}", "total energy",
                 "#FF2D2D" if dr.wasserstein_h1 > _kd_diff else "#FFB100"),
                (mc2, "BOTTLENECK",     f"{dr.bottleneck_h1:.4f}", "most perturbed cycle",
                 "#FF2D2D" if dr.bottleneck_h1 > _kd_diff * 0.5 else "#FFB100"),
                (mc3, "Δ FALSEHOODS",  f"{dr.delta.delta_structural_faults:+d}", "new H₁ cycles",
                 "#FF2D2D" if dr.delta.delta_structural_faults > 0 else "#00CC66"),
                (mc4, "Δ INTEGRITY",  f"{dr.delta.delta_integrity:+.4f}", "integrity B − A",
                 "#FF2D2D" if dr.delta.delta_integrity < 0 else "#00CC66"),
            ]:
                _col.markdown(f"""
                <div style="border:1px solid rgba(255,177,0,0.18);border-radius:5px;
                            padding:0.5rem 0.7rem;background:rgba(255,177,0,0.04);">
                    <div style="font-size:0.57rem;color:rgba(255,177,0,0.50);letter-spacing:0.09em;">{_lbl}</div>
                    <div style="font-size:1.05rem;color:{_c};font-family:monospace;font-weight:700;">{_val}</div>
                    <div style="font-size:0.57rem;color:rgba(255,177,0,0.35);">{_note}</div>
                </div>""", unsafe_allow_html=True)

            with st.expander("◎ COMPLETE TECHNICAL REPORT", expanded=False):
                st.code(dr.summary, language=None)
                st.download_button("⬇ JSON DIFF",
                    data=dr.to_json(),
                    file_name=f"diff_{dr.hash_a[:8]}_{dr.hash_b[:8]}.json",
                    mime="application/json", key="dl_diff_json")


# ══════════════════════════════════════════════════════════════
# TAB 8: FORENSIC AUDIT — Batch + Ledger
# ══════════════════════════════════════════════════════════════

with tab_batch:
    st.markdown("""
    <div class="section-title"><span>▸</span> FORENSIC AUDIT — TOPOGRAPHIC CORPUS ASSESSMENT</div>
    """, unsafe_allow_html=True)

    _kd_batch = st.session_state.get("kd_live", K_D)

    st.markdown(f"""
    <div style="border:1px solid rgba(255,177,0,0.18);border-radius:6px;
                padding:0.7rem 1rem;margin-bottom:1rem;font-size:0.71rem;
                color:rgba(255,177,0,0.65);letter-spacing:0.05em;line-height:1.7;">
    Process a complete corpus. The <strong style="color:#FFB100">CIR</strong>
    (Corpus Integrity Rate) measures what fraction of documents exceeds
    κD = <strong style="color:#FFB100">{_kd_batch:.2f}</strong>.
    CIR &lt; 50% → <strong style="color:#FF2D2D">CORPUS COMPROMISED</strong>.
    Sign the verdict with immutable SHA-256 via <strong style="color:#FFB100">Forensic Ledger</strong>.
    </div>
    """, unsafe_allow_html=True)

    if not _BATCH_OK:
        st.warning("Module batch_auditor.py not found. Copy it to core/")
    else:
        cfg1, cfg2 = st.columns([2, 1], gap="medium")
        with cfg1:
            batch_files = st.file_uploader(
                "Documents for bulk audit",
                type=["txt", "pdf", "docx"],
                accept_multiple_files=True,
                key="batch_uploader",
                label_visibility="collapsed",
            )
        with cfg2:
            batch_itype = st.selectbox("Type", ["generic","legal","discourse","finance","code"],
                                       key="batch_itype")
            btn_batch = st.button("≣  EXECUTE AUDIT", use_container_width=True, key="btn_batch")

        if btn_batch and batch_files:
            _ba = BatchAuditor(kappa_d=_kd_batch, input_type=batch_itype)
            _n  = len(batch_files)
            _pb = st.progress(0)
            _ps = st.empty()
            _lt = st.empty()
            _batch_results = []

            for _i, _uf in enumerate(batch_files):
                _pb.progress(int(_i/_n*100))
                _ps.markdown(f'<span style="font-size:0.63rem;color:#FFB100;font-family:monospace;">'
                             f'▶ [{_i+1}/{_n}] {_uf.name}</span>', unsafe_allow_html=True)
                _res = _ba._process_single(_uf.name, _uf.read(), batch_itype)
                _batch_results.append(_res)
                _rows = []
                for _r in _batch_results:
                    _s = f"{_r.manifold_score:.3f}" if _r.manifold_score >= 0 else "ERR"
                    _ic = "🟢" if _r.passes_kd else ("🔴" if _r.status=="OK" else "⚪")
                    _rows.append(f"{_ic} `{_r.filename[:40]}` — `{_s}` — `{_r.overall_verdict}`")
                _lt.markdown("\n".join(_rows))

            _pb.progress(100)
            _ps.markdown('<span style="font-size:0.63rem;color:#00CC66;font-family:monospace;">✓ COMPLETED</span>',
                         unsafe_allow_html=True)
            import datetime as _dt
            _br = _ba._build_report(_dt.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"), _batch_results)
            st.session_state["batch_report"] = _br
            st.session_state["batch_auditor"] = _ba

        br = st.session_state.get("batch_report")
        if br is not None:

            # ── CORPUS COMPROMISED banner ────────────────────────
            if br.corpus_compromised:
                st.markdown(f"""
                <div style="border:2px solid #FF2D2D;border-radius:6px;padding:0.9rem 1.2rem;
                            margin:0 0 1rem 0;background:rgba(255,45,45,0.09);">
                    <div style="font-size:0.88rem;color:#FF2D2D;letter-spacing:0.15em;font-weight:700;">
                        ⚠ CORPUS COMPROMISED: High Structural Entropy Density
                    </div>
                    <div style="font-size:0.66rem;color:rgba(255,100,100,0.85);margin-top:0.35rem;">
                        CIR = <strong style="color:#FF2D2D">{br.cir:.1%}</strong> —
                        Menos del 50% de los documentos supera κD = {br.kappa_d:.2f}
                    </div>
                </div>""", unsafe_allow_html=True)

            # ── KPIs ────────────────────────────────────────────
            k1,k2,k3,k4,k5 = st.columns(5, gap="small")
            _tic_c = "#00CC66" if br.cir >= 0.5 else "#FF2D2D"
            for _col, _lbl, _val, _c, _sub in [
                (k1, "CIR",           f"{br.cir:.1%}",          _tic_c,  br.corpus_verdict),
                (k2, "AVG. SCORE",   f"{br.mean_manifold:.4f}", "#00CC66" if br.mean_manifold>=_kd_batch else "#FF2D2D", f"κD={_kd_batch:.2f}"),
                (k3, "CLEAR",         str(br.clear_count),       "#00CC66", "≥ κD"),
                (k4, "HIGH_RISK",     str(br.high_risk_count),   "#FF2D2D", "< κD"),
                (k5, "ERR/SKIP",      str(br.errors+br.skipped), "#FFB100", f"{br.errors}e·{br.skipped}s"),
            ]:
                _col.markdown(f"""
                <div style="border:1px solid rgba(255,177,0,0.20);border-radius:6px;
                            padding:0.6rem 0.5rem;background:rgba(255,177,0,0.04);text-align:center;">
                    <div style="font-size:0.55rem;color:rgba(255,177,0,0.50);letter-spacing:0.10em;">{_lbl}</div>
                    <div style="font-size:1.35rem;color:{_c};font-family:monospace;font-weight:700;">{_val}</div>
                    <div style="font-size:0.55rem;color:rgba(255,177,0,0.35);">{_sub}</div>
                </div>""", unsafe_allow_html=True)

            st.markdown("<div style='margin-top:0.7rem'></div>", unsafe_allow_html=True)

            # ── Bar chart ───────────────────────────────────────
            _ok_r = [r for r in br.results if r.status=="OK" and r.manifold_score>=0]
            if _ok_r:
                _fig_b = go.Figure(go.Bar(
                    x=list(range(len(_ok_r))),
                    y=[r.manifold_score for r in _ok_r],
                    marker_color=["#00CC66" if r.passes_kd else "#FF2D2D" for r in _ok_r],
                    marker_line_width=0,
                    text=[f"{r.manifold_score:.3f}" for r in _ok_r],
                    textposition="outside",
                    textfont=dict(size=8, color=AMBER),
                    hovertext=[r.filename for r in _ok_r],
                    hoverinfo="text+y",
                ))
                _fig_b.add_hline(y=_kd_batch, line_color="#FFB100", line_width=1.5,
                                  line_dash="dash",
                                  annotation_text=f"κD={_kd_batch:.2f} — Durante Limit",
                                  annotation_font_color=AMBER, annotation_font_size=9,
                                  annotation_position="top right")
                _fig_b.update_layout(
                    paper_bgcolor="#000", plot_bgcolor="#0D0D0D",
                    font=dict(family="IBM Plex Mono, monospace", color=AMBER, size=9),
                    margin=dict(l=35,r=35,t=25,b=55), height=250,
                    xaxis=dict(tickvals=list(range(len(_ok_r))),
                               ticktext=[r.filename[:20] for r in _ok_r],
                               tickangle=-35, color=AMBER,
                               gridcolor="rgba(255,177,0,0.04)"),
                    yaxis=dict(color=AMBER, gridcolor="rgba(255,177,0,0.06)"),
                    showlegend=False,
                )
                st.plotly_chart(_fig_b, use_container_width=True)

            # ── Tabla resultados ────────────────────────────────
            st.markdown("""<div class="section-title"><span>▸</span> RESULTS TABLE</div>""",
                        unsafe_allow_html=True)
            for _r in br.results:
                _sc  = f"{_r.manifold_score:.4f}" if _r.manifold_score>=0 else "ERR"
                _vc  = "#00CC66" if _r.overall_verdict=="CLEAR" else "#FF2D2D" if _r.overall_verdict=="HIGH_RISK" else "#FFB100"
                _kdf = '<span style="color:#00CC66">✓</span>' if _r.passes_kd else '<span style="color:#FF2D2D">✗</span>' if _r.status=="OK" else '—'
                st.markdown(f"""
                <div style="display:flex;align-items:center;gap:0.7rem;padding:0.3rem 0.5rem;
                            border-bottom:1px solid rgba(255,177,0,0.07);font-size:0.67rem;font-family:monospace;">
                    <span style="min-width:1.2rem;">{_kdf}</span>
                    <span style="flex:1;color:rgba(255,177,0,0.85);overflow:hidden;text-overflow:ellipsis;
                                 white-space:nowrap;">{_r.filename}</span>
                    <span style="min-width:5rem;color:#FFB100;">score:{_sc}</span>
                    <span style="min-width:5rem;color:#FFB100;">coh:{_r.coherence_score:.3f if _r.coherence_score>=0 else 'N/A'}</span>
                    <span style="min-width:7rem;color:{_vc};font-weight:700;">{_r.overall_verdict}</span>
                    <span style="min-width:3.5rem;color:rgba(255,177,0,0.40);">{_r.status}</span>
                </div>""", unsafe_allow_html=True)

            # ── FORENSIC LEDGER — Verdict signing ──────────────
            st.markdown("""
            <div class="section-title" style="margin-top:1rem;">
                <span>▸</span> FORENSIC LEDGER — IMMUTABLE VERDICT SIGNING
            </div>""", unsafe_allow_html=True)

            if _LEDGER_OK:
                if st.button("🔐  SIGN VERDICT (Forensic Ledger)",
                             use_container_width=True, key="btn_ledger_batch"):
                    _lv  = LedgerVanguard()
                    _corpus_text = "\n".join(
                        [r.filename + "|" + str(r.manifold_score) + "|" + r.overall_verdict
                         for r in br.results]
                    )
                    _le = _lv.sign(
                        text           = _corpus_text,
                        manifold_score = br.mean_manifold,
                        verdict        = f"TIC={br.cir:.4f}|{br.corpus_verdict}",
                        kappa_d        = _kd_batch,
                    )
                    st.session_state["ledger_entry"] = _le
                    _log(f"Batch Forensic Ledger signed: {_le.entry_hash[:24]}...", "ok")

                _le = st.session_state.get("ledger_entry")
                if _le is not None:
                    st.markdown(f"""
                    <div style="border:1px solid rgba(255,177,0,0.30);border-radius:6px;
                                padding:0.9rem 1.1rem;background:rgba(255,177,0,0.04);
                                font-family:monospace;font-size:0.68rem;line-height:2.0;">
                        <div style="color:#FFB100;font-weight:700;letter-spacing:0.12em;
                                    margin-bottom:0.6rem;">◆ FORENSIC LEDGER ENTRY</div>
                        <div style="color:rgba(255,177,0,0.80);">
                        ENTRY_HASH&nbsp;&nbsp;&nbsp;: <strong style="color:#FFB100">{_le.entry_hash}</strong><br>
                        DOC_HASH&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: {_le.doc_hash}<br>
                        SCORE&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: {_le.manifold_score}<br>
                        VERDICT&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: {_le.verdict}<br>
                        κD&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: {_le.kappa_d}<br>
                        TIMESTAMP&nbsp;&nbsp;&nbsp;&nbsp;: {_le.timestamp_utc}
                        </div>
                    </div>
                    """, unsafe_allow_html=True)

                    # Blockchain Readiness
                    with st.expander("⛓ BLOCKCHAIN READINESS — Anchoring Payload"):
                        st.markdown(f"""
                        <div style="font-size:0.64rem;color:rgba(255,177,0,0.70);
                                    font-family:monospace;line-height:2.0;">
                        <strong style="color:#FFB100;">OpenTimestamps (Bitcoin):</strong><br>
                        <span style="color:rgba(255,177,0,0.55);">{_le.ots_payload}</span><br><br>
                        <strong style="color:#FFB100;">Ethereum calldata:</strong><br>
                        <span style="color:rgba(255,177,0,0.55);">{_le.eth_calldata}</span><br><br>
                        <strong style="color:#FFB100;">Canonical payload (JSON):</strong><br>
                        <span style="color:rgba(255,177,0,0.55);">{_le.canonical_json}</span>
                        </div>
                        """, unsafe_allow_html=True)
                        st.download_button("⬇ EXPORT PAYLOAD",
                                           data=_le.canonical_json,
                                           file_name=f"ledger_{_le.entry_hash[:16]}.json",
                                           mime="application/json",
                                           key="dl_ledger_payload")
            else:
                st.info("Module ledger_vanguard.py not found. Copy it to core/")

            # ── Download Center ─────────────────────────────────
            st.markdown("""<div class="section-title"><span>▸</span> DOWNLOAD CENTER</div>""",
                        unsafe_allow_html=True)
            _ts_s  = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            _ba_dl = st.session_state.get("batch_auditor") or BatchAuditor(kappa_d=_kd_batch)
            dc1, dc2 = st.columns(2, gap="medium")
            with dc1:
                st.download_button("⬇ EXPORT CSV",
                    data=_ba_dl.to_csv_bytes(br),
                    file_name=f"batch_{_ts_s}.csv",
                    mime="text/csv", use_container_width=True, key="dl_batch_csv")
            with dc2:
                try:
                    _xlsx = _ba_dl.to_xlsx_bytes(br)
                    st.download_button("⬇ EXPORT COLORED EXCEL",
                        data=_xlsx,
                        file_name=f"batch_{_ts_s}.xlsx",
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        use_container_width=True, key="dl_batch_xlsx")
                except RuntimeError as _xe:
                    st.warning(f"Excel unavailable: {_xe}")


# ══════════════════════════════════════════════════════════════
# TAB 9: ACTIVE SURVEILLANCE — Live Stream Monitor + Calibration
# ══════════════════════════════════════════════════════════════

with tab_monitor:
    st.markdown("""
    <div class="section-title"><span>▸</span> ACTIVE SURVEILLANCE — INVARIANCE SHIELD</div>
    """, unsafe_allow_html=True)

    _kd_mon = st.session_state.get("kd_live", K_D)

    # ── Section A: κD CALIBRATION ─────────────────────────────
    st.markdown("""
    <div class="section-title"><span>▸</span> A. κD THRESHOLD CALIBRATION</div>
    """, unsafe_allow_html=True)

    st.markdown(f"""
    <div style="border:1px solid rgba(255,177,0,0.18);border-radius:6px;
                padding:0.7rem 1rem;margin-bottom:1rem;font-size:0.70rem;
                color:rgba(255,177,0,0.65);letter-spacing:0.05em;line-height:1.7;">
    The master slider in the sidebar controls κD globally.
    Here you can see the real-time effect on the already-scanned text,
    without re-running the full pipeline.
    The value <strong style="color:#FFB100">0.56</strong> is the
    <strong style="color:#FFB100">Durante Equilibrium Point</strong> —
    the golden zone of maximum semantic discrimination.
    </div>
    """, unsafe_allow_html=True)

    # Extended calibration bar
    _zones = [
        (0.40, 0.48, "#888888", "Probabilistic noise"),
        (0.48, 0.54, "#FFB100", "Pre-threshold"),
        (0.54, 0.58, "#00CC66", "Durante Equilibrium Point"),
        (0.58, 0.65, "#FFB100", "Post-threshold"),
        (0.65, 0.80, "#FF6600", "Over-restriction"),
    ]

    st.markdown('<div style="position:relative;height:28px;border-radius:4px;overflow:hidden;margin-bottom:0.3rem;display:flex;">', unsafe_allow_html=True)
    for _z0, _z1, _zc, _zn in _zones:
        _zw = (_z1 - _z0) / (0.80 - 0.40) * 100
        st.markdown(f'<div style="width:{_zw:.1f}%;background:{_zc};opacity:0.25;"></div>', unsafe_allow_html=True)
    st.markdown('</div>', unsafe_allow_html=True)

    # Marcadores de zona
    _zone_cols = st.columns(5)
    for _ci, (_z0, _z1, _zc, _zn) in enumerate(_zones):
        _zone_cols[_ci].markdown(
            f'<div style="font-size:0.55rem;color:{_zc};text-align:center;letter-spacing:0.05em;">'
            f'{_z0:.2f}–{_z1:.2f}<br>{_zn}</div>',
            unsafe_allow_html=True,
        )

    st.markdown(f"""
    <div style="margin:0.8rem 0;padding:0.7rem 1rem;border-radius:5px;
                border:1px solid rgba(255,177,0,0.30);
                background:rgba(255,177,0,0.06);text-align:center;">
        <span style="font-size:1.4rem;color:#FFB100;font-family:monospace;font-weight:700;">
            Active κD = {_kd_mon:.2f}
        </span>
        <span style="font-size:0.70rem;color:rgba(255,177,0,0.55);margin-left:1rem;">
            {'◆ Durante Equilibrium Point' if abs(_kd_mon-0.56)<0.02
             else '⚠ Away from optimal point — adjust carefully'}
        </span>
    </div>
    """, unsafe_allow_html=True)

    # Effect of κD on last report
    _rep_actual = st.session_state.get("report")
    if _rep_actual is not None:
        _ms = _rep_actual.manifold_score
        _new_verdict = "CLEAR" if _ms >= _kd_mon else "HIGH_RISK" if _ms < _kd_mon * 0.85 else "REVIEW"
        _orig_verdict = _rep_actual.overall_verdict
        st.markdown(f"""
        <div style="font-size:0.70rem;color:rgba(255,177,0,0.75);
                    border:1px solid rgba(255,177,0,0.15);border-radius:5px;
                    padding:0.6rem 0.9rem;margin-bottom:0.8rem;line-height:2.0;">
            <strong style="color:#FFB100;">Effect on last scan:</strong><br>
            ManifoldScore = <strong style="color:#FFB100;">{_ms:.4f}</strong>
            &nbsp;|&nbsp; Original verdict: <strong>{_orig_verdict}</strong>
            &nbsp;→&nbsp; With κD={_kd_mon:.2f}: <strong style="color:{'#00CC66' if _new_verdict=='CLEAR' else '#FF2D2D' if _new_verdict=='HIGH_RISK' else '#FFB100'};">{_new_verdict}</strong>
            {'&nbsp; <em style="color:rgba(255,177,0,0.50);">(no changes)</em>' if _new_verdict==_orig_verdict else '&nbsp; <strong style="color:#FF2D2D;">← VERDICT CHANGES</strong>'}
        </div>
        """, unsafe_allow_html=True)
    else:
        st.markdown('<div style="font-size:0.67rem;color:rgba(255,177,0,0.40);">Run a scan in the Terminal to see the slider effect on the verdict.</div>', unsafe_allow_html=True)

    st.markdown("<hr style='border-color:rgba(255,177,0,0.12);margin:1rem 0;'>", unsafe_allow_html=True)

    # ── Section B: LIVE STREAM MONITOR ────────────────────────
    st.markdown("""
    <div class="section-title"><span>▸</span> B. INVARIANCE SHIELD — LIVE STREAM MONITOR</div>
    """, unsafe_allow_html=True)

    st.markdown(f"""
    <div style="border:1px solid rgba(255,177,0,0.15);border-radius:6px;
                padding:0.7rem 1rem;margin-bottom:1rem;font-size:0.70rem;
                color:rgba(255,177,0,0.60);line-height:1.7;">
    Paste the output of an external model (AI, API, LLM). The monitor analyzes
    sliding text windows and evaluates whether the accumulated ManifoldScore
    stays above κD = <strong style="color:#FFB100">{_kd_mon:.2f}</strong>.
    If it drops below for N consecutive windows, the
    <strong style="color:#FF2D2D">Invariance Shield</strong> activates.
    </div>
    """, unsafe_allow_html=True)

    mon_col1, mon_col2 = st.columns([3,1], gap="medium")
    with mon_col1:
        stream_text = st.text_area(
            "stream_input",
            placeholder="Paste the external model output to monitor here...",
            height=200,
            label_visibility="collapsed",
            key="stream_input_text",
        )
    with mon_col2:
        win_size = st.number_input("Window (approx. tokens)", min_value=30, max_value=300,
                                    value=80, step=10, key="mon_window_size")
        max_drops = st.number_input("Max drops before alert", min_value=1, max_value=10,
                                     value=3, step=1, key="mon_max_drops")
        btn_monitor = st.button("⚙  ANALYZE STREAM", use_container_width=True, key="btn_monitor")

    if btn_monitor:
        if not stream_text or len(stream_text.strip()) < 40:
            st.warning("⚠ Enter at least 40 characters to analyze the stream.")
        else:
            if _MONITOR_OK:
                with st.spinner("Analyzing sliding windows..."):
                    try:
                        _mon = StreamMonitor(
                            kappa_d=_kd_mon,
                            window_size=int(win_size),
                            max_consecutive_drops=int(max_drops),
                        )
                        _events = list(_mon.analyze_text(stream_text))
                        st.session_state["stream_events"]     = _events
                        st.session_state["stream_score_hist"] = [e.score for e in _events if hasattr(e, 'score') and e.score is not None]
                    except Exception as _me:
                        st.error(f"Error en monitor: {_me}")
            else:
                # Fallback: manual analysis with FullDiagnostic in windows
                with st.spinner("Analyzing windows (fallback mode)..."):
                    _words    = stream_text.split()
                    _ws       = int(win_size)
                    _events   = []
                    _scores   = []
                    _n_drops  = 0
                    _disconnected = False
                    for _wi in range(0, len(_words), _ws // 2):
                        _chunk = " ".join(_words[_wi: _wi + _ws])
                        if len(_chunk.strip()) < 20:
                            continue
                        try:
                            _wr = DIAGNOSTIC.run(_chunk, input_type="generic")
                            _ws_score = _wr.manifold_score
                        except Exception:
                            _ws_score = -1.0
                        _drop = _ws_score >= 0 and _ws_score < _kd_mon
                        if _drop:
                            _n_drops += 1
                        else:
                            _n_drops = 0
                        _action = "OK"
                        if _n_drops >= int(max_drops) and not _disconnected:
                            _action = "DISCONNECT"
                            _disconnected = True
                        elif _drop:
                            _action = "WARNING"
                        _events.append({
                            "window": _wi // (_ws // 2) + 1,
                            "score":  _ws_score,
                            "action": _action,
                            "text_preview": _chunk[:60] + "...",
                        })
                        _scores.append(_ws_score if _ws_score >= 0 else 0)
                    st.session_state["stream_events"]     = _events
                    st.session_state["stream_score_hist"] = _scores

    _events = st.session_state.get("stream_events", [])
    _score_hist = st.session_state.get("stream_score_hist", [])

    if _events:
        # ── Indicador del Escudo ──────────────────────────────
        _has_disconnect = any(
            (e.get("action") if isinstance(e, dict) else getattr(e, "action", "OK")) == "DISCONNECT"
            for e in _events
        )
        _has_warning = any(
            (e.get("action") if isinstance(e, dict) else getattr(e, "action", "OK")) == "WARNING"
            for e in _events
        )
        _shield_color  = "#FF2D2D" if _has_disconnect else "#FFB100" if _has_warning else "#00CC66"
        _shield_label  = "🔴 INCOHERENCE DISCONNECTION" if _has_disconnect else "🟡 ALERT — STRUCTURAL TENSION" if _has_warning else "🟢 SHIELD ACTIVE — INTACT STREAM"
        _shield_border = "#FF2D2D" if _has_disconnect else "#FFB100" if _has_warning else "#00CC66"

        st.markdown(f"""
        <div style="border:2px solid {_shield_border};border-radius:8px;
                    padding:0.9rem 1.2rem;margin:0 0 1rem 0;
                    background:{'rgba(255,45,45,0.09)' if _has_disconnect else 'rgba(255,177,0,0.05)'};
                    text-align:center;">
            <div style="font-size:1.0rem;color:{_shield_color};font-weight:700;letter-spacing:0.15em;">
                {_shield_label}
            </div>
            <div style="font-size:0.63rem;color:rgba(255,177,0,0.55);margin-top:0.3rem;">
                {len(_events)} windows analyzed &nbsp;·&nbsp;
                κD = {_kd_mon:.2f} &nbsp;·&nbsp;
                Ventana = {win_size} tokens
            </div>
        </div>
        """, unsafe_allow_html=True)

        # ── Window score chart ──────────────────────────────────
        if _score_hist:
            _valid_scores = [s for s in _score_hist if s >= 0]
            if _valid_scores:
                _fig_mon = go.Figure()
                _xs = list(range(1, len(_valid_scores)+1))
                _cs = ["#FF2D2D" if s < _kd_mon else "#00CC66" for s in _valid_scores]

                _fig_mon.add_trace(go.Scatter(
                    x=_xs, y=_valid_scores,
                    mode="lines+markers",
                    line=dict(color=AMBER, width=1.5),
                    marker=dict(size=7, color=_cs, line=dict(width=1, color="#000")),
                    name="ManifoldScore ventana",
                ))
                _fig_mon.add_hline(y=_kd_mon, line_color="#FFB100", line_width=1.5,
                                    line_dash="dash",
                                    annotation_text=f"κD={_kd_mon:.2f}",
                                    annotation_font_color=AMBER, annotation_font_size=9)
                _fig_mon.update_layout(
                    paper_bgcolor="#000", plot_bgcolor="#0D0D0D",
                    font=dict(family="IBM Plex Mono, monospace", color=AMBER, size=9),
                    margin=dict(l=35,r=35,t=25,b=30), height=220,
                    xaxis=dict(title="Ventana #", color=AMBER, gridcolor="rgba(255,177,0,0.05)"),
                    yaxis=dict(title="Score", color=AMBER, gridcolor="rgba(255,177,0,0.07)",
                               range=[0, 1.05]),
                    showlegend=False,
                )
                st.plotly_chart(_fig_mon, use_container_width=True)

        # ── Tabla de eventos ──────────────────────────────────
        st.markdown("""<div class="section-title"><span>▸</span> WINDOW LOG</div>""",
                    unsafe_allow_html=True)
        for _ev in _events:
            if isinstance(_ev, dict):
                _w, _s, _a, _tp = _ev.get("window","?"), _ev.get("score",-1), _ev.get("action","OK"), _ev.get("text_preview","")
            else:
                _w, _s, _a, _tp = getattr(_ev,"window_idx",0), getattr(_ev,"score",-1), getattr(_ev,"action","OK"), getattr(_ev,"text_preview","")
            _ac = "#FF2D2D" if _a=="DISCONNECT" else "#FFB100" if _a=="WARNING" else "#00CC66"
            _sc_str = f"{_s:.4f}" if isinstance(_s, float) and _s >= 0 else "—"
            st.markdown(f"""
            <div style="display:flex;gap:0.8rem;align-items:center;padding:0.28rem 0.5rem;
                        border-bottom:1px solid rgba(255,177,0,0.06);
                        font-size:0.64rem;font-family:monospace;">
                <span style="min-width:3.5rem;color:rgba(255,177,0,0.55);">ventana {_w}</span>
                <span style="min-width:4.5rem;color:#FFB100;">score:{_sc_str}</span>
                <span style="min-width:6rem;color:{_ac};font-weight:700;">{_a}</span>
                <span style="color:rgba(255,177,0,0.45);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{str(_tp)[:70]}</span>
            </div>""", unsafe_allow_html=True)

    else:
        st.markdown(
            '<div style="font-size:0.67rem;color:rgba(255,177,0,0.35);padding:0.5rem;">'
            'Paste the external model output and run the analysis to activate the Invariance Shield.</div>',
            unsafe_allow_html=True,
        )


# ══════════════════════════════════════════════════════════════
# TAB 10: LOG DE SISTEMA
# ══════════════════════════════════════════════════════════════

with tab_log:
    st.markdown("""
    <div class="section-title"><span>▸</span> LOG TERMINAL</div>
    """, unsafe_allow_html=True)

    # Current session log
    session_log = st.session_state.get("scan_log", [])
    if session_log:
        log_html = "<br>".join(f"$ {line}" for line in session_log)
    else:
        log_html = '<span class="log-dim">$ System started. Awaiting operations.</span>'

    st.markdown(
        f'<div class="terminal-output">{log_html}</div>',
        unsafe_allow_html=True,
    )

    st.markdown("<div style='margin-top:1rem'></div>", unsafe_allow_html=True)

    # Persistent history from log file
    st.markdown("""
    <div class="section-title"><span>▸</span> SCAN HISTORY</div>
    """, unsafe_allow_html=True)

    history = CONNECTOR.load_history(last_n=50)
    if history:
        hist_html = "<br>".join(f'<span class="log-dim">{line}</span>'
                                for line in reversed(history))
        st.markdown(
            f'<div class="terminal-output">{hist_html}</div>',
            unsafe_allow_html=True,
        )
        st.download_button(
            "⬇  EXPORT HISTORY",
            data="\n".join(history),
            file_name=f"scan_history_{datetime.datetime.now().strftime('%Y%m%d')}.log",
            mime="text/plain",
        )
    else:
        st.markdown(
            '<div class="terminal-output">'
            '<span class="log-dim">$ No previous history.</span></div>',
            unsafe_allow_html=True,
        )

    # Footer
    st.markdown(f"""
    <div style="margin-top:2rem;padding-top:0.8rem;
                border-top:1px solid rgba(255,177,0,0.15);
                font-size:0.62rem;color:rgba(255,177,0,0.30);
                letter-spacing:0.12em;text-align:center;">
    OMNI-SCANNER SEMANTIC v2.0 &nbsp;·&nbsp; PROTOCOL ANEXA ULTRA v4.0
    &nbsp;·&nbsp; κD = {K_D} &nbsp;·&nbsp;
    {datetime.datetime.now().strftime('%Y-%m-%d')}
    </div>
    """, unsafe_allow_html=True)
