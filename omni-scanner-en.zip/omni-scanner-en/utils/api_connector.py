"""
api_connector.py — Omni-Scanner Semantic v1.0
-----------------------------------------------
Exportador y conector de reportes. Guarda evidencia localmente en logs/ y
reports/, and optionally sends to an external webhook configurable via .env.

CHANGELOG vs original version:
  + send_to_origin(diagnostic_data) preservada con firma original
  + FIX: URL 'api.gemini.sovereign' no existe. Reemplazada por:
      a) Guardado local de reportes (siempre disponible, sin dependencias)
      b) Webhook opcional configurable en .env (WEBHOOK_URL)
  + NUEVO: save_report() — persiste JSON + Markdown en reports/
  + NEW: log_scan() — adds entry to history in logs/scans_history.log
  + NUEVO: export_evidence() — copia reporte a logs/evidence_vault/ con hash
  + NEW: load_history() — reads previous scan history
"""
from __future__ import annotations
import os
import json
import hashlib
import datetime
from pathlib import Path
from typing import Optional


class ApiConnector:
    """
    Exportador de reportes y conector opcional a webhook externo.

    Parameters
    ----------
    base_dir : str      Project root directory.
    webhook_url : str   URL de webhook externo (opcional, sobreescribe .env).
    """

    def __init__(self, base_dir: str = ".", webhook_url: Optional[str] = None):
        self.base_dir = Path(base_dir)
        self.reports_dir = self.base_dir / "reports"
        self.logs_dir = self.base_dir / "logs"
        self.vault_dir = self.logs_dir / "evidence_vault"
        self.log_file = self.logs_dir / "scans_history.log"

        # Webhook: argumento > variable de entorno > None
        self.webhook_url = (
            webhook_url
            or os.getenv("WEBHOOK_URL")
            or None
        )

        # Crear directorios si no existen
        for d in [self.reports_dir, self.logs_dir, self.vault_dir,
                  self.reports_dir / "visuals", self.reports_dir / "generators"]:
            d.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # API ORIGINAL (preservada para compatibilidad)
    # ------------------------------------------------------------------

    def send_to_origin(self, diagnostic_data: dict) -> dict:
        """
        Sincroniza el hallazgo. API original preservada.

        Comportamiento corregido:
        - Guarda el reporte localmente (siempre).
        - If WEBHOOK_URL is set in .env, attempts HTTP send.
        - If no webhook, returns local success without network call.
        """
        report_path = self.save_report(diagnostic_data, format="json")
        self.log_scan(diagnostic_data)

        genesis_hash = diagnostic_data.get(
            "hash_genesis",
            hashlib.sha256(json.dumps(diagnostic_data, default=str).encode()).hexdigest()[:16]
        )
        print(f"[SYNC] Reporte guardado localmente. Hash: {genesis_hash}")
        print(f"[SYNC] Location: {report_path}")

        if self.webhook_url:
            return self._send_webhook(diagnostic_data, genesis_hash)

        return {
            "status": "SUCCESS",
            "storage": "LOCAL",
            "report_path": str(report_path),
            "hash": genesis_hash,
            "message": "Report persisted. Set WEBHOOK_URL in .env for remote sending.",
        }

    # ------------------------------------------------------------------
    # API EXTENDIDA
    # ------------------------------------------------------------------

    def save_report(self, data: dict, format: str = "json", filename: Optional[str] = None) -> Path:
        """
        Persiste el reporte en reports/.
        format: "json" | "markdown" | "both"
        """
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        name = filename or f"scan_{ts}"
        paths = []

        if format in ("json", "both"):
            p = self.reports_dir / "generators" / f"{name}.json"
            p.write_text(json.dumps(data, default=str, indent=2), encoding="utf-8")
            paths.append(p)

        if format in ("markdown", "both"):
            p = self.reports_dir / "generators" / f"{name}.md"
            p.write_text(self._to_markdown(data, name), encoding="utf-8")
            paths.append(p)

        return paths[0] if paths else self.reports_dir

    def log_scan(self, data: dict) -> None:
        """Adds a line to the scan history."""
        ts = datetime.datetime.now().isoformat()
        verdict = data.get("overall_verdict", data.get("verdict", "N/A"))
        input_type = data.get("input_type", "unknown")
        entry = f"[{ts}] type={input_type} verdict={verdict}\n"
        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(entry)

    def export_evidence(self, data: dict, label: str = "") -> Path:
        """
        Copia el reporte al evidence_vault con hash de integridad.
        Useful for preserving immutable audit evidence.
        """
        content = json.dumps(data, default=str, indent=2)
        integrity_hash = hashlib.sha256(content.encode()).hexdigest()
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_label = label.replace(" ", "_")[:30] if label else "evidence"
        filename = f"{ts}_{safe_label}_{integrity_hash[:12]}.json"

        vault_path = self.vault_dir / filename
        vault_path.write_text(content, encoding="utf-8")

        # Manifest file with the full hash
        manifest = {
            "file": filename,
            "sha256": integrity_hash,
            "timestamp": ts,
            "label": label,
        }
        manifest_path = self.vault_dir / f"{filename}.manifest.json"
        manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

        print(f"[VAULT] Evidence sealed: {filename}")
        print(f"[VAULT] SHA-256: {integrity_hash}")
        return vault_path

    def load_history(self, last_n: int = 20) -> list[str]:
        """Reads the last N entries from scan history."""
        if not self.log_file.exists():
            return []
        lines = self.log_file.read_text(encoding="utf-8").splitlines()
        return lines[-last_n:]

    # ------------------------------------------------------------------
    # Helpers privados
    # ------------------------------------------------------------------

    def _send_webhook(self, data: dict, genesis_hash: str) -> dict:
        """Sends the report to an external HTTP webhook (requires 'requests')."""
        try:
            import requests  # lazy import — not mandatory
            payload = {
                "hash_genesis": genesis_hash,
                "timestamp": datetime.datetime.now().isoformat(),
                "report": data,
            }
            resp = requests.post(
                self.webhook_url,
                json=payload,
                timeout=10,
                headers={"Content-Type": "application/json"},
            )
            resp.raise_for_status()
            print(f"[WEBHOOK] Enviado a {self.webhook_url} — Status: {resp.status_code}")
            return {"status": "SUCCESS", "storage": "REMOTE+LOCAL", "http_status": resp.status_code}
        except ImportError:
            return {"status": "WARNING", "message": "requests no instalado. Solo guardado local."}
        except Exception as e:
            return {"status": "ERROR", "message": str(e), "storage": "LOCAL"}

    def _to_markdown(self, data: dict, title: str) -> str:
        """Convierte el reporte a Markdown legible."""
        lines = [
            f"# Scan Report: {title}",
            f"**Fecha:** {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "",
            "## Verdict",
            f"```",
            f"Global verdict   : {data.get('overall_verdict', 'N/A')}",
            f"Tipo de input    : {data.get('input_type', 'N/A')}",
            f"ManifoldScore    : {data.get('manifold_score', 'N/A')}",
            f"Confianza        : {data.get('confidence', 'N/A')}",
            f"```",
            "",
            "## Datos Completos",
            "```json",
            json.dumps(data, default=str, indent=2),
            "```",
        ]
        return "\n".join(lines)
