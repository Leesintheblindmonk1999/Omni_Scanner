"""
text_cleaner.py — Omni-Scanner Semantic v1.0
----------------------------------------------
Lexical noise normalizer. Prepares text for semantic analysis
preservando el español completo (tildes, ñ, ü, ç).

CHANGELOG vs original version:
  + clean(raw_text) preservada con firma original
  + segment_by_logic(text) preservada con firma original
  + CRITICAL FIX: .encode('ascii','ignore') removed all accents and ñ,
    breaking Spanish clause detection (e.g. 'Cláusula' → 'Clusula').
    Replaced by NFKC Unicode normalization that preserves Spanish.
  + NEW: clean() accepts keep_case parameter (default False = lowercase)
  + NEW: clean_for_analysis() — conservative cleaning that preserves case
    and punctuation for TopologyMapper and EntropyAnalyzer
  + NEW: extract_metadata() — extracts dates, amounts and numeric references
  + NEW: segment_by_paragraph() — paragraph segmentation (more useful than by '.;:')
  + NUEVO: normalize_legal_abbreviations() — expande abreviaturas comunes
"""
from __future__ import annotations
import re
import unicodedata
from typing import List


# Common legal/technical abbreviations in Spanish
_LEGAL_ABBREVS = {
    r"\bart\.": "artículo",
    r"\barts\.": "artículos",
    r"\bcfr\.": "conforme",
    r"\bej\.": "ejemplo",
    r"\betc\.": "etcétera",
    r"\binc\.": "inciso",
    r"\blit\.": "literal",
    r"\bnum\.": "número",
    r"\bpár\.": "párrafo",
    r"\bpárs\.": "párrafos",
    r"\bsec\.": "sección",
    r"\bvid\.": "véase",
}

# Artefactos de encoding frecuentes en documentos escaneados / PDFs
_ENCODING_ARTIFACTS = {
    "\x92": "'",  "\x93": '"',  "\x94": '"',
    "\x96": "–",  "\x97": "—",  "\xa0": " ",
    "\x85": "...", "\x91": "'",  "\x95": "•",
}


class TextCleaner:
    """
    Normalizador de texto para el pipeline del Omni-Scanner.

    Parameters
    ----------
    remove_html : bool          Eliminar etiquetas HTML/XML (default True).
    normalize_whitespace : bool Collapse multiple spaces (default True).
    fix_encoding : bool         Corregir artefactos de encoding (default True).
    expand_abbrevs : bool       Expandir abreviaturas legales (default False).
    """

    def __init__(
        self,
        remove_html: bool = True,
        normalize_whitespace: bool = True,
        fix_encoding: bool = True,
        expand_abbrevs: bool = False,
    ):
        self.remove_html = remove_html
        self.normalize_whitespace = normalize_whitespace
        self.fix_encoding = fix_encoding
        self.expand_abbrevs = expand_abbrevs

    # ------------------------------------------------------------------
    # API ORIGINAL (preservada para compatibilidad)
    # ------------------------------------------------------------------

    def clean(self, raw_text: str, keep_case: bool = False) -> str:
        """
        Standard text cleaning. Original API preserved and corrected.

        FIX: eliminado .encode('ascii','ignore') que destruía español.
        Ahora usa normalización Unicode NFKC + eliminación solo de caracteres
        de control, preservando todo el alfabeto español.

        Parameters
        ----------
        raw_text : str
        keep_case : bool    If True, preserves case. Default False (lowercase).
        """
        text = raw_text

        # 1. Artefactos de encoding (PDF, Word, etc.)
        if self.fix_encoding:
            text = self._fix_encoding_artifacts(text)

        # 2. NFKC Unicode normalization (preserves accents and ñ)
        text = unicodedata.normalize("NFKC", text)

        # 3. Eliminar etiquetas HTML/XML
        if self.remove_html:
            text = re.sub(r"<[^>]*>", "", text)

        # 4. Eliminar caracteres de control (pero NO letras acentuadas)
        text = self._remove_control_chars(text)

        # 5. Normalize spaces and line breaks
        if self.normalize_whitespace:
            text = re.sub(r"\s+", " ", text).strip()

        # 6. Abbreviation expansion (optional)
        if self.expand_abbrevs:
            text = self.normalize_legal_abbreviations(text)

        return text if keep_case else text.lower()

    def segment_by_logic(self, text: str) -> List[str]:
        """
        Divide el texto en unidades de pensamiento lógico.
        API original preservada. Filtra segmentos vacíos.
        """
        segments = re.split(r"[.;:]", text)
        return [s.strip() for s in segments if s.strip()]

    # ------------------------------------------------------------------
    # API EXTENDIDA
    # ------------------------------------------------------------------

    def clean_for_analysis(self, raw_text: str) -> str:
        """
        Limpieza conservadora: preserva mayúsculas y puntuación oracional.
        Ideal para TopologyMapper (necesita oraciones completas) y
        EntropyAnalyzer (sensible a la distribución real de tokens).
        """
        text = self._fix_encoding_artifacts(raw_text)
        text = unicodedata.normalize("NFKC", text)
        if self.remove_html:
            text = re.sub(r"<[^>]*>", "", text)
        text = self._remove_control_chars(text)
        # Preserve sentence punctuation, only collapse multiple spaces
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text.strip()

    def segment_by_paragraph(self, text: str) -> List[str]:
        """
        Segmentación por párrafos (doble salto de línea).
        Más útil que segment_by_logic para documentos legales y técnicos.
        """
        paragraphs = re.split(r"\n{2,}", text.strip())
        return [p.strip() for p in paragraphs if len(p.strip()) > 20]

    def segment_by_sentence(self, text: str) -> List[str]:
        """
        Sentence segmentation with abbreviation handling.
        Preserva el punto final para el TopologyMapper.
        """
        # Marcadores temporales para abreviaturas que contienen punto
        protected = re.sub(
            r"\b(art|arts|dr|sr|sra|ing|lic|etc|num|pár|sec)\.",
            lambda m: m.group(0).replace(".", "<<<DOT>>>"),
            text,
            flags=re.IGNORECASE,
        )
        sentences = re.split(r"(?<=[.!?])\s+(?=[A-ZÁÉÍÓÚÑA-Z])", protected)
        return [
            s.replace("<<<DOT>>>", ".").strip()
            for s in sentences
            if len(s.strip()) > 10
        ]

    def extract_metadata(self, text: str) -> dict:
        """
        Extrae entidades numéricas y referencias clave del texto.
        Useful for contract auditing (deadlines, amounts, percentages).
        """
        dates = re.findall(
            r"\b(\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4}-\d{2}-\d{2})\b", text
        )
        amounts = re.findall(
            r"\b(?:USD|ARS|EUR|BTC)?\s*[\$€£]?\s*\d[\d.,]*(?:\s*(?:millones?|mil))?\b",
            text, re.IGNORECASE,
        )
        percentages = re.findall(r"\b\d+(?:[.,]\d+)?\s*%", text)
        deadlines = re.findall(
            r"\b\d+\s*(?:días?|meses?|años?|horas?|semanas?)\b", text, re.IGNORECASE
        )
        references = re.findall(
            r"\b(?:art[ií]culo|cláusula|inciso|sección|anexo)\s+\d+\w*\b",
            text, re.IGNORECASE,
        )

        return {
            "dates": dates,
            "amounts": amounts,
            "percentages": percentages,
            "deadlines": deadlines,
            "legal_references": references,
            "has_numeric_content": bool(dates or amounts or percentages),
        }

    def normalize_legal_abbreviations(self, text: str) -> str:
        """Expands common legal abbreviations in Spanish."""
        for pattern, replacement in _LEGAL_ABBREVS.items():
            text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)
        return text

    def strip_boilerplate(self, text: str, min_sentence_len: int = 30) -> str:
        """
        Elimina frases de boilerplate muy cortas o repetitivas
        (footnotes, generic one-line disclaimers).
        """
        sentences = self.segment_by_sentence(text)
        return " ".join(s for s in sentences if len(s) >= min_sentence_len)

    # ------------------------------------------------------------------
    # Helpers privados
    # ------------------------------------------------------------------

    def _fix_encoding_artifacts(self, text: str) -> str:
        for bad, good in _ENCODING_ARTIFACTS.items():
            text = text.replace(bad, good)
        return text

    def _remove_control_chars(self, text: str) -> str:
        """
        Elimina solo caracteres de control Unicode (categoría Cc),
        preservando letras, tildes, ñ y cualquier carácter visible.
        """
        return "".join(
            ch for ch in text
            if unicodedata.category(ch) != "Cc" or ch in ("\n", "\t")
        )
